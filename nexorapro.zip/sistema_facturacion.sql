-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 25-08-2026 a las 19:44:16
-- Versión del servidor: 8.4.7
-- Versión de PHP: 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sistema_facturacion`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `caja_montos`
--

DROP TABLE IF EXISTS `caja_montos`;
CREATE TABLE IF NOT EXISTS `caja_montos` (
  `id_monto` int NOT NULL AUTO_INCREMENT,
  `id_caja` int NOT NULL,
  `id_moneda` int NOT NULL,
  `tipo` enum('INICIAL','CONTADO') NOT NULL,
  `monto` decimal(14,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_monto`),
  UNIQUE KEY `uq_caja_moneda_tipo` (`id_caja`,`id_moneda`,`tipo`),
  KEY `fk_montos_moneda` (`id_moneda`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `caja_montos`
--

INSERT INTO `caja_montos` (`id_monto`, `id_caja`, `id_moneda`, `tipo`, `monto`) VALUES
(1, 1, 4, 'INICIAL', 200000.00),
(2, 1, 1, 'INICIAL', 100.00),
(3, 1, 3, 'INICIAL', 5000.00),
(4, 1, 4, 'CONTADO', 689510.50),
(5, 1, 1, 'CONTADO', 100.00),
(6, 1, 3, 'CONTADO', 12500.00),
(7, 2, 4, 'INICIAL', 200000.00),
(8, 2, 1, 'INICIAL', 100.00),
(9, 2, 3, 'INICIAL', 5000.00),
(10, 2, 4, 'CONTADO', 200000.00),
(11, 2, 1, 'CONTADO', 100.00),
(12, 2, 3, 'CONTADO', 5000.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `caja_movimientos`
--

DROP TABLE IF EXISTS `caja_movimientos`;
CREATE TABLE IF NOT EXISTS `caja_movimientos` (
  `id_movimiento` int NOT NULL AUTO_INCREMENT,
  `id_caja` int NOT NULL,
  `id_moneda` int NOT NULL,
  `tipo` enum('RETIRO','INGRESO') NOT NULL,
  `monto` decimal(14,2) NOT NULL,
  `motivo` varchar(255) DEFAULT NULL,
  `id_usuario` int NOT NULL,
  `fecha` datetime NOT NULL,
  PRIMARY KEY (`id_movimiento`),
  KEY `fk_cajamov_caja` (`id_caja`),
  KEY `fk_cajamov_moneda` (`id_moneda`),
  KEY `fk_cajamov_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `caja_sesiones`
--

DROP TABLE IF EXISTS `caja_sesiones`;
CREATE TABLE IF NOT EXISTS `caja_sesiones` (
  `id_caja` int NOT NULL AUTO_INCREMENT,
  `id_usuario_apertura` int NOT NULL,
  `fecha_apertura` datetime NOT NULL,
  `id_usuario_cierre` int DEFAULT NULL,
  `fecha_cierre` datetime DEFAULT NULL,
  `estado` enum('ABIERTA','CERRADA') NOT NULL DEFAULT 'ABIERTA',
  `observaciones_apertura` varchar(255) DEFAULT NULL,
  `observaciones_cierre` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_caja`),
  KEY `fk_caja_usuario_apertura` (`id_usuario_apertura`),
  KEY `fk_caja_usuario_cierre` (`id_usuario_cierre`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `caja_sesiones`
--

INSERT INTO `caja_sesiones` (`id_caja`, `id_usuario_apertura`, `fecha_apertura`, `id_usuario_cierre`, `fecha_cierre`, `estado`, `observaciones_apertura`, `observaciones_cierre`) VALUES
(1, 1, '2026-08-25 14:56:29', 1, '2026-08-25 15:06:33', 'CERRADA', '', ''),
(2, 1, '2026-08-25 15:35:21', 1, '2026-08-25 15:37:06', 'CERRADA', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE IF NOT EXISTS `categorias` (
  `id_categoria` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_categoria`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id_categoria`, `nombre`, `descripcion`, `activo`) VALUES
(1, 'Electrónica', 'Productos electrónicos', 1),
(2, 'Accesorios', 'Accesorios para dispositivos', 0),
(3, 'Hogar', 'Productos para el hogar', 1),
(4, 'Otros', 'Productos generales', 1),
(5, 'Mercado', NULL, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE IF NOT EXISTS `clientes` (
  `id_cliente` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documento` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `correo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `fecha_creacion` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cliente`),
  KEY `idx_clientes_nombre` (`nombre`),
  KEY `idx_clientes_documento` (`documento`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `nombre`, `documento`, `telefono`, `correo`, `direccion`, `activo`, `fecha_creacion`) VALUES
(1, 'Miguel Torres', '19673245', '04264578321', 'migueltorres@gmail.com', '', 1, '2026-08-20 16:27:39'),
(2, 'Valentina Hernandez', '23154687', '04148762314', 'valentinahernandez@gmail.com', '', 1, '2026-08-20 16:28:24'),
(3, 'Daniela Alvarado', '32456134', '04265463311', 'Danielaalvarado@gmail.com', '', 1, '2026-08-20 16:28:57'),
(4, 'Jesus Salazar', '26430987', '04123789654', 'jesussalazar@gmail.com', '', 1, '2026-08-20 16:29:36'),
(5, 'Daniel Blanco', '17543789', '04167234598', 'danielblanco@gmail.com', '', 1, '2026-08-20 16:31:28');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras`
--

DROP TABLE IF EXISTS `compras`;
CREATE TABLE IF NOT EXISTS `compras` (
  `id_compra` int NOT NULL AUTO_INCREMENT,
  `numero_factura` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_proveedor` int NOT NULL,
  `id_usuario` int NOT NULL,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `descuento` decimal(12,2) NOT NULL DEFAULT '0.00',
  `impuesto` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `id_moneda` int NOT NULL,
  `tipo_cambio` decimal(18,6) NOT NULL DEFAULT '1.000000',
  `estado` enum('PENDIENTE','COMPLETADA','ANULADA') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'COMPLETADA',
  `observaciones` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_compra`),
  UNIQUE KEY `numero_factura` (`numero_factura`),
  KEY `fk_compra_usuario` (`id_usuario`),
  KEY `fk_compra_moneda` (`id_moneda`),
  KEY `idx_compras_fecha` (`fecha`),
  KEY `idx_compras_proveedor` (`id_proveedor`),
  KEY `idx_compras_estado` (`estado`)
) ;

--
-- Volcado de datos para la tabla `compras`
--

INSERT INTO `compras` (`id_compra`, `numero_factura`, `id_proveedor`, `id_usuario`, `fecha`, `subtotal`, `descuento`, `impuesto`, `total`, `id_moneda`, `tipo_cambio`, `estado`, `observaciones`) VALUES
(1, '44567777', 3, 1, '2026-08-20 16:32:29', 62.00, 0.00, 0.00, 62.00, 1, 1.000000, 'COMPLETADA', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `configuracion_empresa`
--

DROP TABLE IF EXISTS `configuracion_empresa`;
CREATE TABLE IF NOT EXISTS `configuracion_empresa` (
  `id_configuracion` int NOT NULL AUTO_INCREMENT,
  `razon_social` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `nombre_comercial` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tipo_identificacion_fiscal` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NIT',
  `identificacion_fiscal` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `direccion_fiscal` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `telefono` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `correo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `logotipo` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolucion_fiscal` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `fecha_resolucion` date DEFAULT NULL,
  `fecha_vencimiento_resolucion` date DEFAULT NULL,
  `prefijo_factura` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'F-',
  `numero_inicial` int NOT NULL DEFAULT '1',
  `numero_actual` int NOT NULL DEFAULT '1',
  `numero_final` int DEFAULT NULL,
  `id_moneda_predeterminada` int DEFAULT NULL,
  `decimales` int NOT NULL DEFAULT '2',
  `dias_credito` int NOT NULL DEFAULT '0',
  `formas_pago_habituales` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `forma_pago_predeterminada` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `impuesto_general` decimal(5,2) NOT NULL DEFAULT '0.00',
  `retencion` decimal(5,2) NOT NULL DEFAULT '0.00',
  `impuesto_local` decimal(5,2) NOT NULL DEFAULT '0.00',
  `regimen_fiscal` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cuenta_ventas` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cuenta_compras` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cuenta_impuestos` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cuenta_retenciones` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `entorno` enum('PRUEBAS','PRODUCCION') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PRUEBAS',
  `fecha_actualizacion` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_configuracion`),
  KEY `fk_configuracion_moneda` (`id_moneda_predeterminada`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `configuracion_empresa`
--

INSERT INTO `configuracion_empresa` (`id_configuracion`, `razon_social`, `nombre_comercial`, `tipo_identificacion_fiscal`, `identificacion_fiscal`, `direccion_fiscal`, `telefono`, `correo`, `logotipo`, `resolucion_fiscal`, `fecha_resolucion`, `fecha_vencimiento_resolucion`, `prefijo_factura`, `numero_inicial`, `numero_actual`, `numero_final`, `id_moneda_predeterminada`, `decimales`, `dias_credito`, `formas_pago_habituales`, `forma_pago_predeterminada`, `impuesto_general`, `retencion`, `impuesto_local`, `regimen_fiscal`, `cuenta_ventas`, `cuenta_compras`, `cuenta_impuestos`, `cuenta_retenciones`, `entorno`, `fecha_actualizacion`) VALUES
(1, 'Comercializadora Nexora, C.A.', 'Nexora', 'RIF', 'J-31234567-0', 'Av. Principal Los Robles, Edificio Nova, Local 12, San Cristóbal, Táchira, Venezuela', '+58 276-555-1842', 'Nexora@gmail.com', 'uploads/company/company_logo_2d32af6df660e13b422acaabc56ec84c.jpg', '000123', '2026-08-18', '2026-08-30', 'F-AC', 1, 1, 5000, 1, 2, 30, '', '', 0.00, 0.00, 0.00, '', '', '', '', '', 'PRODUCCION', '2026-08-18 15:38:04');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_compras`
--

DROP TABLE IF EXISTS `detalle_compras`;
CREATE TABLE IF NOT EXISTS `detalle_compras` (
  `id_detalle_compra` int NOT NULL AUTO_INCREMENT,
  `id_compra` int NOT NULL,
  `id_producto` int NOT NULL,
  `cantidad` decimal(12,3) NOT NULL,
  `precio_unitario` decimal(12,2) NOT NULL,
  `descuento` decimal(12,2) NOT NULL DEFAULT '0.00',
  `subtotal` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id_detalle_compra`),
  KEY `idx_detalle_compras_compra` (`id_compra`),
  KEY `idx_detalle_compras_producto` (`id_producto`)
) ;

--
-- Volcado de datos para la tabla `detalle_compras`
--

INSERT INTO `detalle_compras` (`id_detalle_compra`, `id_compra`, `id_producto`, `cantidad`, `precio_unitario`, `descuento`, `subtotal`) VALUES
(1, 1, 3, 4.000, 3.00, 0.00, 12.00),
(2, 1, 6, 2.000, 3.00, 0.00, 6.00),
(3, 1, 5, 7.000, 2.00, 0.00, 14.00),
(4, 1, 9, 10.000, 3.00, 0.00, 30.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_ventas`
--

DROP TABLE IF EXISTS `detalle_ventas`;
CREATE TABLE IF NOT EXISTS `detalle_ventas` (
  `id_detalle_venta` int NOT NULL AUTO_INCREMENT,
  `id_venta` int NOT NULL,
  `id_producto` int NOT NULL,
  `cantidad` decimal(12,3) NOT NULL,
  `precio_unitario` decimal(12,2) NOT NULL,
  `costo_unitario` decimal(12,2) NOT NULL,
  `descuento` decimal(12,2) NOT NULL DEFAULT '0.00',
  `subtotal` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id_detalle_venta`),
  KEY `idx_detalle_ventas_venta` (`id_venta`),
  KEY `idx_detalle_ventas_producto` (`id_producto`)
) ;

--
-- Volcado de datos para la tabla `detalle_ventas`
--

INSERT INTO `detalle_ventas` (`id_detalle_venta`, `id_venta`, `id_producto`, `cantidad`, `precio_unitario`, `costo_unitario`, `descuento`, `subtotal`) VALUES
(1, 1, 3, 5.000, 7.00, 3.00, 0.00, 35.00),
(2, 1, 1, 7.000, 6.00, 2.00, 0.00, 42.00),
(3, 1, 5, 5.000, 5.00, 2.00, 0.00, 25.00),
(4, 1, 7, 9.000, 4.00, 1.00, 0.00, 36.00),
(5, 1, 6, 5.000, 6.00, 3.00, 0.00, 30.00),
(6, 2, 3, 1.000, 7.00, 3.00, 0.00, 7.00),
(7, 3, 3, 5.000, 7.00, 3.00, 0.00, 35.00),
(8, 4, 3, 5.000, 7.00, 3.00, 0.00, 35.00),
(9, 5, 3, 1.000, 7.00, 3.00, 0.00, 7.00),
(10, 5, 1, 1.000, 6.00, 2.00, 0.00, 6.00),
(11, 5, 6, 1.000, 6.00, 3.00, 0.00, 6.00),
(12, 5, 5, 1.000, 5.00, 2.00, 0.00, 5.00),
(16, 6, 1, 1.000, 6.00, 2.00, 0.00, 6.00),
(17, 6, 6, 1.000, 6.00, 3.00, 0.00, 6.00),
(18, 6, 3, 1.000, 7.00, 3.00, 0.00, 7.00),
(19, 7, 12, 1.000, 10.00, 6.00, 0.00, 10.00),
(20, 9, 12, 6.000, 10.00, 6.00, 0.00, 60.00),
(21, 10, 3, 2.000, 7.00, 3.00, 0.00, 14.00),
(22, 10, 12, 5.000, 10.00, 6.00, 0.00, 50.00),
(23, 11, 12, 1.000, 10.00, 6.00, 0.00, 10.00),
(24, 11, 2, 1.000, 6.00, 3.00, 0.00, 6.00),
(25, 11, 8, 1.000, 6.00, 3.00, 0.00, 6.00),
(26, 12, 6, 2.000, 6.00, 3.00, 0.00, 12.00),
(27, 12, 7, 1.000, 4.00, 1.00, 0.00, 4.00),
(28, 12, 4, 4.000, 5.00, 2.00, 0.00, 20.00),
(29, 12, 5, 3.000, 5.00, 2.00, 0.00, 15.00),
(30, 13, 5, 4.000, 5.00, 2.00, 0.00, 20.00),
(31, 13, 8, 4.000, 6.00, 3.00, 0.00, 24.00),
(32, 13, 5, 4.000, 5.00, 2.00, 0.00, 20.00),
(33, 13, 9, 3.000, 4.00, 3.00, 0.00, 12.00),
(34, 14, 9, 4.000, 4.00, 3.00, 0.00, 16.00),
(35, 14, 8, 3.000, 6.00, 3.00, 0.00, 18.00),
(36, 14, 6, 2.000, 6.00, 3.00, 0.00, 12.00),
(37, 14, 12, 2.000, 10.00, 6.00, 0.00, 20.00),
(38, 15, 10, 1.000, 3.00, 2.00, 0.00, 3.00),
(39, 15, 6, 1.000, 6.00, 3.00, 0.00, 6.00),
(40, 15, 2, 1.000, 6.00, 3.00, 0.00, 6.00),
(41, 16, 10, 3.000, 3.00, 2.00, 0.00, 9.00),
(42, 16, 6, 1.000, 6.00, 3.00, 0.00, 6.00),
(43, 16, 11, 3.000, 5.00, 2.00, 0.00, 15.00),
(44, 16, 8, 2.000, 6.00, 3.00, 0.00, 12.00),
(45, 17, 10, 4.000, 3.00, 2.00, 0.00, 12.00),
(46, 18, 5, 3.000, 5.00, 2.00, 0.00, 15.00),
(47, 19, 3, 2.000, 7.00, 3.00, 0.00, 14.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `metodos_pago`
--

DROP TABLE IF EXISTS `metodos_pago`;
CREATE TABLE IF NOT EXISTS `metodos_pago` (
  `id_metodo_pago` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_pago` enum('EFECTIVO','TRANSFERENCIA','TARJETA','OTRO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'EFECTIVO',
  `id_moneda` int NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `fecha_creacion` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_metodo_pago`),
  UNIQUE KEY `uq_metodo_moneda` (`nombre`,`id_moneda`),
  KEY `fk_metodo_moneda` (`id_moneda`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `metodos_pago`
--

INSERT INTO `metodos_pago` (`id_metodo_pago`, `nombre`, `tipo_pago`, `id_moneda`, `activo`, `fecha_creacion`) VALUES
(1, 'Efectivo USD', 'EFECTIVO', 1, 1, '2026-08-12 14:37:35'),
(2, 'Transferencia USD', 'TRANSFERENCIA', 1, 1, '2026-08-12 14:37:35'),
(3, 'Tarjeta USD', 'TARJETA', 1, 1, '2026-08-12 14:37:35'),
(4, 'Efectivo EUR', 'EFECTIVO', 2, 0, '2026-08-12 14:37:35'),
(5, 'Efectivo VES', 'EFECTIVO', 3, 1, '2026-08-12 14:37:35'),
(6, 'Transferencia VES', 'TRANSFERENCIA', 3, 1, '2026-08-12 14:37:35'),
(7, 'Efectivo', 'EFECTIVO', 4, 0, '2026-08-17 22:29:15'),
(8, 'Pesos en Efectivo', 'EFECTIVO', 4, 1, '2026-08-17 22:29:31');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `monedas`
--

DROP TABLE IF EXISTS `monedas`;
CREATE TABLE IF NOT EXISTS `monedas` (
  `id_moneda` int NOT NULL AUTO_INCREMENT,
  `codigo` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `simbolo` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tasa_referencia` decimal(18,6) NOT NULL DEFAULT '1.000000',
  `es_moneda_base` tinyint(1) NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `fecha_creacion` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_moneda`),
  UNIQUE KEY `codigo` (`codigo`)
) ;

--
-- Volcado de datos para la tabla `monedas`
--

INSERT INTO `monedas` (`id_moneda`, `codigo`, `nombre`, `simbolo`, `tasa_referencia`, `es_moneda_base`, `activo`, `fecha_creacion`) VALUES
(1, 'USD', 'Dólar estadounidense', '$', 1.000000, 1, 1, '2026-08-12 14:37:35'),
(2, 'EUR', 'Euro', '€', 1.000000, 0, 0, '2026-08-12 14:37:35'),
(3, 'VES', 'Bolívar venezolano', 'Bs.', 0.002000, 0, 1, '2026-08-12 14:37:35'),
(4, 'COP', 'Peso colombiano', '$', 0.000286, 0, 1, '2026-08-12 14:37:35'),
(5, 'CAD', 'Dólar canadiense', 'C$', 1.000000, 0, 0, '2026-08-12 14:37:35'),
(6, 'COD', 'pesos colombianos', '$', 0.000286, 0, 0, '2026-08-17 22:28:49');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimientos_inventario`
--

DROP TABLE IF EXISTS `movimientos_inventario`;
CREATE TABLE IF NOT EXISTS `movimientos_inventario` (
  `id_movimiento` int NOT NULL AUTO_INCREMENT,
  `id_producto` int NOT NULL,
  `tipo_movimiento` enum('ENTRADA_COMPRA','SALIDA_VENTA','ENTRADA_DEVOLUCION','SALIDA_DEVOLUCION','AJUSTE_ENTRADA','AJUSTE_SALIDA') COLLATE utf8mb4_unicode_ci NOT NULL,
  `cantidad` decimal(12,3) NOT NULL,
  `stock_anterior` decimal(12,3) NOT NULL,
  `stock_nuevo` decimal(12,3) NOT NULL,
  `costo_unitario` decimal(12,2) NOT NULL DEFAULT '0.00',
  `id_compra` int DEFAULT NULL,
  `id_detalle_compra` int DEFAULT NULL,
  `id_venta` int DEFAULT NULL,
  `id_detalle_venta` int DEFAULT NULL,
  `id_usuario` int NOT NULL,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `observaciones` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_movimiento`),
  KEY `fk_mov_compra` (`id_compra`),
  KEY `fk_mov_detalle_compra` (`id_detalle_compra`),
  KEY `fk_mov_venta` (`id_venta`),
  KEY `fk_mov_detalle_venta` (`id_detalle_venta`),
  KEY `fk_mov_usuario` (`id_usuario`),
  KEY `idx_mov_producto_fecha` (`id_producto`,`fecha`),
  KEY `idx_mov_tipo` (`tipo_movimiento`)
) ;

--
-- Volcado de datos para la tabla `movimientos_inventario`
--

INSERT INTO `movimientos_inventario` (`id_movimiento`, `id_producto`, `tipo_movimiento`, `cantidad`, `stock_anterior`, `stock_nuevo`, `costo_unitario`, `id_compra`, `id_detalle_compra`, `id_venta`, `id_detalle_venta`, `id_usuario`, `fecha`, `observaciones`) VALUES
(1, 3, 'ENTRADA_COMPRA', 4.000, 18.000, 22.000, 3.00, 1, 1, NULL, NULL, 1, '2026-08-20 16:32:29', NULL),
(2, 6, 'ENTRADA_COMPRA', 2.000, 15.000, 17.000, 3.00, 1, 2, NULL, NULL, 1, '2026-08-20 16:32:29', NULL),
(3, 5, 'ENTRADA_COMPRA', 7.000, 20.000, 27.000, 2.00, 1, 3, NULL, NULL, 1, '2026-08-20 16:32:29', NULL),
(4, 9, 'ENTRADA_COMPRA', 10.000, 15.000, 25.000, 3.00, 1, 4, NULL, NULL, 1, '2026-08-20 16:32:29', NULL),
(5, 3, 'SALIDA_VENTA', 5.000, 22.000, 17.000, 3.00, NULL, NULL, 1, 1, 1, '2026-08-20 16:34:40', NULL),
(6, 1, 'SALIDA_VENTA', 7.000, 15.000, 8.000, 2.00, NULL, NULL, 1, 2, 1, '2026-08-20 16:34:40', NULL),
(7, 5, 'SALIDA_VENTA', 5.000, 27.000, 22.000, 2.00, NULL, NULL, 1, 3, 1, '2026-08-20 16:34:40', NULL),
(8, 7, 'SALIDA_VENTA', 9.000, 13.000, 4.000, 1.00, NULL, NULL, 1, 4, 1, '2026-08-20 16:34:40', NULL),
(9, 6, 'SALIDA_VENTA', 5.000, 17.000, 12.000, 3.00, NULL, NULL, 1, 5, 1, '2026-08-20 16:34:40', NULL),
(10, 3, 'SALIDA_VENTA', 1.000, 17.000, 16.000, 3.00, NULL, NULL, 2, 6, 1, '2026-08-23 11:34:50', NULL),
(11, 3, 'SALIDA_VENTA', 5.000, 16.000, 11.000, 3.00, NULL, NULL, 3, 7, 1, '2026-08-24 14:42:41', NULL),
(12, 3, 'SALIDA_VENTA', 5.000, 11.000, 6.000, 3.00, NULL, NULL, 4, 8, 1, '2026-08-24 15:32:36', NULL),
(13, 3, 'SALIDA_VENTA', 1.000, 6.000, 5.000, 3.00, NULL, NULL, 5, 9, 1, '2026-08-24 17:13:55', NULL),
(14, 1, 'SALIDA_VENTA', 1.000, 8.000, 7.000, 2.00, NULL, NULL, 5, 10, 1, '2026-08-24 17:13:55', NULL),
(15, 6, 'SALIDA_VENTA', 1.000, 12.000, 11.000, 3.00, NULL, NULL, 5, 11, 1, '2026-08-24 17:13:55', NULL),
(16, 5, 'SALIDA_VENTA', 1.000, 22.000, 21.000, 2.00, NULL, NULL, 5, 12, 1, '2026-08-24 17:13:55', NULL),
(17, 1, 'SALIDA_VENTA', 1.000, 7.000, 6.000, 2.00, NULL, NULL, 6, NULL, 1, '2026-08-24 17:14:45', NULL),
(18, 6, 'SALIDA_VENTA', 1.000, 11.000, 10.000, 3.00, NULL, NULL, 6, NULL, 1, '2026-08-24 17:14:45', NULL),
(19, 3, 'SALIDA_VENTA', 1.000, 5.000, 4.000, 3.00, NULL, NULL, 6, NULL, 1, '2026-08-24 17:14:45', NULL),
(20, 1, 'AJUSTE_ENTRADA', 1.000, 6.000, 7.000, 2.00, NULL, NULL, 6, NULL, 1, '2026-08-25 13:42:25', 'Edición de factura #6 (reverso de línea anterior)'),
(21, 6, 'AJUSTE_ENTRADA', 1.000, 10.000, 11.000, 3.00, NULL, NULL, 6, NULL, 1, '2026-08-25 13:42:25', 'Edición de factura #6 (reverso de línea anterior)'),
(22, 3, 'AJUSTE_ENTRADA', 1.000, 4.000, 5.000, 3.00, NULL, NULL, 6, NULL, 1, '2026-08-25 13:42:25', 'Edición de factura #6 (reverso de línea anterior)'),
(23, 1, 'AJUSTE_SALIDA', 1.000, 7.000, 6.000, 2.00, NULL, NULL, 6, 16, 1, '2026-08-25 13:42:25', 'Edición de factura #6 (nueva línea)'),
(24, 6, 'AJUSTE_SALIDA', 1.000, 11.000, 10.000, 3.00, NULL, NULL, 6, 17, 1, '2026-08-25 13:42:25', 'Edición de factura #6 (nueva línea)'),
(25, 3, 'AJUSTE_SALIDA', 1.000, 5.000, 4.000, 3.00, NULL, NULL, 6, 18, 1, '2026-08-25 13:42:25', 'Edición de factura #6 (nueva línea)'),
(26, 12, 'SALIDA_VENTA', 1.000, 15.000, 14.000, 6.00, NULL, NULL, 7, 19, 1, '2026-08-25 13:58:08', NULL),
(27, 12, 'SALIDA_VENTA', 6.000, 14.000, 8.000, 6.00, NULL, NULL, 9, 20, 2, '2026-08-25 14:08:14', NULL),
(28, 3, 'SALIDA_VENTA', 2.000, 4.000, 2.000, 3.00, NULL, NULL, 10, 21, 1, '2026-08-25 14:10:36', NULL),
(29, 12, 'SALIDA_VENTA', 5.000, 8.000, 3.000, 6.00, NULL, NULL, 10, 22, 1, '2026-08-25 14:10:36', NULL),
(30, 3, 'ENTRADA_DEVOLUCION', 2.000, 2.000, 4.000, 3.00, NULL, NULL, 10, 21, 1, '2026-08-25 14:10:57', 'Anulación de venta #10'),
(31, 12, 'ENTRADA_DEVOLUCION', 5.000, 3.000, 8.000, 6.00, NULL, NULL, 10, 22, 1, '2026-08-25 14:10:57', 'Anulación de venta #10'),
(32, 12, 'SALIDA_VENTA', 1.000, 8.000, 7.000, 6.00, NULL, NULL, 11, 23, 1, '2026-08-25 14:57:15', NULL),
(33, 2, 'SALIDA_VENTA', 1.000, 16.000, 15.000, 3.00, NULL, NULL, 11, 24, 1, '2026-08-25 14:57:15', NULL),
(34, 8, 'SALIDA_VENTA', 1.000, 17.000, 16.000, 3.00, NULL, NULL, 11, 25, 1, '2026-08-25 14:57:16', NULL),
(35, 6, 'SALIDA_VENTA', 2.000, 10.000, 8.000, 3.00, NULL, NULL, 12, 26, 1, '2026-08-25 14:58:03', NULL),
(36, 7, 'SALIDA_VENTA', 1.000, 4.000, 3.000, 1.00, NULL, NULL, 12, 27, 1, '2026-08-25 14:58:03', NULL),
(37, 4, 'SALIDA_VENTA', 4.000, 13.000, 9.000, 2.00, NULL, NULL, 12, 28, 1, '2026-08-25 14:58:03', NULL),
(38, 5, 'SALIDA_VENTA', 3.000, 21.000, 18.000, 2.00, NULL, NULL, 12, 29, 1, '2026-08-25 14:58:03', NULL),
(39, 5, 'SALIDA_VENTA', 4.000, 18.000, 14.000, 2.00, NULL, NULL, 13, 30, 1, '2026-08-25 14:59:44', NULL),
(40, 8, 'SALIDA_VENTA', 4.000, 16.000, 12.000, 3.00, NULL, NULL, 13, 31, 1, '2026-08-25 14:59:44', NULL),
(41, 5, 'SALIDA_VENTA', 4.000, 14.000, 10.000, 2.00, NULL, NULL, 13, 32, 1, '2026-08-25 14:59:44', NULL),
(42, 9, 'SALIDA_VENTA', 3.000, 25.000, 22.000, 3.00, NULL, NULL, 13, 33, 1, '2026-08-25 14:59:44', NULL),
(43, 9, 'SALIDA_VENTA', 4.000, 22.000, 18.000, 3.00, NULL, NULL, 14, 34, 1, '2026-08-25 15:03:14', NULL),
(44, 8, 'SALIDA_VENTA', 3.000, 12.000, 9.000, 3.00, NULL, NULL, 14, 35, 1, '2026-08-25 15:03:14', NULL),
(45, 6, 'SALIDA_VENTA', 2.000, 8.000, 6.000, 3.00, NULL, NULL, 14, 36, 1, '2026-08-25 15:03:14', NULL),
(46, 12, 'SALIDA_VENTA', 2.000, 7.000, 5.000, 6.00, NULL, NULL, 14, 37, 1, '2026-08-25 15:03:14', NULL),
(47, 10, 'SALIDA_VENTA', 1.000, 17.000, 16.000, 2.00, NULL, NULL, 15, 38, 1, '2026-08-25 15:04:51', NULL),
(48, 6, 'SALIDA_VENTA', 1.000, 6.000, 5.000, 3.00, NULL, NULL, 15, 39, 1, '2026-08-25 15:04:51', NULL),
(49, 2, 'SALIDA_VENTA', 1.000, 15.000, 14.000, 3.00, NULL, NULL, 15, 40, 1, '2026-08-25 15:04:51', NULL),
(50, 10, 'SALIDA_VENTA', 3.000, 16.000, 13.000, 2.00, NULL, NULL, 16, 41, 1, '2026-08-25 15:05:49', NULL),
(51, 6, 'SALIDA_VENTA', 1.000, 5.000, 4.000, 3.00, NULL, NULL, 16, 42, 1, '2026-08-25 15:05:49', NULL),
(52, 11, 'SALIDA_VENTA', 3.000, 15.000, 12.000, 2.00, NULL, NULL, 16, 43, 1, '2026-08-25 15:05:49', NULL),
(53, 8, 'SALIDA_VENTA', 2.000, 9.000, 7.000, 3.00, NULL, NULL, 16, 44, 1, '2026-08-25 15:05:49', NULL),
(54, 10, 'SALIDA_VENTA', 4.000, 13.000, 9.000, 2.00, NULL, NULL, 17, 45, 1, '2026-08-25 15:35:45', NULL),
(55, 5, 'SALIDA_VENTA', 3.000, 10.000, 7.000, 2.00, NULL, NULL, 18, 46, 1, '2026-08-25 15:36:10', NULL),
(56, 3, 'SALIDA_VENTA', 2.000, 4.000, 2.000, 3.00, NULL, NULL, 19, 47, 1, '2026-08-25 15:36:57', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos_ventas`
--

DROP TABLE IF EXISTS `pagos_ventas`;
CREATE TABLE IF NOT EXISTS `pagos_ventas` (
  `id_pago_venta` int NOT NULL AUTO_INCREMENT,
  `id_venta` int NOT NULL,
  `id_metodo_pago` int NOT NULL,
  `monto` decimal(12,2) NOT NULL,
  `tipo_cambio` decimal(18,6) NOT NULL DEFAULT '1.000000',
  `monto_moneda_base` decimal(12,2) NOT NULL,
  `referencia` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pago_venta`),
  KEY `fk_pago_venta_metodo` (`id_metodo_pago`),
  KEY `idx_pagos_ventas_venta` (`id_venta`)
) ;

--
-- Volcado de datos para la tabla `pagos_ventas`
--

INSERT INTO `pagos_ventas` (`id_pago_venta`, `id_venta`, `id_metodo_pago`, `monto`, `tipo_cambio`, `monto_moneda_base`, `referencia`, `fecha`) VALUES
(1, 1, 1, 168.00, 1.000000, 168.00, '', '2026-08-20 16:34:40'),
(2, 2, 8, 24475.52, 0.000286, 7.00, '', '2026-08-23 11:34:51'),
(3, 3, 1, 40.60, 1.000000, 40.60, '', '2026-08-24 14:42:41'),
(4, 4, 3, 35.00, 1.000000, 35.00, '', '2026-08-24 15:32:36'),
(5, 5, 3, 24.00, 1.000000, 24.00, '', '2026-08-24 17:13:55'),
(6, 6, 3, 19.00, 1.000000, 19.00, '', '2026-08-24 17:14:45'),
(7, 7, 1, 10.00, 1.000000, 10.00, '', '2026-08-25 13:58:08'),
(8, 9, 1, 60.00, 1.000000, 60.00, '', '2026-08-25 14:08:14'),
(9, 10, 1, 64.00, 1.000000, 64.00, '', '2026-08-25 14:10:36'),
(10, 11, 8, 76923.08, 0.000286, 22.00, '', '2026-08-25 14:57:16'),
(11, 12, 3, 51.00, 1.000000, 51.00, '', '2026-08-25 14:58:03'),
(12, 13, 8, 265734.27, 0.000286, 76.00, '', '2026-08-25 14:59:44'),
(13, 14, 2, 66.00, 1.000000, 66.00, '', '2026-08-25 15:03:14'),
(14, 15, 5, 7500.00, 0.002000, 15.00, '', '2026-08-25 15:04:51'),
(15, 16, 8, 146853.15, 0.000286, 42.00, '', '2026-08-25 15:05:49'),
(16, 17, 6, 6000.00, 0.002000, 12.00, '', '2026-08-25 15:35:45'),
(17, 18, 6, 7500.00, 0.002000, 15.00, '', '2026-08-25 15:36:10'),
(18, 19, 3, 14.00, 1.000000, 14.00, '', '2026-08-25 15:36:57');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

DROP TABLE IF EXISTS `productos`;
CREATE TABLE IF NOT EXISTS `productos` (
  `id_producto` int NOT NULL AUTO_INCREMENT,
  `id_categoria` int DEFAULT NULL,
  `codigo` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `imagen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `precio_compra` decimal(12,2) NOT NULL DEFAULT '0.00',
  `precio_venta` decimal(12,2) NOT NULL DEFAULT '0.00',
  `costo_promedio` decimal(12,2) NOT NULL DEFAULT '0.00',
  `stock_actual` decimal(12,3) NOT NULL DEFAULT '0.000',
  `stock_minimo` decimal(12,3) NOT NULL DEFAULT '0.000',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `fecha_creacion` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_producto`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `fk_producto_categoria` (`id_categoria`)
) ;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id_producto`, `id_categoria`, `codigo`, `nombre`, `imagen`, `descripcion`, `precio_compra`, `precio_venta`, `costo_promedio`, `stock_actual`, `stock_minimo`, `activo`, `fecha_creacion`) VALUES
(1, 5, '7591473005362', 'Arroz Mary', NULL, NULL, 2.00, 6.00, 2.00, 6.000, 3.000, 1, '2026-08-20 16:17:52'),
(2, 5, 'MP016', 'Harina Pan', NULL, NULL, 3.00, 6.00, 3.00, 14.000, 3.000, 1, '2026-08-20 16:18:21'),
(3, 5, '7591473005393', 'Harina Mary', NULL, NULL, 3.00, 7.00, 3.00, 2.000, 3.000, 1, '2026-08-20 16:18:49'),
(4, 5, 'MP003', 'Pasta Capri', NULL, NULL, 2.00, 5.00, 2.00, 9.000, 3.000, 1, '2026-08-20 16:19:51'),
(5, 5, 'MP005', 'Atún Eveba', NULL, NULL, 2.00, 5.00, 2.00, 7.000, 3.000, 1, '2026-08-20 16:20:24'),
(6, 5, 'MP015', 'Leche La Campiña', NULL, NULL, 3.00, 6.00, 3.00, 4.000, 4.000, 1, '2026-08-20 16:21:25'),
(7, 5, 'MP017', 'Café Fama de América', NULL, NULL, 1.00, 4.00, 1.00, 3.000, 4.000, 1, '2026-08-20 16:22:08'),
(8, 5, 'MP020', 'Mantequilla Mavesa', NULL, NULL, 3.00, 6.00, 3.00, 7.000, 4.000, 1, '2026-08-20 16:22:41'),
(9, 5, 'MP021', 'Salsa de Tomate Pampero', NULL, NULL, 3.00, 4.00, 3.00, 18.000, 4.000, 1, '2026-08-20 16:23:27'),
(10, 5, 'MP022', 'Mayonesa Kraft', NULL, NULL, 2.00, 3.00, 2.00, 9.000, 5.000, 1, '2026-08-20 16:24:06'),
(11, 5, 'MP0222', 'Queso Parmesano', NULL, NULL, 2.00, 5.00, 2.00, 12.000, 4.000, 1, '2026-08-23 11:43:08'),
(12, 1, '849439001949', 'bluetooth', NULL, NULL, 6.00, 10.00, 6.00, 5.000, 3.000, 1, '2026-08-24 11:31:42');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
CREATE TABLE IF NOT EXISTS `proveedores` (
  `id_proveedor` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documento` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `correo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contacto` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `fecha_creacion` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proveedor`),
  KEY `idx_proveedores_nombre` (`nombre`),
  KEY `idx_proveedores_documento` (`documento`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`id_proveedor`, `nombre`, `documento`, `telefono`, `correo`, `direccion`, `contacto`, `activo`, `fecha_creacion`) VALUES
(1, 'Jose Perez', '31031245', '04267348845', 'joseperez@gmail.com', 'La Esperanza', NULL, 1, '2026-08-20 16:16:02'),
(2, 'Maria Gomez', '17345678', '04124567823', 'mariagomez00@gmail.com', 'La San Juana', NULL, 1, '2026-08-20 16:16:54'),
(3, 'Carlos Mendoza', '18452109', '04143582194', 'carlosmendoza@gmail.com', '', NULL, 1, '2026-08-20 16:25:31'),
(4, 'Alejandro Benitez', '22104567', '04129843105', 'alejandrobenitez3@gmail.com', '', NULL, 1, '2026-08-20 16:26:34');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respaldos`
--

DROP TABLE IF EXISTS `respaldos`;
CREATE TABLE IF NOT EXISTS `respaldos` (
  `id_respaldo` int NOT NULL AUTO_INCREMENT,
  `nombre_archivo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ruta_archivo` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tipo` enum('MANUAL','AUTOMATICO') COLLATE utf8mb4_unicode_ci NOT NULL,
  `tamano` bigint DEFAULT NULL,
  `estado` enum('EXITOSO','FALLIDO') COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_usuario` int DEFAULT NULL,
  PRIMARY KEY (`id_respaldo`),
  KEY `fk_respaldo_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id_rol` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_rol`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id_rol`, `nombre`, `descripcion`, `activo`) VALUES
(1, 'Administrador', 'Acceso completo al sistema', 1),
(4, 'Vendedor TPV', 'Acceso único al Punto de Venta (TPV)', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `id_rol` int NOT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `fecha_creacion` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `usuario` (`usuario`),
  KEY `fk_usuario_rol` (`id_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `id_rol`, `nombre`, `usuario`, `password`, `activo`, `fecha_creacion`) VALUES
(1, 1, 'arianna', 'ari', '$2y$10$7WSe8i60YujLEX2i3DLPc.sWkgLPqXCsdzaMLPpFBZTjBO7ZLP9UW', 1, '2026-08-12 16:55:25'),
(2, 4, 'arianna', 'katherin', '$2y$10$izVt1EAonKjvFTPMDmByv.Ievq6AyvG0T17BKs3NOqbTrIZiXJGEO', 1, '2026-08-17 22:12:37'),
(4, 4, 'marco', 'marco', '$2y$10$/k/lxKFuWYeC32HiBi98fegHgPG7JM/FdiW1scpNT0nmOPT9KiIOW', 1, '2026-08-25 10:24:55'),
(6, 1, 'maria', 'maria', '$2y$10$Amz2lgiflJ13geyWUFv5iObVC43.sR0iCTNbF/gUHfANxDWzTCDr2', 1, '2026-08-25 10:42:23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

DROP TABLE IF EXISTS `ventas`;
CREATE TABLE IF NOT EXISTS `ventas` (
  `id_venta` int NOT NULL AUTO_INCREMENT,
  `numero_factura` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_cliente` int DEFAULT NULL,
  `id_usuario` int NOT NULL,
  `id_caja` int DEFAULT NULL,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `descuento` decimal(12,2) NOT NULL DEFAULT '0.00',
  `impuesto` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `id_moneda` int NOT NULL,
  `tasas_cambio` text COLLATE utf8mb4_unicode_ci,
  `tipo_cambio` decimal(18,6) NOT NULL DEFAULT '1.000000',
  `estado` enum('PENDIENTE','COMPLETADA','ANULADA') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'COMPLETADA',
  `origen` enum('VENTA','TPV') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'VENTA',
  `observaciones` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_venta`),
  UNIQUE KEY `numero_factura` (`numero_factura`),
  KEY `fk_venta_usuario` (`id_usuario`),
  KEY `fk_venta_moneda` (`id_moneda`),
  KEY `idx_ventas_fecha` (`fecha`),
  KEY `idx_ventas_cliente` (`id_cliente`),
  KEY `idx_ventas_estado` (`estado`),
  KEY `idx_ventas_origen` (`origen`),
  KEY `fk_ventas_caja` (`id_caja`)
) ;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id_venta`, `numero_factura`, `id_cliente`, `id_usuario`, `id_caja`, `fecha`, `subtotal`, `descuento`, `impuesto`, `total`, `id_moneda`, `tasas_cambio`, `tipo_cambio`, `estado`, `origen`, `observaciones`) VALUES
(1, 'F-20260820163440-92', 5, 1, NULL, '2026-08-20 16:34:40', 168.00, 0.00, 0.00, 168.00, 1, '{\"USD\":1,\"VES\":0.002,\"COP\":0.000286}', 1.000000, 'COMPLETADA', 'VENTA', NULL),
(2, 'F-20260823113450-62', 5, 1, NULL, '2026-08-23 11:34:50', 7.00, 0.00, 0.00, 7.00, 1, '{\"USD\":1,\"VES\":0.002,\"COP\":0.000286}', 1.000000, 'COMPLETADA', 'VENTA', NULL),
(3, 'F-20260824144241-34', 5, 1, NULL, '2026-08-24 14:42:41', 35.00, 0.00, 5.60, 40.60, 1, '{\"USD\":1,\"VES\":0.002,\"COP\":0.000286}', 1.000000, 'COMPLETADA', 'VENTA', NULL),
(4, 'F-20260824153236-49', 3, 1, NULL, '2026-08-24 15:32:36', 35.00, 0.00, 0.00, 35.00, 1, '{\"USD\":1,\"VES\":0.002,\"COP\":0.000286}', 1.000000, 'COMPLETADA', 'VENTA', NULL),
(5, 'F-20260824171355-79', NULL, 1, NULL, '2026-08-24 17:13:55', 24.00, 0.00, 0.00, 24.00, 1, '{\"USD\":1,\"VES\":0.002,\"COP\":0.000286}', 1.000000, 'COMPLETADA', 'TPV', NULL),
(6, 'F-20260824171445-47', NULL, 1, NULL, '2026-08-24 17:14:45', 19.00, 0.00, 0.00, 19.00, 1, '{\"USD\":1,\"VES\":0.002,\"COP\":0.000286}', 1.000000, 'COMPLETADA', 'TPV', NULL),
(7, 'F-20260825135808-30', 3, 1, NULL, '2026-08-25 13:58:08', 10.00, 0.00, 0.00, 10.00, 1, '{\"USD\":1,\"VES\":0.002,\"COP\":0.000286}', 1.000000, 'COMPLETADA', 'TPV', NULL),
(9, 'F-20260825140814-31', NULL, 2, NULL, '2026-08-25 14:08:14', 60.00, 0.00, 0.00, 60.00, 1, '{\"USD\":1,\"VES\":0.002,\"COP\":0.000286}', 1.000000, 'COMPLETADA', 'TPV', NULL),
(10, 'F-20260825141036-80', 1, 1, NULL, '2026-08-25 14:10:36', 64.00, 0.00, 0.00, 64.00, 1, '{\"USD\":1,\"VES\":0.002,\"COP\":0.000286}', 1.000000, 'ANULADA', 'VENTA', NULL),
(11, 'F-20260825145715-59', 3, 1, 1, '2026-08-25 14:57:15', 22.00, 0.00, 0.00, 22.00, 1, '{\"USD\":1,\"VES\":0.002,\"COP\":0.000286}', 1.000000, 'COMPLETADA', 'VENTA', NULL),
(12, 'F-20260825145803-52', 1, 1, 1, '2026-08-25 14:58:03', 51.00, 0.00, 0.00, 51.00, 1, '{\"USD\":1,\"VES\":0.002,\"COP\":0.000286}', 1.000000, 'COMPLETADA', 'VENTA', NULL),
(13, 'F-20260825145944-47', 1, 1, 1, '2026-08-25 14:59:44', 76.00, 0.00, 0.00, 76.00, 1, '{\"USD\":1,\"VES\":0.002,\"COP\":0.000286}', 1.000000, 'COMPLETADA', 'VENTA', NULL),
(14, 'F-20260825150314-17', 4, 1, 1, '2026-08-25 15:03:14', 66.00, 0.00, 0.00, 66.00, 1, '{\"USD\":1,\"VES\":0.002,\"COP\":0.000286}', 1.000000, 'COMPLETADA', 'VENTA', NULL),
(15, 'F-20260825150451-67', 3, 1, 1, '2026-08-25 15:04:51', 15.00, 0.00, 0.00, 15.00, 1, '{\"USD\":1,\"VES\":0.002,\"COP\":0.000286}', 1.000000, 'COMPLETADA', 'VENTA', NULL),
(16, 'F-20260825150549-52', 4, 1, 1, '2026-08-25 15:05:49', 42.00, 0.00, 0.00, 42.00, 1, '{\"USD\":1,\"VES\":0.002,\"COP\":0.000286}', 1.000000, 'COMPLETADA', 'VENTA', NULL),
(17, 'F-20260825153545-28', NULL, 1, 2, '2026-08-25 15:35:45', 12.00, 0.00, 0.00, 12.00, 1, '{\"USD\":1,\"VES\":0.002,\"COP\":0.000286}', 1.000000, 'COMPLETADA', 'TPV', NULL),
(18, 'F-20260825153610-51', NULL, 1, 2, '2026-08-25 15:36:10', 15.00, 0.00, 0.00, 15.00, 1, '{\"USD\":1,\"VES\":0.002,\"COP\":0.000286}', 1.000000, 'COMPLETADA', 'TPV', NULL),
(19, 'F-20260825153657-71', NULL, 1, 2, '2026-08-25 15:36:57', 14.00, 0.00, 0.00, 14.00, 1, '{\"USD\":1,\"VES\":0.002,\"COP\":0.000286}', 1.000000, 'COMPLETADA', 'TPV', NULL);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_compras`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `vista_compras`;
CREATE TABLE IF NOT EXISTS `vista_compras` (
`id_compra` int
,`numero_factura` varchar(50)
,`fecha` datetime
,`proveedor` varchar(150)
,`moneda` varchar(10)
,`subtotal` decimal(12,2)
,`descuento` decimal(12,2)
,`impuesto` decimal(12,2)
,`total` decimal(12,2)
,`estado` enum('PENDIENTE','COMPLETADA','ANULADA')
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_ganancias_ventas`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `vista_ganancias_ventas`;
CREATE TABLE IF NOT EXISTS `vista_ganancias_ventas` (
`id_venta` int
,`numero_factura` varchar(50)
,`fecha` datetime
,`id_producto` int
,`codigo` varchar(50)
,`producto` varchar(150)
,`cantidad` decimal(12,3)
,`precio_unitario` decimal(12,2)
,`costo_unitario` decimal(12,2)
,`ganancia_bruta` decimal(25,5)
,`subtotal` decimal(12,2)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_inventario`
-- (Véase abajo para la vista actual)
--
DROP VIEW IF EXISTS `vista_inventario`;
CREATE TABLE IF NOT EXISTS `vista_inventario` (
`id_producto` int
,`codigo` varchar(50)
,`nombre` varchar(150)
,`categoria` varchar(100)
,`precio_compra` decimal(12,2)
,`precio_venta` decimal(12,2)
,`costo_promedio` decimal(12,2)
,`stock_actual` decimal(12,3)
,`stock_minimo` decimal(12,3)
,`estado_stock` varchar(10)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_compras`
--
DROP TABLE IF EXISTS `vista_compras`;

DROP VIEW IF EXISTS `vista_compras`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_compras`  AS SELECT `c`.`id_compra` AS `id_compra`, `c`.`numero_factura` AS `numero_factura`, `c`.`fecha` AS `fecha`, `pr`.`nombre` AS `proveedor`, `m`.`codigo` AS `moneda`, `c`.`subtotal` AS `subtotal`, `c`.`descuento` AS `descuento`, `c`.`impuesto` AS `impuesto`, `c`.`total` AS `total`, `c`.`estado` AS `estado` FROM ((`compras` `c` join `proveedores` `pr` on((`c`.`id_proveedor` = `pr`.`id_proveedor`))) join `monedas` `m` on((`c`.`id_moneda` = `m`.`id_moneda`))) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_ganancias_ventas`
--
DROP TABLE IF EXISTS `vista_ganancias_ventas`;

DROP VIEW IF EXISTS `vista_ganancias_ventas`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_ganancias_ventas`  AS SELECT `v`.`id_venta` AS `id_venta`, `v`.`numero_factura` AS `numero_factura`, `v`.`fecha` AS `fecha`, `p`.`id_producto` AS `id_producto`, `p`.`codigo` AS `codigo`, `p`.`nombre` AS `producto`, `dv`.`cantidad` AS `cantidad`, `dv`.`precio_unitario` AS `precio_unitario`, `dv`.`costo_unitario` AS `costo_unitario`, ((`dv`.`precio_unitario` - `dv`.`costo_unitario`) * `dv`.`cantidad`) AS `ganancia_bruta`, `dv`.`subtotal` AS `subtotal` FROM ((`ventas` `v` join `detalle_ventas` `dv` on((`v`.`id_venta` = `dv`.`id_venta`))) join `productos` `p` on((`dv`.`id_producto` = `p`.`id_producto`))) WHERE (`v`.`estado` = 'COMPLETADA') ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_inventario`
--
DROP TABLE IF EXISTS `vista_inventario`;

DROP VIEW IF EXISTS `vista_inventario`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_inventario`  AS SELECT `p`.`id_producto` AS `id_producto`, `p`.`codigo` AS `codigo`, `p`.`nombre` AS `nombre`, `c`.`nombre` AS `categoria`, `p`.`precio_compra` AS `precio_compra`, `p`.`precio_venta` AS `precio_venta`, `p`.`costo_promedio` AS `costo_promedio`, `p`.`stock_actual` AS `stock_actual`, `p`.`stock_minimo` AS `stock_minimo`, (case when (`p`.`stock_actual` = 0) then 'AGOTADO' when (`p`.`stock_actual` <= `p`.`stock_minimo`) then 'STOCK BAJO' else 'DISPONIBLE' end) AS `estado_stock` FROM (`productos` `p` left join `categorias` `c` on((`p`.`id_categoria` = `c`.`id_categoria`))) WHERE (`p`.`activo` = true) ;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `caja_montos`
--
ALTER TABLE `caja_montos`
  ADD CONSTRAINT `fk_montos_caja` FOREIGN KEY (`id_caja`) REFERENCES `caja_sesiones` (`id_caja`),
  ADD CONSTRAINT `fk_montos_moneda` FOREIGN KEY (`id_moneda`) REFERENCES `monedas` (`id_moneda`);

--
-- Filtros para la tabla `caja_movimientos`
--
ALTER TABLE `caja_movimientos`
  ADD CONSTRAINT `fk_cajamov_caja` FOREIGN KEY (`id_caja`) REFERENCES `caja_sesiones` (`id_caja`),
  ADD CONSTRAINT `fk_cajamov_moneda` FOREIGN KEY (`id_moneda`) REFERENCES `monedas` (`id_moneda`),
  ADD CONSTRAINT `fk_cajamov_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`);

--
-- Filtros para la tabla `caja_sesiones`
--
ALTER TABLE `caja_sesiones`
  ADD CONSTRAINT `fk_caja_usuario_apertura` FOREIGN KEY (`id_usuario_apertura`) REFERENCES `usuarios` (`id_usuario`),
  ADD CONSTRAINT `fk_caja_usuario_cierre` FOREIGN KEY (`id_usuario_cierre`) REFERENCES `usuarios` (`id_usuario`);

--
-- Filtros para la tabla `compras`
--
ALTER TABLE `compras`
  ADD CONSTRAINT `fk_compra_moneda` FOREIGN KEY (`id_moneda`) REFERENCES `monedas` (`id_moneda`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_compra_proveedor` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedores` (`id_proveedor`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_compra_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Filtros para la tabla `configuracion_empresa`
--
ALTER TABLE `configuracion_empresa`
  ADD CONSTRAINT `fk_configuracion_moneda` FOREIGN KEY (`id_moneda_predeterminada`) REFERENCES `monedas` (`id_moneda`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `detalle_compras`
--
ALTER TABLE `detalle_compras`
  ADD CONSTRAINT `fk_detalle_compra` FOREIGN KEY (`id_compra`) REFERENCES `compras` (`id_compra`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_detalle_compra_producto` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Filtros para la tabla `detalle_ventas`
--
ALTER TABLE `detalle_ventas`
  ADD CONSTRAINT `fk_detalle_venta` FOREIGN KEY (`id_venta`) REFERENCES `ventas` (`id_venta`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_detalle_venta_producto` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Filtros para la tabla `metodos_pago`
--
ALTER TABLE `metodos_pago`
  ADD CONSTRAINT `fk_metodo_moneda` FOREIGN KEY (`id_moneda`) REFERENCES `monedas` (`id_moneda`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Filtros para la tabla `movimientos_inventario`
--
ALTER TABLE `movimientos_inventario`
  ADD CONSTRAINT `fk_mov_compra` FOREIGN KEY (`id_compra`) REFERENCES `compras` (`id_compra`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_mov_detalle_compra` FOREIGN KEY (`id_detalle_compra`) REFERENCES `detalle_compras` (`id_detalle_compra`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_mov_detalle_venta` FOREIGN KEY (`id_detalle_venta`) REFERENCES `detalle_ventas` (`id_detalle_venta`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_mov_producto` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_mov_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_mov_venta` FOREIGN KEY (`id_venta`) REFERENCES `ventas` (`id_venta`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `pagos_ventas`
--
ALTER TABLE `pagos_ventas`
  ADD CONSTRAINT `fk_pago_venta` FOREIGN KEY (`id_venta`) REFERENCES `ventas` (`id_venta`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pago_venta_metodo` FOREIGN KEY (`id_metodo_pago`) REFERENCES `metodos_pago` (`id_metodo_pago`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `fk_producto_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id_categoria`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `respaldos`
--
ALTER TABLE `respaldos`
  ADD CONSTRAINT `fk_respaldo_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `fk_usuario_rol` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id_rol`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Filtros para la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD CONSTRAINT `fk_venta_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_venta_moneda` FOREIGN KEY (`id_moneda`) REFERENCES `monedas` (`id_moneda`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_venta_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_ventas_caja` FOREIGN KEY (`id_caja`) REFERENCES `caja_sesiones` (`id_caja`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
