<?php
define('DB_HOST', 'db');
define('DB_NAME', 'sistema_facturacion');
define('DB_USER', 'root');
define('DB_PASS', '');
define('APP_NAME', 'Mi Tienda');
date_default_timezone_set('America/Caracas');
