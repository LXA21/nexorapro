<?php

require_once __DIR__.'/functions.php';

require_login();

$id = (int)($_GET['id'] ?? 0);

$v = one("
    SELECT
        v.*,
        c.nombre AS cliente,
        m.codigo AS moneda,
        m.simbolo
    FROM ventas v
    LEFT JOIN clientes c ON c.id_cliente = v.id_cliente
    JOIN monedas m ON m.id_moneda = v.id_moneda
    WHERE v.id_venta = ?
", [$id]);

if (!$v) {
    http_response_code(404);
    exit('Venta no encontrada.');
}

$items = allrows("
    SELECT
        d.*,
        p.nombre
    FROM detalle_ventas d
    JOIN productos p ON p.id_producto = d.id_producto
    WHERE d.id_venta = ?
", [$id]);

$pagos = allrows("
    SELECT
        pg.*,
        mp.nombre AS metodo
    FROM pagos_ventas pg
    JOIN metodos_pago mp ON mp.id_metodo_pago = pg.id_metodo_pago
    WHERE pg.id_venta = ?
", [$id]);

$empresa = company_settings();

$usuario = one("SELECT nombre FROM usuarios WHERE id_usuario=?", [$v['id_usuario']]);

// Usa ?ancho=58 en la URL si tu impresora es de 58mm; por defecto 80mm.
$ancho = (($_GET['ancho'] ?? '80') === '58') ? '58' : '80';

?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Ticket <?=e($v['numero_factura'])?></title>
<style>
    * { box-sizing: border-box; }

    html, body {
        width: <?=$ancho?>mm;
        margin: 0 auto;
        padding: 3mm;
        color: #000;
        font-family: "Courier New", monospace;
        font-size: 11px;
        line-height: 1.35;
        background: #fff;
    }

    .center { text-align: center; }
    .right { text-align: right; }
    .bold { font-weight: 700; }

    .logo {
        max-width: 55mm;
        max-height: 20mm;
        margin: 0 auto 4px;
        display: block;
    }

    .divider {
        border-top: 1px dashed #000;
        margin: 6px 0;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    td {
        padding: 1px 0;
        vertical-align: top;
    }

    .pago-line {
        display: flex;
        justify-content: space-between;
    }

    .actions {
        margin-top: 14px;
        text-align: center;
    }

    .actions button {
        padding: 10px 18px;
        font-size: 14px;
        border: 1px solid #182238;
        background: #182238;
        color: #fff;
        border-radius: 6px;
        cursor: pointer;
    }

   @media print {

    .no-print {
        display: none !important;
    }

    @page {
        size: <?=$ancho?>mm auto;
        margin: 0;
    }

    html {
        width: <?=$ancho?>mm !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    body {
        width: <?=$ancho?>mm !important;
        max-width: <?=$ancho?>mm !important;
        margin: 0 !important;
        padding: 2mm !important;
        background: #fff !important;
        color: #000 !important;
    }
}
</style>
</head>
<body>

    <?php if (!empty($empresa['logotipo'])): ?>
        <img src="<?=e($empresa['logotipo'])?>" class="logo">
    <?php endif; ?>

    <div class="center bold">
        <?=e($empresa['nombre_comercial'] ?: $empresa['razon_social'] ?: APP_NAME)?>
    </div>

    <?php if (!empty($empresa['identificacion_fiscal'])): ?>
        <div class="center"><?=e($empresa['tipo_identificacion_fiscal'].': '.$empresa['identificacion_fiscal'])?></div>
    <?php endif; ?>

    <?php if (!empty($empresa['direccion_fiscal'])): ?>
        <div class="center"><?=e($empresa['direccion_fiscal'])?></div>
    <?php endif; ?>

    <?php if (!empty($empresa['telefono'])): ?>
        <div class="center"><?=e($empresa['telefono'])?></div>
    <?php endif; ?>

    <div class="divider"></div>

    <div>Factura: <b><?=e($v['numero_factura'])?></b></div>
    <div>Fecha: <?=e(date('d/m/Y H:i', strtotime($v['fecha'])))?></div>
    <div>Cliente: <?=e($v['cliente'] ?: 'Consumidor final')?></div>
    <div>Atendido por: <?=e($usuario['nombre'] ?? '')?></div>

    <div class="divider"></div>

    <table>
        <?php foreach ($items as $it): ?>
            <tr>
                <td colspan="2"><?=e($it['nombre'])?></td>
            </tr>
            <tr>
                <td>
                    <?=e(rtrim(rtrim(number_format((float)$it['cantidad'], 3, '.', ''), '0'), '.'))?>
                    x <?=money($it['precio_unitario'], $v['simbolo'])?>
                </td>
                <td class="right"><?=money($it['subtotal'], $v['simbolo'])?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <div class="divider"></div>

    <table>
        <tr>
            <td>Subtotal</td>
            <td class="right"><?=money($v['subtotal'], $v['simbolo'])?></td>
        </tr>
        <?php if ((float)$v['impuesto'] > 0): ?>
        <tr>
            <td>Impuesto</td>
            <td class="right"><?=money($v['impuesto'], $v['simbolo'])?></td>
        </tr>
        <?php endif; ?>
        <tr>
            <td class="bold">TOTAL</td>
            <td class="right bold"><?=money($v['total'], $v['simbolo'])?></td>
        </tr>
    </table>

    <div class="divider"></div>

    <?php foreach ($pagos as $pg): ?>
        <div class="pago-line">
            <span><?=e($pg['metodo'])?></span>
            <span><?=money($pg['monto'], $v['simbolo'])?></span>
        </div>
    <?php endforeach; ?>

    <div class="divider"></div>

    <div class="center">¡Gracias por su compra!</div>

    <div class="actions no-print">
       <button
        type="button"
        onclick="window.print()"
    >
        Imprimir ticket
    </button>
</div>

</body>
</html>