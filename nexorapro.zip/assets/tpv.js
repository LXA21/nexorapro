(function () {

    var cart = [];
    var baseCurrency = window.tpvCurrency || { simbolo: '$', codigo: 'USD' };
    var currencies = window.tpvCurrencies || [];
    var html5QrCode = null;
    var searchTimer = null;


    /* -------------------------------------------------------
       FORMATO DE DINERO
       ------------------------------------------------------- */

    function fmtBase(v) {
        var n = parseFloat(v) || 0;
        return baseCurrency.simbolo + n.toFixed(2);
    }


    function fmtWith(symbol, v) {
        var n = parseFloat(v) || 0;
        return (symbol || '') + n.toFixed(2);
    }


    /* -------------------------------------------------------
       FORMATO DE CANTIDADES / STOCK
       -------------------------------------------------------
       Solo cambia la forma en que se muestra la cantidad.

       3.000  -> 3
       19.000 -> 19
       30.000 -> 30
       2.500  -> 2.5
       1.250  -> 1.25
       ------------------------------------------------------- */

    function fmtQuantity(v) {

        var n = parseFloat(v);

        if (!isFinite(n)) {
            return '0';
        }

        return n.toLocaleString('en-US', {
            minimumFractionDigits: 0,
            maximumFractionDigits: 3
        });

    }


    function showMsg(text, ok, duration) {
        var el = document.getElementById('tpvScanMsg');
        el.textContent = text;
        el.className = 'tpv-scan-msg ' + (ok ? 'ok' : 'err');
        clearTimeout(showMsg._t);
        showMsg._t = setTimeout(function () {
            el.textContent = '';
            el.className = 'tpv-scan-msg';
        }, duration || (ok ? 3000 : 8000));
    }


    // -------------------------------------------------------
    // CARRITO
    // -------------------------------------------------------

    function addToCart(p) {

        var existing = cart.find(function (i) {
            return i.id_producto == p.id_producto;
        });


        if (existing) {

            existing.cantidad += 1;

        } else {

            cart.push({
                id_producto: p.id_producto,
                codigo: p.codigo,
                nombre: p.nombre,
                precio_venta: parseFloat(p.precio_venta),
                stock_actual: parseFloat(p.stock_actual),
                cantidad: 1
            });

        }


        renderCart();

        showMsg(
            'Agregado: ' + p.nombre,
            true
        );

    }


    function renderCart() {

        var tbody =
            document.querySelector(
                '#tpvCartTable tbody'
            );


        tbody.innerHTML = '';


        cart.forEach(function (item, idx) {

            var subtotal =
                item.cantidad *
                item.precio_venta;


            var tr =
                document.createElement(
                    'tr'
                );


            tr.innerHTML =
                '<td>' +
                    item.nombre +
                '</td>' +

                '<td>' +
                    fmtBase(
                        item.precio_venta
                    ) +
                '</td>' +

                '<td>' +
                    '<input ' +
                        'type="number" ' +
                        'min="0.001" ' +
                        'step="0.001" ' +
                        'class="tpv-qty" ' +
                        'data-idx="' + idx + '" ' +
                        'value="' + item.cantidad + '" ' +
                        'style="width:70px"' +
                    '>' +
                '</td>' +

                '<td>' +
                    fmtBase(
                        subtotal
                    ) +
                '</td>' +

                '<td>' +
                    '<button ' +
                        'type="button" ' +
                        'class="btn danger sm tpv-remove" ' +
                        'data-idx="' + idx + '"' +
                    '>' +
                        '✕' +
                    '</button>' +
                '</td>';


            tbody.appendChild(
                tr
            );

        });


        calcTotal();

    }


    function getSubtotal() {

        return cart.reduce(
            function (s, i) {

                return s +
                    (
                        i.cantidad *
                        i.precio_venta
                    );

            },
            0
        );

    }


    function getTaxPercent() {

        var el =
            document.getElementById(
                'tpvTax'
            );


        return el
            ? (
                parseFloat(el.value) || 0
            )
            : 0;

    }


    function getTotal() {

        var subtotal =
            getSubtotal();


        var tax =
            subtotal *
            (
                getTaxPercent() /
                100
            );


        return subtotal + tax;

    }


    function calcTotal() {

        var subtotal =
            getSubtotal();


        var taxPercent =
            getTaxPercent();


        var tax =
            subtotal *
            (
                taxPercent /
                100
            );


        var total =
            subtotal + tax;


        var subtotalEl =
            document.getElementById(
                'tpvSubtotal'
            );


        if (subtotalEl) {

            subtotalEl.textContent =
                fmtBase(
                    subtotal
                );

        }


        var taxEl =
            document.getElementById(
                'tpvTaxAmount'
            );


        if (taxEl) {

            taxEl.textContent =
                fmtBase(
                    tax
                );

        }


        document.getElementById(
            'tpvTotal'
        ).textContent =
            fmtBase(
                total
            );


        renderConversions(
            total
        );


        updatePaymentAmountFromMethod(
            false
        );


        document.getElementById(
            'tpvSubmitBtn'
        ).disabled =
            cart.length === 0;

    }


    // -------------------------------------------------------
    // CONVERSIONES A OTRAS MONEDAS (informativo)
    // -------------------------------------------------------

    function renderConversions(
        totalBase
    ) {

        var container =
            document.getElementById(
                'tpvConversions'
            );


        var parts = [];


        currencies.forEach(
            function (c) {

                if (
                    Number(
                        c.es_moneda_base
                    ) === 1
                ) {
                    return;
                }


                var rate =
                    Number(
                        c.tasa_referencia || 0
                    );


                if (rate <= 0) {
                    return;
                }


                var converted =
                    totalBase / rate;


                parts.push(
                    '≈ ' +
                    (
                        c.simbolo || ''
                    ) +
                    converted.toLocaleString(
                        'en-US',
                        {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        }
                    ) +
                    ' ' +
                    c.codigo
                );

            }
        );


        container.textContent =
            parts.join(
                '   ·   '
            );

    }


    // -------------------------------------------------------
    // MÉTODO DE PAGO / CONVERSIÓN AUTOMÁTICA
    // -------------------------------------------------------

    var methodSelect =
        document.getElementById(
            'tpvPaymentMethod'
        );


    var rateInput =
        document.getElementById(
            'tpvPaymentRate'
        );


    var amountInput =
        document.getElementById(
            'tpvPaymentAmount'
        );


    var changeInput =
        document.getElementById(
            'tpvChange'
        );


    function currentMethodOption() {

        return methodSelect.options[
            methodSelect.selectedIndex
        ];

    }


    function updatePaymentAmountFromMethod(
        force
    ) {

        var opt =
            currentMethodOption();


        if (
            !opt ||
            !opt.dataset.tasa
        ) {
            return;
        }


        var tasa =
            Number(
                opt.dataset.tasa
            );


        if (tasa <= 0) {
            return;
        }


        rateInput.value =
            tasa;


        var total =
            getTotal();


        if (
            force ||
            !amountInput.dataset.touched
        ) {

            amountInput.value =
                (
                    total /
                    tasa
                ).toFixed(2);


            amountInput.dataset.touched =
                '';

        }


        updateChange();

    }


    function updateChange() {

        var opt =
            currentMethodOption();


        var symbol =
            (
                opt &&
                opt.dataset.simbolo
            ) ||
            baseCurrency.simbolo;


        var tasa =
            Number(
                (
                    opt &&
                    opt.dataset.tasa
                ) ||
                1
            ) || 1;


        var total =
            getTotal();


        var totalInMethodCurrency =
            total / tasa;


        var recibido =
            parseFloat(
                amountInput.value
            ) || 0;


        var cambio =
            recibido -
            totalInMethodCurrency;


        changeInput.value =
            fmtWith(
                symbol,
                cambio < 0
                    ? 0
                    : cambio
            );

    }


    methodSelect.addEventListener(
        'change',
        function () {

            updatePaymentAmountFromMethod(
                true
            );

        }
    );


    amountInput.addEventListener(
        'input',
        function () {

            this.dataset.touched =
                '1';


            updateChange();

        }
    );


    var taxInputEl =
        document.getElementById(
            'tpvTax'
        );


    if (taxInputEl) {

        taxInputEl.addEventListener(
            'input',
            function () {

                calcTotal();

            }
        );

    }


    // -------------------------------------------------------
    // ESCANEO POR TECLADO
    // -------------------------------------------------------

    var scanInput =
        document.getElementById(
            'tpvScanInput'
        );


    function searchAndAdd(code) {

        code =
            code.trim();


        if (!code) {
            return;
        }


        fetch(
            'tpv_search.php?codigo=' +
            encodeURIComponent(code)
        )
            .then(
                function (r) {
                    return r.json();
                }
            )
            .then(
                function (data) {

                    if (data.found) {

                        addToCart(
                            data.producto
                        );

                    } else {

                        showMsg(
                            '⚠ Código de barras inválido: "' +
                            code +
                            '" no corresponde a ningún producto registrado.',
                            false
                        );

                    }

                }
            )
            .catch(
                function () {

                    showMsg(
                        'Error al buscar el producto.',
                        false
                    );

                }
            );

    }


    scanInput.addEventListener(
        'keydown',
        function (e) {

            if (
                e.key === 'Enter'
            ) {

                e.preventDefault();


                searchAndAdd(
                    scanInput.value
                );


                scanInput.value =
                    '';

            }

        }
    );


    scanInput.focus();


    document.addEventListener(
        'click',
        function (e) {

            var tag =
                e.target.tagName;


            var isFormField =
                [
                    'INPUT',
                    'SELECT',
                    'BUTTON',
                    'TEXTAREA'
                ].indexOf(tag) !== -1;


            var insideSearch =
                e.target.closest(
                    '.tpv-search-wrap'
                );


            if (
                !isFormField &&
                !insideSearch
            ) {

                scanInput.focus();

            }

        }
    );


    // -------------------------------------------------------
    // BUSCADOR MANUAL DE PRODUCTOS
    // -------------------------------------------------------

    var searchInput =
        document.getElementById(
            'tpvSearchInput'
        );


    var searchResults =
        document.getElementById(
            'tpvSearchResults'
        );


    searchInput.addEventListener(
        'input',
        function () {

            var q =
                searchInput.value.trim();


            clearTimeout(
                searchTimer
            );


            if (!q) {

                searchResults.innerHTML =
                    '';

                searchResults.classList.remove(
                    'show'
                );

                return;

            }


            searchTimer =
                setTimeout(
                    function () {

                        fetch(
                            'tpv_search.php?q=' +
                            encodeURIComponent(q)
                        )
                            .then(
                                function (r) {
                                    return r.json();
                                }
                            )
                            .then(
                                function (data) {

                                    renderSearchResults(
                                        data.results || []
                                    );

                                }
                            );

                    },
                    250
                );

        }
    );


    // Al presionar Enter en el buscador (por ejemplo al escanear un
    // código de barras con un lector físico enfocado aquí, o al
    // escribir un nombre y querer tomar la primera coincidencia),
    // seleccionamos el producto de inmediato en lugar de obligar
    // a hacer clic en la sugerencia. Se cancela el debounce
    // pendiente y se hace una consulta inmediata: el endpoint ya
    // ordena primero por coincidencia EXACTA de código, así que si
    // el texto es un código de barras válido, el primer resultado
    // siempre será ese producto.

    searchInput.addEventListener(
        'keydown',
        function (e) {

            if (
                e.key !== 'Enter'
            ) {
                return;
            }


            e.preventDefault();


            var q =
                searchInput.value.trim();


            if (!q) {
                return;
            }


            clearTimeout(
                searchTimer
            );


            fetch(
                'tpv_search.php?q=' +
                encodeURIComponent(q)
            )
                .then(
                    function (r) {
                        return r.json();
                    }
                )
                .then(
                    function (data) {

                        var results =
                            data.results || [];


                        if (results.length) {

                            addToCart(
                                results[0]
                            );

                        } else {

                            showMsg(
                                '⚠ No se encontró ningún producto para: "' +
                                q +
                                '"',
                                false
                            );

                        }


                        searchInput.value =
                            '';

                        searchResults.innerHTML =
                            '';

                        searchResults.classList.remove(
                            'show'
                        );

                        scanInput.focus();

                    }
                )
                .catch(
                    function () {

                        showMsg(
                            'Error al buscar el producto.',
                            false
                        );

                    }
                );

        }
    );


    function renderSearchResults(
        results
    ) {

        if (!results.length) {

            searchResults.innerHTML =
                '<div class="tpv-search-empty">Sin resultados</div>';


            searchResults.classList.add(
                'show'
            );


            return;

        }


        searchResults.innerHTML =
            results.map(
                function (p) {

                    return (

                        '<div class="tpv-search-item" data-id="' +
                        p.id_producto +
                        '">' +

                        '<span class="tpv-search-name">' +
                        p.nombre +
                        '</span>' +

                        '<span class="tpv-search-meta">' +
                        p.codigo +
                        ' · ' +
                        fmtBase(
                            p.precio_venta
                        ) +
                        ' · stock ' +
                        fmtQuantity(
                            p.stock_actual
                        ) +
                        '</span>' +

                        '</div>'

                    );

                }
            ).join('');


        searchResults._data =
            results;


        searchResults.classList.add(
            'show'
        );

    }


    searchResults.addEventListener(
        'click',
        function (e) {

            var item =
                e.target.closest(
                    '.tpv-search-item'
                );


            if (!item) {
                return;
            }


            var id =
                item.dataset.id;


            var producto =
                (
                    searchResults._data ||
                    []
                ).find(
                    function (p) {

                        return String(
                            p.id_producto
                        ) === id;

                    }
                );


            if (producto) {

                addToCart(
                    producto
                );

            }


            searchInput.value =
                '';


            searchResults.innerHTML =
                '';


            searchResults.classList.remove(
                'show'
            );


            scanInput.focus();

        }
    );


    document.addEventListener(
        'click',
        function (e) {

            if (
                !e.target.closest(
                    '.tpv-search-wrap'
                )
            ) {

                searchResults.classList.remove(
                    'show'
                );

            }

        }
    );


    // -------------------------------------------------------
    // CARRITO: editar cantidad / eliminar
    // -------------------------------------------------------

    document
        .getElementById(
            'tpvCartTable'
        )
        .addEventListener(
            'input',
            function (e) {

                if (
                    e.target.classList.contains(
                        'tpv-qty'
                    )
                ) {

                    var idx =
                        e.target.dataset.idx;


                    var val =
                        parseFloat(
                            e.target.value
                        ) || 0;


                    cart[idx].cantidad =
                        val;


                    calcTotal();

                }

            }
        );


    document
        .getElementById(
            'tpvCartTable'
        )
        .addEventListener(
            'click',
            function (e) {

                var btn =
                    e.target.closest(
                        '.tpv-remove'
                    );


                if (btn) {

                    cart.splice(
                        btn.dataset.idx,
                        1
                    );


                    renderCart();

                }

            }
        );


    // -------------------------------------------------------
    // ENVÍO DEL FORMULARIO
    // -------------------------------------------------------

    document
        .getElementById(
            'tpvForm'
        )
        .addEventListener(
            'submit',
            function (e) {

                var form =
                    this;


                if (
                    cart.length === 0
                ) {

                    e.preventDefault();

                    return;

                }


                form
                    .querySelectorAll(
                        '.tpv-hidden-item'
                    )
                    .forEach(
                        function (el) {

                            el.remove();

                        }
                    );


                cart.forEach(
                    function (item) {

                        [
                            [
                                'product_id[]',
                                item.id_producto
                            ],

                            [
                                'quantity[]',
                                item.cantidad
                            ],

                            [
                                'price[]',
                                item.precio_venta
                            ]

                        ].forEach(
                            function (pair) {

                                var input =
                                    document.createElement(
                                        'input'
                                    );


                                input.type =
                                    'hidden';


                                input.className =
                                    'tpv-hidden-item';


                                input.name =
                                    pair[0];


                                input.value =
                                    pair[1];


                                form.appendChild(
                                    input
                                );

                            }
                        );

                    }
                );

            }
        );


    // -------------------------------------------------------
    // ESCANEO POR CÁMARA
    // -------------------------------------------------------

    var cameraBtn =
        document.getElementById(
            'tpvCameraBtn'
        );


    var cameraModal =
        document.getElementById(
            'tpvCameraModal'
        );


    var cameraClose =
        document.getElementById(
            'tpvCameraClose'
        );


    function stopCamera() {

        if (html5QrCode) {

            html5QrCode
                .stop()
                .then(
                    function () {

                        html5QrCode.clear();

                        html5QrCode =
                            null;

                    }
                )
                .catch(
                    function () {

                        html5QrCode =
                            null;

                    }
                );

        }

    }


    cameraBtn.addEventListener(
        'click',
        function () {

            // La librería se carga desde un CDN externo.
            // Si no hay internet o el CDN fue bloqueado,
            // Html5Qrcode no existe.

            if (
                typeof Html5Qrcode ===
                'undefined'
            ) {

                showMsg(
                    'No se pudo cargar el lector de cámara (sin conexión a internet o CDN bloqueado).',
                    false
                );

                return;

            }


            // La cámara requiere contexto seguro.

            if (
                !window.isSecureContext
            ) {

                showMsg(
                    'La cámara requiere HTTPS (o abrir el sistema desde "localhost"). Accede por http://localhost/... en este equipo, o configura HTTPS para usarla desde otros dispositivos.',
                    false
                );

                return;

            }


            cameraModal.classList.add(
                'show'
            );


            html5QrCode =
                new Html5Qrcode(
                    'tpvCameraReader',
                    {

                        formatsToSupport: [

                            Html5QrcodeSupportedFormats.EAN_13,
                            Html5QrcodeSupportedFormats.EAN_8,
                            Html5QrcodeSupportedFormats.CODE_128,
                            Html5QrcodeSupportedFormats.CODE_39,
                            Html5QrcodeSupportedFormats.UPC_A,
                            Html5QrcodeSupportedFormats.UPC_E,
                            Html5QrcodeSupportedFormats.QR_CODE

                        ],


                        experimentalFeatures: {

                            useBarCodeDetectorIfSupported:
                                true

                        },


                        verbose:
                            false

                    }
                );


            html5QrCode.start(

                {
                    facingMode:
                        'environment'
                },

                {
                    fps:
                        15,

                    qrbox: {
                        width:
                            300,

                        height:
                            160
                    }

                },

                function (
                    decodedText
                ) {

                    stopCamera();

                    cameraModal.classList.remove(
                        'show'
                    );

                    searchAndAdd(
                        decodedText
                    );

                },

                function () {
                    /* frame sin código detectado, se ignora */
                }

            )
                .catch(
                    function (err) {

                        console.error(
                            'Error al iniciar la cámara:',
                            err
                        );


                        showMsg(
                            'No se pudo acceder a la cámara. Verifica los permisos del navegador.',
                            false
                        );


                        cameraModal.classList.remove(
                            'show'
                        );

                    }
                );

        }
    );


    cameraClose.addEventListener(
        'click',
        function () {

            stopCamera();

            cameraModal.classList.remove(
                'show'
            );

        }
    );


    renderCart();

})();