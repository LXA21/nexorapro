/* =========================================================
   SISTEMA DE FACTURACIÓN
   BUSCADOR DE PRODUCTOS - VENTAS Y COMPRAS
   ========================================================= */

let productModalRow = null;
let productModalMode = 'sale';
let productModalInitialized = false;
let lastSaleTotal = 0;


/* =========================================================
   UTILIDADES
   ========================================================= */

function esc(value) {
    return String(value ?? '').replace(/[&<>"']/g, function (m) {
        return {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        }[m];
    });
}


function normalizeSearch(value) {
    return String(value ?? '')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .trim()
        .toLowerCase();
}


function fmt(value) {
    return '$' + Number(value || 0).toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}


/* =========================================================
   FORMATO DE CANTIDADES / STOCK
   =========================================================
   Solo modifica la forma visual en que se muestra
   una cantidad.

   Ejemplos:
   3.000  -> 3
   19.000 -> 19
   30.000 -> 30
   2.500  -> 2.5
   1.250  -> 1.25
   ========================================================= */

function fmtQuantity(value) {

    const number =
        Number(value || 0);


    if (!Number.isFinite(number)) {
        return '0';
    }


    return number.toLocaleString(
        'en-US',
        {
            minimumFractionDigits: 0,
            maximumFractionDigits: 3
        }
    );

}


/* =========================================================
   CREAR MODAL AUTOMÁTICAMENTE
   ========================================================= */

function ensureProductModal() {

    /* Si ya lo inicializamos una vez, no lo vuelvas a crear */
    if (productModalInitialized) {
        return;
    }

    /* IMPORTANTE:
       Elimina cualquier modal viejo o duplicado que venga
       de PHP (_footer.php, _header.php, index.php, etc.)
       para evitar que bloquee la creación del modal real
       y que sus clases/CSS no coincidan con style.css. */

    const oldModal = document.getElementById('productModal');

    if (oldModal) {

        oldModal.remove();

    }

    const modal = document.createElement('div');

    modal.id = 'productModal';
    modal.className = 'product-modal';
    modal.setAttribute('aria-hidden', 'true');

    modal.innerHTML = `

        <div class="product-modal-box">

            <div class="product-modal-header">

                <div class="product-modal-title-wrap">

                    <div class="product-modal-icon">
                        🔎
                    </div>

                    <div>

                        <h2 id="productModalTitle">
                            Seleccionar producto
                        </h2>

                        <p id="productModalSubtitle">
                            Busca el producto por nombre o código
                        </p>

                    </div>

                </div>

                <button
                    type="button"
                    id="productModalClose"
                    class="product-modal-close"
                    aria-label="Cerrar"
                    title="Cerrar"
                >
                    ×
                </button>

            </div>


            <div class="product-search">

                <div class="product-search-box">

                    <span class="product-search-icon">
                        🔍
                    </span>

                    <input
                        type="text"
                        id="productSearch"
                        autocomplete="off"
                        placeholder="Buscar por nombre o código..."
                    >

                    <button
                        type="button"
                        id="productSearchClear"
                        class="product-search-clear"
                        title="Limpiar búsqueda"
                    >
                        ×
                    </button>

                </div>


                <div class="product-search-meta">

                    <span>
                        Escribe para buscar
                    </span>

                    <span id="productResultCount">
                        0 productos
                    </span>

                </div>

            </div>


            <div
                id="productResults"
                class="product-results"
            ></div>

        </div>

    `;

    document.body.appendChild(modal);


    /* =====================================================
       CERRAR CON X
       ===================================================== */

    const closeButton =
        document.getElementById('productModalClose');

    if (closeButton) {

        closeButton.addEventListener('click', function (event) {

            event.preventDefault();
            event.stopPropagation();

            closeProductModal();

        });

    }


    /* =====================================================
       CERRAR HACIENDO CLIC EN EL FONDO
       ===================================================== */

    modal.addEventListener('click', function (event) {

        if (event.target === modal) {

            closeProductModal();

        }

    });


    /* =====================================================
       BUSCAR
       ===================================================== */

    const search =
        document.getElementById('productSearch');

    if (search) {

        search.addEventListener('input', function () {

            renderProductResults(this.value);

            updateSearchClear();

        });


        /* ENTER */

        search.addEventListener('keydown', function (event) {

            if (event.key !== 'Enter') {
                return;
            }

            event.preventDefault();

            const first =
                document.querySelector(
                    '#productResults .product-result'
                );

            if (first) {

                selectProductFromModal(
                    first.dataset.productId
                );

            }

        });

    }


    /* =====================================================
       LIMPIAR BÚSQUEDA
       ===================================================== */

    const clearButton =
        document.getElementById('productSearchClear');

    if (clearButton) {

        clearButton.addEventListener('click', function (event) {

            event.preventDefault();
            event.stopPropagation();

            if (search) {

                search.value = '';

                renderProductResults('');

                updateSearchClear();

                search.focus();

            }

        });

    }


    /* =====================================================
       ESC
       ===================================================== */

    document.addEventListener('keydown', function (event) {

        if (
            event.key === 'Escape' &&
            modal.getAttribute('aria-hidden') === 'false'
        ) {

            closeProductModal();

        }

    });


    /* =====================================================
       CLIC EN PRODUCTO
       ===================================================== */

    const results =
        document.getElementById('productResults');

    if (results) {

        results.addEventListener('click', function (event) {

            const product =
                event.target.closest('.product-result');

            if (!product) {
                return;
            }

            event.preventDefault();

            selectProductFromModal(
                product.dataset.productId
            );

        });

    }

    productModalInitialized = true;

}


/* =========================================================
   ABRIR MODAL
   ========================================================= */

function openProductModal(row, mode = 'sale') {

    if (!row) {

        console.error(
            'No se encontró la fila del producto.'
        );

        return;

    }


    /* Asegurar que exista el modal */

    ensureProductModal();


    const modal =
        document.getElementById('productModal');

    const search =
        document.getElementById('productSearch');


    if (!modal || !search) {

        console.error(
            'No se pudo crear el selector de productos.'
        );

        return;

    }


    /* Guardar fila */

    productModalRow = row;


    /* Guardar modo */

    productModalMode =
        mode === 'purchase'
            ? 'purchase'
            : 'sale';


    /* Limpiar búsqueda */

    search.value = '';


    /* Abrir */

    modal.setAttribute(
        'aria-hidden',
        'false'
    );


    modal.classList.add('show');


    document.body.classList.add(
        'product-modal-open'
    );


    /* Mostrar mensaje inicial */

    renderProductResults('');


    updateSearchClear();


    /* Enfocar */

    setTimeout(function () {

        search.focus();

    }, 50);

}


/* =========================================================
   CERRAR MODAL
   ========================================================= */

function closeProductModal() {

    const modal =
        document.getElementById('productModal');

    const search =
        document.getElementById('productSearch');

    const clear =
        document.getElementById('productSearchClear');


    if (search) {

        search.value = '';

        search.blur();

    }


    if (modal) {

        modal.classList.remove('show');

        modal.setAttribute(
            'aria-hidden',
            'true'
        );

    }


    if (clear) {

        clear.classList.remove(
            'visible'
        );

    }


    document.body.classList.remove(
        'product-modal-open'
    );


    /* IMPORTANTE:
       NO borrar la fila antes de terminar
       la selección. */

    productModalRow = null;

    productModalMode = 'sale';

}


/* =========================================================
   X DEL BUSCADOR
   ========================================================= */

function updateSearchClear() {

    const input =
        document.getElementById(
            'productSearch'
        );

    const clear =
        document.getElementById(
            'productSearchClear'
        );


    if (!input || !clear) {
        return;
    }


    if (input.value.trim() !== '') {

        clear.classList.add(
            'visible'
        );

    } else {

        clear.classList.remove(
            'visible'
        );

    }

}


/* =========================================================
   MOSTRAR RESULTADOS
   ========================================================= */

function renderProductResults(text = '') {

    const container =
        document.getElementById(
            'productResults'
        );


    const countElement =
        document.getElementById(
            'productResultCount'
        );


    if (!container) {
        return;
    }


    const products =
        Array.isArray(window.products)
            ? window.products
            : [];


    const search =
        normalizeSearch(text);


    /* =====================================================
       SIN TEXTO
       ===================================================== */

    if (!search) {

        container.innerHTML = `

            <div class="product-no-results">

                <div style="font-size:28px;margin-bottom:8px;">
                    
                </div>

                Escribe el nombre o código
                del producto que deseas buscar.

            </div>

        `;


        if (countElement) {

            countElement.textContent =
                products.length +
                (
                    products.length === 1
                        ? ' producto'
                        : ' productos'
                );

        }

        return;

    }


    /* =====================================================
       FILTRAR
       ===================================================== */

    const results =
        products.filter(function (product) {

            const codigo =
                normalizeSearch(
                    product.codigo
                );

            const nombre =
                normalizeSearch(
                    product.nombre
                );

            return (
                codigo.includes(search) ||
                nombre.includes(search)
            );

        });


    /* =====================================================
       CONTADOR
       ===================================================== */

    if (countElement) {

        countElement.textContent =
            results.length +
            (
                results.length === 1
                    ? ' resultado'
                    : ' resultados'
            );

    }


    /* =====================================================
       SIN RESULTADOS
       ===================================================== */

    if (!results.length) {

        container.innerHTML = `

            <div class="product-no-results">

                <div style="font-size:28px;margin-bottom:8px;">
                    📦
                </div>

                No se encontraron productos
                con esa búsqueda.

            </div>

        `;

        return;

    }


    /* =====================================================
       CREAR RESULTADOS
       ===================================================== */

    container.innerHTML =
        results.map(function (product) {

            const stock =
                Number(
                    product.stock || 0
                );


            let price = 0;

            let label = 'Precio';


            if (
                productModalMode ===
                'purchase'
            ) {

                price =
                    Number(
                        product.costo_promedio || 0
                    );

                label = 'Costo';

            } else {

                price =
                    Number(
                        product.precio_venta || 0
                    );

            }


            let imageHTML = '';


            if (product.imagen) {

                imageHTML = `

                    <img
                        src="${esc(product.imagen)}"
                        alt="${esc(product.nombre)}"
                        class="product-modal-image"
                    >

                `;

            } else {

                imageHTML = `

                    <div class="product-modal-image-placeholder">
                        📦
                    </div>

                `;

            }


            return `

                <button
                    type="button"
                    class="product-result"
                    data-product-id="${esc(product.id_producto)}"
                >

                    <div class="product-result-main">

                        <div class="product-result-image">

                            ${imageHTML}

                        </div>


                        <div class="product-result-content">

                            <div class="product-result-name">

                                ${esc(product.nombre)}

                            </div>


                            <div class="product-result-code">

                                Código:
                                ${esc(product.codigo)}

                            </div>


                            <div class="product-result-info">

                                <span class="product-result-stock">

                                    Stock:
                                    ${fmtQuantity(stock)}

                                </span>


                                <span class="product-result-price">

                                    ${label}:
                                    ${fmt(price)}

                                </span>

                            </div>

                        </div>

                    </div>

                </button>

            `;

        }).join('');

}


/* =========================================================
   SELECCIONAR PRODUCTO
   ========================================================= */

function selectProductFromModal(productId) {

    const products =
        Array.isArray(window.products)
            ? window.products
            : [];


    const product =
        products.find(function (p) {

            return Number(
                p.id_producto
            ) === Number(productId);

        });


    if (!product) {

        console.error(
            'Producto no encontrado:',
            productId
        );

        return;

    }


    if (!productModalRow) {

        console.error(
            'No existe una fila seleccionada.'
        );

        return;

    }


    /* =====================================================
       GUARDAR REFERENCIAS ANTES DE CERRAR
       ===================================================== */

    const row =
        productModalRow;

    const mode =
        productModalMode;


    /* =====================================================
       ID DEL PRODUCTO
       ===================================================== */

    const hidden =
        row.querySelector(
            '.product-id'
        );


    if (hidden) {

        hidden.value =
            product.id_producto;

    }


    /* =====================================================
       BOTÓN DE PRODUCTO
       ===================================================== */

    const button =
        row.querySelector(
            '.select-product-btn'
        );


    if (button) {

        button.classList.add(
            'has-product'
        );


        button.innerHTML = `

            <span class="selected-product">

                <strong>
                    ${esc(product.nombre)}
                </strong>

                <small>
                    Código: ${esc(product.codigo)}
                </small>

            </span>

            <span class="selected-product-arrow">
                ›
            </span>

        `;

    }


    /* =====================================================
       VENTA
       ===================================================== */

    if (mode === 'sale') {

        const stock =
            row.querySelector(
                '.stock'
            );


        const price =
            row.querySelector(
                '.price'
            );


        if (stock) {

            stock.textContent =
                fmtQuantity(
                    product.stock || 0
                );

            stock.classList.toggle(
                'low-stock',
                Number(product.stock || 0) <= 5
            );

        }


        if (price) {

            price.value =
                Number(
                    product.precio_venta || 0
                ).toFixed(2);

        }


        calcSale();

    }


    /* =====================================================
       COMPRA
       ===================================================== */

    if (mode === 'purchase') {

        const cost =
            row.querySelector(
                '.cost'
            );


        if (cost) {

            cost.value =
                Number(
                    product.costo_promedio || 0
                ).toFixed(2);

        }


        calcPurchase();

    }


    /* =====================================================
       CERRAR INMEDIATAMENTE
       ===================================================== */

    closeProductModal();

}


/* =========================================================
   VENTAS
   ========================================================= */

function addSaleRow() {

    const tbody =
        document.querySelector(
            '#saleTable tbody'
        );


    if (!tbody) {
        return;
    }


    const tr =
        document.createElement('tr');


    tr.innerHTML = `

        <td class="product-cell">

            <input
                type="hidden"
                name="product_id[]"
                class="product-id"
                value=""
            >

            <button
                type="button"
                class="select-product-btn"
            >

                <span class="product-placeholder">
                    Seleccionar producto
                </span>

            </button>

        </td>


        <td class="stock">
            -
        </td>


        <td>

            <input
                name="price[]"
                class="price"
                type="number"
                step="0.01"
                min="0"
                value="0"
            >

        </td>


        <td>

            <input
                name="quantity[]"
                class="qty"
                type="number"
                min="0.001"
                step="0.001"
                value="1"
            >

        </td>


        <td class="line">
            $0.00
        </td>


        <td>

            <button
                type="button"
                class="btn sm danger remove-sale"
                title="Eliminar producto"
            >
                ×
            </button>

        </td>

    `;


    tbody.appendChild(tr);

    calcSale();

}


/* =========================================================
   CALCULAR VENTA
   ========================================================= */

function calcSale() {

    let subtotal = 0;


    document
        .querySelectorAll(
            '#saleTable tbody tr'
        )
        .forEach(function (tr) {

            const qty =
                Number(
                    tr.querySelector(
                        '.qty'
                    )?.value || 0
                );


            const price =
                Number(
                    tr.querySelector(
                        '.price'
                    )?.value || 0
                );


            const total =
                qty * price;


            subtotal += total;


            const line =
                tr.querySelector(
                    '.line'
                );


            if (line) {

                line.textContent =
                    fmt(total);

            }

        });


    const form =
        document.getElementById(
            'saleForm'
        );


    const discount =
        Number(
            form?.querySelector(
                '[name="descuento"]'
            )?.value || 0
        );


    const taxPercent =
        Number(
            form?.querySelector(
                '[name="impuesto"]'
            )?.value || 0
        );


    const subtotalElement =
        document.getElementById(
            'saleSubtotal'
        );


    const totalElement =
        document.getElementById(
            'saleTotal'
        );


    const baseImponible =
        Math.max(
            0,
            subtotal - discount
        );


    const tax =
        baseImponible * (taxPercent / 100);


    const totalValue =
        Math.max(
            0,
            baseImponible + tax
        );


    if (subtotalElement) {

        subtotalElement.textContent =
            fmt(subtotal);

    }


    if (totalElement) {

        totalElement.textContent =
            fmt(totalValue);

    }


    lastSaleTotal =
        totalValue;


    renderSaleConversions(
        totalValue
    );


    /* Si ya hay métodos de pago elegidos, actualiza
       sus montos automáticamente con el nuevo total */

    document
        .querySelectorAll(
            '#paymentsTable tbody tr'
        )
        .forEach(function (row) {

            syncPaymentRow(row);

        });

}


/* =========================================================
   MOSTRAR CONVERSIÓN A OTRAS MONEDAS
   (el total del producto siempre se calcula en USD;
   esto solo muestra el equivalente informativo)
   ========================================================= */

function renderConversions(
    containerId,
    totalUsd
) {

    const container =
        document.getElementById(
            containerId
        );


    if (!container) {
        return;
    }


    const currencies =
        window.currencies || [];


    const parts = [];


    currencies.forEach(function (c) {

        if (
            Number(
                c.es_moneda_base
            ) === 1
        ) {

            return;

        }


        const rate =
            Number(
                c.tasa_referencia || 0
            );


        if (rate <= 0) {
            return;
        }


        const converted =
            totalUsd / rate;


        parts.push(
            '≈ ' +
            (c.simbolo || '') +
            converted.toLocaleString(
                'en-US',
                {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }
            ) +
            ' ' +
            c.codigo
        );

    });


    container.textContent =
        parts.join(
            '   ·   '
        );

}


function renderSaleConversions(
    totalUsd
) {

    renderConversions(
        'saleConversions',
        totalUsd
    );

}


function renderPurchaseConversions(
    totalUsd
) {

    renderConversions(
        'purchaseConversions',
        totalUsd
    );

}


/* =========================================================
   COMPRAS
   ========================================================= */

function addPurchaseRow() {

    const tbody =
        document.querySelector(
            '#purchaseTable tbody'
        );


    if (!tbody) {
        return;
    }


    const tr =
        document.createElement('tr');


    tr.innerHTML = `

        <td class="product-cell">

            <input
                type="hidden"
                name="product_id[]"
                class="product-id"
                value=""
            >

            <button
                type="button"
                class="select-product-btn"
            >

                <span class="product-placeholder">
                    Seleccionar producto
                </span>

            </button>

        </td>


        <td>

            <input
                name="cost[]"
                class="cost"
                type="number"
                step="0.01"
                min="0"
                value="0"
            >

        </td>


        <td>

            <input
                name="quantity[]"
                class="qty"
                type="number"
                min="0.001"
                step="0.001"
                value="1"
            >

        </td>


        <td class="line">
            $0.00
        </td>


        <td>

            <button
                type="button"
                class="btn sm danger remove-purchase"
                title="Eliminar producto"
            >
                ×
            </button>

        </td>

    `;


    tbody.appendChild(tr);

    calcPurchase();

}


/* =========================================================
   CALCULAR COMPRA
   ========================================================= */

function calcPurchase() {

    let subtotal = 0;


    document
        .querySelectorAll(
            '#purchaseTable tbody tr'
        )
        .forEach(function (tr) {

            const qty =
                Number(
                    tr.querySelector(
                        '.qty'
                    )?.value || 0
                );


            const cost =
                Number(
                    tr.querySelector(
                        '.cost'
                    )?.value || 0
                );


            const total =
                qty * cost;


            subtotal += total;


            const line =
                tr.querySelector(
                    '.line'
                );


            if (line) {

                line.textContent =
                    fmt(total);

            }

        });


    const form =
        document.getElementById(
            'purchaseForm'
        );


    const discount =
        Number(
            form?.querySelector(
                '[name="descuento"]'
            )?.value || 0
        );


    const tax =
        Number(
            form?.querySelector(
                '[name="impuesto"]'
            )?.value || 0
        );


    const subtotalElement =
        document.getElementById(
            'purchaseSubtotal'
        );


    const totalElement =
        document.getElementById(
            'purchaseTotal'
        );


    if (subtotalElement) {

        subtotalElement.textContent =
            fmt(subtotal);

    }


    const totalValue =
        Math.max(
            0,
            subtotal -
            discount +
            tax
        );


    if (totalElement) {

        totalElement.textContent =
            fmt(totalValue);

    }


    renderPurchaseConversions(
        totalValue
    );

}


/* =========================================================
   PAGOS
   ========================================================= */

function addPaymentRow() {

    const tbody =
        document.querySelector(
            '#paymentsTable tbody'
        );


    if (!tbody) {
        return;
    }


    const tr =
        document.createElement('tr');


    tr.innerHTML = `

        <td>

            <select
                name="payment_method[]"
                required
            >

                <option value="">
                    Seleccione
                </option>

                ${(window.paymentMethods || [])
                    .map(function (m) {

                        return `
                            <option
                                value="${esc(m.id_metodo_pago)}"
                                data-tasa="${esc(m.tasa)}"
                                data-moneda="${esc(m.moneda)}"
                            >
                                ${esc(m.nombre)}
                                ·
                                ${esc(m.moneda)}
                            </option>
                        `;

                    })
                    .join('')}

            </select>

        </td>


        <td>

            <input
                name="payment_amount[]"
                type="number"
                step="0.01"
                min="0"
                value="0"
            >

        </td>


        <td>

            <input
                name="payment_rate[]"
                type="number"
                step="0.000001"
                min="0"
                value="1"
            >

        </td>


        <td class="payment-base">
            -
        </td>


        <td class="payment-base">
            -
        </td>


        <td>

            <button
                type="button"
                class="btn sm danger remove-payment"
                title="Eliminar pago"
            >
                ×
            </button>

        </td>

    `;


    tbody.appendChild(tr);

}


/* =========================================================
   SINCRONIZAR FILA DE PAGO
   (autocompleta monto según la moneda elegida y el total
   de la venta, y muestra el equivalente en USD como "Base")
   ========================================================= */

function syncPaymentRow(
    row,
    forceAmount = false
) {

    if (!row) {
        return;
    }


    const select =
        row.querySelector(
            '[name="payment_method[]"]'
        );


    const amountInput =
        row.querySelector(
            '[name="payment_amount[]"]'
        );


    const rateInput =
        row.querySelector(
            '[name="payment_rate[]"]'
        );


    const baseCell =
        row.querySelector(
            '.payment-base'
        );


    if (!select) {
        return;
    }


    const selectedOption =
        select.options[
            select.selectedIndex
        ];


    const tasa =
        Number(
            selectedOption?.dataset.tasa || 0
        );


    if (
        tasa > 0 &&
        rateInput
    ) {

        rateInput.value =
            tasa;

    }


    if (
        tasa > 0 &&
        amountInput &&
        (
            forceAmount ||
            Number(
                amountInput.value || 0
            ) === 0
        )
    ) {

        amountInput.value =
            (
                lastSaleTotal /
                tasa
            ).toFixed(2);

    }


    if (baseCell) {

        const amount =
            Number(
                amountInput?.value || 0
            );


        const rate =
            Number(
                rateInput?.value || 0
            );


        baseCell.textContent =
            (
                amount &&
                rate
            )
                ? fmt(
                    amount * rate
                )
                : '-';

    }

}


/* =========================================================
   INICIALIZACIÓN
   ========================================================= */

/* =========================================================
   BUSCADOR PARA SELECTS DE CLIENTE / PROVEEDOR
   =========================================================
   Convierte cualquier <select data-combo-search="..."> en un
   campo de texto con un desplegable filtrable. El <select>
   original se mantiene oculto en el DOM (para que el formulario
   siga enviando "cliente" / "proveedor" tal como antes); solo
   cambia la forma en que el usuario elige la opción.
   ========================================================= */

function initComboSelects() {

    document
        .querySelectorAll(
            'select[data-combo-search]'
        )
        .forEach(
            setupComboSelect
        );

}


function setupComboSelect(select) {

    /* Evita inicializar dos veces el mismo select */

    if (
        select.dataset.comboReady
    ) {

        return;

    }


    select.dataset.comboReady =
        '1';


    const placeholder =
        select.getAttribute(
            'data-combo-search'
        ) ||
        'Buscar…';


    /* El required HTML5 no funciona bien sobre un <select>
       oculto (algunos navegadores no lo validan). Lo trasladamos
       al campo de texto visible, que sí es enfocable. */

    const wasRequired =
        select.hasAttribute(
            'required'
        );


    if (wasRequired) {

        select.removeAttribute(
            'required'
        );

    }


    /* Opciones reales */

    const options =
        Array.from(
            select.options
        )
        .filter(
            function (opt) {

                return opt.value !== '';

            }
        )
        .map(
            function (opt) {

                return {

                    value:
                        opt.value,

                    label:
                        opt.textContent.trim(),

                    documento:
                        opt.getAttribute(
                            'data-documento'
                        ) || ''

                };

            }
        );


    /* ---------------------------------------------------
       ARMAR MARKUP
       --------------------------------------------------- */

    const wrap =
        document.createElement(
            'div'
        );


    wrap.className =
        'combo-select';


    select.classList.add(
        'combo-select-native'
    );


    select.parentNode.insertBefore(
        wrap,
        select
    );


    wrap.appendChild(
        select
    );


    const box =
        document.createElement(
            'div'
        );


    box.className =
        'combo-select-box';


    const input =
        document.createElement(
            'input'
        );


    input.type =
        'text';


    input.className =
        'combo-select-input';


    input.placeholder =
        placeholder;


    input.autocomplete =
        'off';


    if (wasRequired) {

        input.required =
            true;

    }


    const clearBtn =
        document.createElement(
            'button'
        );


    clearBtn.type =
        'button';


    clearBtn.className =
        'combo-select-clear';


    clearBtn.innerHTML =
        '&times;';


    clearBtn.tabIndex =
        -1;


    clearBtn.setAttribute(
        'aria-label',
        'Limpiar'
    );


    box.appendChild(
        input
    );


    box.appendChild(
        clearBtn
    );


    const list =
        document.createElement(
            'div'
        );


    list.className =
        'combo-select-list';


    wrap.appendChild(
        box
    );


    wrap.appendChild(
        list
    );


    /* ---------------------------------------------------
       ESTADO
       --------------------------------------------------- */

    let activeIndex =
        -1;


    let filtered =
        [];


    function selectedOption() {

        return options.find(
            function (o) {

                return (
                    o.value ===
                    select.value
                );

            }
        );

    }


    function syncFromSelect() {

        const opt =
            selectedOption();


        input.value =
            opt
                ? opt.label
                : '';


        clearBtn.classList.toggle(
            'visible',
            !!opt
        );

    }


    function closeList() {

        list.classList.remove(
            'open'
        );


        activeIndex =
            -1;

    }


    function renderList(
        text
    ) {

        const search =
            normalizeSearch(
                text
            );


        filtered =
            options.filter(
                function (o) {

                    return (

                        normalizeSearch(
                            o.label
                        ).includes(
                            search
                        )

                        ||

                        (
                            o.documento &&

                            normalizeSearch(
                                o.documento
                            ).includes(
                                search
                            )
                        )

                    );

                }
            );


        if (!filtered.length) {

            list.innerHTML =
                '<div class="combo-select-empty">' +
                'Sin resultados' +
                '</div>';


            list.classList.add(
                'open'
            );


            return;

        }


        list.innerHTML =
            filtered
                .map(
                    function (
                        o,
                        i
                    ) {

                        return (

                            '<div class="combo-select-option' +

                            (
                                o.value ===
                                select.value
                                    ? ' selected'
                                    : ''
                            ) +

                            '" data-index="' +
                            i +
                            '">' +

                            esc(
                                o.label
                            ) +

                            (
                                o.documento
                                    ? ' <span class="combo-select-doc">' +
                                      esc(
                                          o.documento
                                      ) +
                                      '</span>'
                                    : ''
                            ) +

                            '</div>'

                        );

                    }
                )
                .join('');


        list.classList.add(
            'open'
        );


        activeIndex =
            -1;

    }


    function highlight() {

        Array.from(
            list.children
        ).forEach(
            function (
                el,
                i
            ) {

                el.classList.toggle(
                    'active',
                    i === activeIndex
                );

            }
        );


        const activeEl =
            list.children[
                activeIndex
            ];


        if (activeEl) {

            activeEl.scrollIntoView({
                block:
                    'nearest'
            });

        }

    }


    function pick(
        option
    ) {

        select.value =
            option.value;


        select.dispatchEvent(
            new Event(
                'change',
                {
                    bubbles: true
                }
            )
        );


        syncFromSelect();


        closeList();

    }


    /* ---------------------------------------------------
       EVENTOS
       --------------------------------------------------- */

    input.addEventListener(
        'focus',
        function () {

            renderList('');

            input.select();

        }
    );


    input.addEventListener(
        'input',
        function () {

            /* Mientras escribe, invalidamos la selección previa
               hasta que elija una opción real de la lista. */

            select.value =
                '';


            renderList(
                input.value
            );

        }
    );


    input.addEventListener(
        'keydown',
        function (e) {

            if (
                !list.classList.contains(
                    'open'
                ) &&
                (
                    e.key ===
                    'ArrowDown' ||
                    e.key ===
                    'ArrowUp'
                )
            ) {

                renderList(
                    input.value
                );

                return;

            }


            if (
                e.key ===
                'ArrowDown'
            ) {

                e.preventDefault();


                activeIndex =
                    Math.min(
                        activeIndex + 1,
                        filtered.length - 1
                    );


                highlight();

            }

            else if (
                e.key ===
                'ArrowUp'
            ) {

                e.preventDefault();


                activeIndex =
                    Math.max(
                        activeIndex - 1,
                        0
                    );


                highlight();

            }

            else if (
                e.key ===
                'Enter'
            ) {

                if (
                    list.classList.contains(
                        'open'
                    )
                ) {

                    e.preventDefault();


                    const opt =
                        filtered[
                            activeIndex
                        ] ||
                        filtered[0];


                    if (opt) {

                        pick(
                            opt
                        );

                    }

                }

            }

            else if (
                e.key ===
                'Escape'
            ) {

                closeList();

                syncFromSelect();

            }

        }
    );


    list.addEventListener(
        'mousedown',
        function (e) {

            const opt =
                e.target.closest(
                    '.combo-select-option'
                );


            if (!opt) {
                return;
            }


            e.preventDefault();


            const chosen =
                filtered[
                    Number(
                        opt.dataset.index
                    )
                ];


            if (chosen) {

                pick(
                    chosen
                );

            }

        }
    );


    clearBtn.addEventListener(
        'mousedown',
        function (e) {

            e.preventDefault();


            select.value =
                '';


            select.dispatchEvent(
                new Event(
                    'change',
                    {
                        bubbles: true
                    }
                )
            );


            syncFromSelect();


            input.focus();


            renderList('');

        }
    );


    input.addEventListener(
        'blur',
        function () {

            /* Retraso para permitir que el mousedown de la lista
               (o del botón limpiar) se procese antes de cerrar. */

            setTimeout(
                function () {

                    closeList();

                    syncFromSelect();

                },
                120
            );

        }
    );


    /* Estado inicial */

    syncFromSelect();

}
/* =========================================================
   MENÚ MÓVIL
   Solo controla la apertura/cierre del menú en teléfonos.
   No modifica ninguna función de ventas, compras o productos.
   ========================================================= */

function initMobileMenu() {

    const toggle =
        document.getElementById('mobileMenuToggle');

    const sidebar =
        document.getElementById('mobileSidebar');

    const overlay =
        document.getElementById('mobileMenuOverlay');

    if (!toggle || !sidebar || !overlay) {
        return;
    }

    if (toggle.dataset.mobileMenuBound === 'true') {
        return;
    }

    toggle.dataset.mobileMenuBound = 'true';

    function closeMenu() {

        sidebar.classList.remove('mobile-menu-open');

        overlay.classList.remove('show');

        toggle.classList.remove('active');

        toggle.setAttribute(
            'aria-expanded',
            'false'
        );

        toggle.setAttribute(
            'aria-label',
            'Abrir menú'
        );

        overlay.setAttribute(
            'aria-hidden',
            'true'
        );

        document.body.classList.remove(
            'mobile-menu-open'
        );

    }

    function openMenu() {

        sidebar.classList.add('mobile-menu-open');

        overlay.classList.add('show');

        toggle.classList.add('active');

        toggle.setAttribute(
            'aria-expanded',
            'true'
        );

        toggle.setAttribute(
            'aria-label',
            'Cerrar menú'
        );

        overlay.setAttribute(
            'aria-hidden',
            'false'
        );

        document.body.classList.add(
            'mobile-menu-open'
        );

    }

    function toggleMenu() {

        if (
            sidebar.classList.contains(
                'mobile-menu-open'
            )
        ) {

            closeMenu();

        } else {

            openMenu();

        }

    }

    toggle.addEventListener(
        'click',
        function (event) {

            event.preventDefault();
            event.stopPropagation();

            toggleMenu();

        }
    );

    overlay.addEventListener(
        'click',
        function () {

            closeMenu();

        }
    );

    sidebar.addEventListener(
        'click',
        function (event) {

            const link =
                event.target.closest('a');

            if (!link) {
                return;
            }

            /*
             * Al seleccionar una opción del menú se cierra
             * solamente el menú móvil. La navegación PHP
             * continúa funcionando normalmente.
             */

            closeMenu();

        }
    );

    document.addEventListener(
        'keydown',
        function (event) {

            if (event.key === 'Escape') {

                closeMenu();

            }

        }
    );

    /*
     * Si el usuario vuelve a una vista de escritorio,
     * dejamos el menú móvil completamente cerrado.
     */

    window.addEventListener(
        'resize',
        function () {

            if (window.innerWidth > 700) {

                closeMenu();

            }

        }
    );

}

/* =========================================================
   INICIAR APLICACIÓN
   ========================================================= */

function initBillingApp() {

     /* Crear menu movil */

    initMobileMenu();

    /* Crear modal PRIMERO */

    ensureProductModal();


    /* Buscador de cliente / proveedor */

    initComboSelects();


    /* =====================================================
       VENTA
       ===================================================== */

    const saleBody =
        document.querySelector(
            '#saleTable tbody'
        );


    if (
        saleBody &&
        !saleBody.children.length
    ) {

        addSaleRow();

    }


    /* =====================================================
       PAGOS
       ===================================================== */

    const paymentBody =
        document.querySelector(
            '#paymentsTable tbody'
        );


    if (
        paymentBody &&
        !paymentBody.children.length
    ) {

        addPaymentRow();

    }


    /* =====================================================
       COMPRA
       ===================================================== */

    const purchaseBody =
        document.querySelector(
            '#purchaseTable tbody'
        );


    if (
        purchaseBody &&
        !purchaseBody.children.length
    ) {

        addPurchaseRow();

    }


    /* =====================================================
       CLICS GLOBALES
       ===================================================== */

    document.addEventListener(
        'click',
        function (event) {


            /* ---------------------------------------------
               SELECCIONAR PRODUCTO
               --------------------------------------------- */

            const selectButton =
                event.target.closest(
                    '.select-product-btn'
                );


            if (selectButton) {

                event.preventDefault();

                event.stopPropagation();


                const row =
                    selectButton.closest(
                        'tr'
                    );


                if (!row) {
                    return;
                }


                let mode =
                    'purchase';


                if (
                    document.querySelector(
                        '#saleTable'
                    )?.contains(
                        row
                    )
                ) {

                    mode =
                        'sale';

                }


                openProductModal(
                    row,
                    mode
                );


                return;

            }


            /* ---------------------------------------------
               RESULTADO DE PRODUCTO
               --------------------------------------------- */

            const result =
                event.target.closest(
                    '.product-result'
                );


            if (result) {

                event.preventDefault();


                selectProductFromModal(
                    result.dataset.productId
                );


                return;

            }


            /* ---------------------------------------------
               ELIMINAR VENTA
               --------------------------------------------- */

            const removeSale =
                event.target.closest(
                    '.remove-sale'
                );


            if (removeSale) {

                const row =
                    removeSale.closest(
                        'tr'
                    );


                if (row) {

                    row.remove();

                    calcSale();

                }


                return;

            }


            /* ---------------------------------------------
               ELIMINAR COMPRA
               --------------------------------------------- */

            const removePurchase =
                event.target.closest(
                    '.remove-purchase'
                );


            if (removePurchase) {

                const row =
                    removePurchase.closest(
                        'tr'
                    );


                if (row) {

                    row.remove();

                    calcPurchase();

                }


                return;

            }


            /* ---------------------------------------------
               ELIMINAR PAGO
               --------------------------------------------- */

            const removePayment =
                event.target.closest(
                    '.remove-payment'
                );


            if (removePayment) {

                const row =
                    removePayment.closest(
                        'tr'
                    );


                if (row) {

                    row.remove();

                }


                return;

            }

        }
    );


    /* =====================================================
       INPUTS
       ===================================================== */

    document.addEventListener(
        'input',
        function (event) {

            const target =
                event.target;


            if (
                target.matches(
                    '#saleTable .qty, ' +
                    '#saleTable .price, ' +
                    '#saleForm [name="descuento"], ' +
                    '#saleForm [name="impuesto"]'
                )
            ) {

                calcSale();

            }


            if (
                target.matches(
                    '#purchaseTable .qty, ' +
                    '#purchaseTable .cost, ' +
                    '#purchaseForm [name="descuento"], ' +
                    '#purchaseForm [name="impuesto"]'
                )
            ) {

                calcPurchase();

            }

        }
    );

}


/* =====================================================
   CAMBIO DE MÉTODO DE PAGO
   ===================================================== */

document.addEventListener(
    'change',
    function (event) {

        const select =
            event.target.closest(
                '[name="payment_method[]"]'
            );


        if (select) {

            syncPaymentRow(
                select.closest('tr'),
                true
            );

        }

    }
);


/* =====================================================
   EDICIÓN MANUAL DE MONTO / TASA
   ===================================================== */

document.addEventListener(
    'input',
    function (event) {

        const target =
            event.target;


        if (
            target.matches(
                '[name="payment_amount[]"], [name="payment_rate[]"]'
            )
        ) {

            syncPaymentRow(
                target.closest('tr')
            );

        }

    }
);


/* =========================================================
   INICIAR
   ========================================================= */

if (
    document.readyState === 'loading'
) {

    document.addEventListener(
        'DOMContentLoaded',
        initBillingApp
    );

} else {

    initBillingApp();

}
/* =========================================================
   HISTORIAL DE CIERRES DE CAJA
   ========================================================= */

let cajaHistorialInitialized = false;
let cajaHistorialPage = 1;

const CAJA_HISTORIAL_PAGE_SIZE = 10;


/* =========================================================
   INICIALIZAR MODAL
   ========================================================= */

function ensureCajaHistorialModal() {

    if (cajaHistorialInitialized) {
        return;
    }

    const modal =
        document.getElementById(
            'cajaHistorialModal'
        );

    const search =
        document.getElementById(
            'cajaHistorialSearch'
        );


    /* -----------------------------------------------------
       BUSCADOR
       ----------------------------------------------------- */

    if (search) {

        search.addEventListener(
            'input',
            function () {

                cajaHistorialPage = 1;

                renderCajaHistorial(
                    this.value
                );

            }
        );

    }


    /* -----------------------------------------------------
       CERRAR AL HACER CLICK FUERA
       ----------------------------------------------------- */

    if (modal) {

        modal.addEventListener(
            'click',
            function (event) {

                if (
                    event.target === modal
                ) {

                    closeCajaHistorialModal();

                }

            }
        );

    }


    /* -----------------------------------------------------
       CERRAR CON ESC
       ----------------------------------------------------- */

    document.addEventListener(
        'keydown',
        function (event) {

            if (
                event.key === 'Escape' &&
                modal &&
                modal.getAttribute(
                    'aria-hidden'
                ) === 'false'
            ) {

                closeCajaHistorialModal();

            }

        }
    );


    cajaHistorialInitialized = true;

}


/* =========================================================
   ABRIR MODAL
   ========================================================= */

function openCajaHistorialModal() {

    const modal =
        document.getElementById(
            'cajaHistorialModal'
        );


    if (!modal) {
        return;
    }


    ensureCajaHistorialModal();


    modal.setAttribute(
        'aria-hidden',
        'false'
    );


    modal.style.display =
        'flex';


    cajaHistorialPage =
        1;


    const search =
        document.getElementById(
            'cajaHistorialSearch'
        );


    if (search) {

        search.value =
            '';

    }


    renderCajaHistorial('');

}


/* =========================================================
   CERRAR MODAL
   ========================================================= */

function closeCajaHistorialModal() {

    const modal =
        document.getElementById(
            'cajaHistorialModal'
        );


    if (!modal) {
        return;
    }


    modal.setAttribute(
        'aria-hidden',
        'true'
    );


    modal.style.display =
        'none';

}


/* =========================================================
   FILTRAR CIERRES
   ========================================================= */

function filterCajaHistorial(
    text
) {

    const cierres =
        Array.isArray(
            window.cajaCierres
        )
            ? window.cajaCierres
            : [];


    const search =
        normalizeSearch(text);


    if (!search) {

        return cierres;

    }


    return cierres.filter(
        function (cierre) {

            const haystack =
                normalizeSearch(
                    [
                        cierre.id_caja,
                        cierre.fecha_apertura,
                        cierre.fecha_cierre,
                        cierre.observaciones_cierre
                    ].join(' ')
                );


            return haystack.includes(
                search
            );

        }
    );

}


/* =========================================================
   MOSTRAR HISTORIAL
   ========================================================= */

function renderCajaHistorial(
    text = ''
) {

    const container =
        document.getElementById(
            'cajaHistorialResults'
        );


    const paginationEl =
        document.getElementById(
            'cajaHistorialPagination'
        );


    if (!container) {
        return;
    }


    const filtered =
        filterCajaHistorial(
            text
        );


    const totalPages =
        Math.max(
            1,
            Math.ceil(
                filtered.length /
                CAJA_HISTORIAL_PAGE_SIZE
            )
        );


    if (
        cajaHistorialPage >
        totalPages
    ) {

        cajaHistorialPage =
            totalPages;

    }


    const start =
        (
            cajaHistorialPage - 1
        ) *
        CAJA_HISTORIAL_PAGE_SIZE;


    const pageItems =
        filtered.slice(
            start,
            start +
            CAJA_HISTORIAL_PAGE_SIZE
        );


    /* -----------------------------------------------------
       SIN RESULTADOS
       ----------------------------------------------------- */

    if (!pageItems.length) {

        container.innerHTML = `

            <div class="product-no-results">

                No se encontraron
                cierres de caja.

            </div>

        `;

    }


    /* -----------------------------------------------------
       MOSTRAR CIERRES
       ----------------------------------------------------- */

    else {

        container.innerHTML = `

            <table>

                <thead>

                    <tr>

                        <th>
                            Cierre
                        </th>

                        <th>
                            Fecha de apertura
                        </th>

                        <th>
                            Fecha de cierre
                        </th>

                        <th>
                            Acción
                        </th>

                    </tr>

                </thead>


                <tbody>

                    ${pageItems.map(
                        function (cierre) {

                            return `

                                <tr>

                                    <td>
                                        <strong>
                                            Cierre #${esc(
                                                cierre.id_caja
                                            )}
                                        </strong>
                                    </td>


                                    <td>
                                        ${esc(
                                            cierre.fecha_apertura ||
                                            '—'
                                        )}
                                    </td>


                                    <td>
                                        ${esc(
                                            cierre.fecha_cierre ||
                                            '—'
                                        )}
                                    </td>


                                    <td>

                                        <a
                                            href="index.php?page=caja&cierre=${encodeURIComponent(
                                                cierre.id_caja
                                            )}"
                                            class="btn primary"
                                        >
                                            Ver cierre
                                        </a>

                                    </td>

                                </tr>

                            `;

                        }
                    ).join('')}

                </tbody>

            </table>

        `;

    }


    /* =====================================================
       PAGINACIÓN
       ===================================================== */

    if (paginationEl) {

        if (
            totalPages <= 1
        ) {

            paginationEl.innerHTML =
                '';

        }

        else {

            let buttons =
                '';


            for (
                let p = 1;
                p <= totalPages;
                p++
            ) {

                buttons += `

                    <button
                        type="button"
                        class="btn${
                            p === cajaHistorialPage
                                ? ' primary'
                                : ''
                        }"
                        onclick="
                            goToCajaHistorialPage(
                                ${p}
                            );
                        "
                    >
                        ${p}
                    </button>

                `;

            }


            paginationEl.innerHTML =
                buttons;

        }

    }

}


/* =========================================================
   CAMBIAR DE PÁGINA
   ========================================================= */

function goToCajaHistorialPage(
    page
) {

    cajaHistorialPage =
        Number(page) || 1;


    const search =
        document.getElementById(
            'cajaHistorialSearch'
        );


    renderCajaHistorial(
        search
            ? search.value
            : ''
    );

}
