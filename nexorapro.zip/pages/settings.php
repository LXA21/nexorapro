<?php

admin_only();

$settings = company_settings();

$currencies = allrows("
    SELECT *
    FROM monedas
    WHERE activo=1
    ORDER BY es_moneda_base DESC, codigo ASC
");

$paymentMethods = allrows("
    SELECT
        mp.id_metodo_pago,
        mp.nombre,
        mp.tipo_pago,
        m.codigo AS moneda
    FROM metodos_pago mp
    INNER JOIN monedas m
        ON m.id_moneda=mp.id_moneda
    WHERE mp.activo=1
    ORDER BY mp.nombre ASC, m.codigo ASC
");

$selectedPayments = array_filter(array_map(
    'trim',
    explode(',', (string)($settings['formas_pago_habituales'] ?? ''))
));

$logoPath = trim((string)($settings['logotipo'] ?? ''));

?>

<section class="panel settings-page">

    <div class="settings-head">
        <div>
            <h2>Configuración del sistema</h2>
            <p class="muted">
                Configura los datos de la empresa, facturación, impuestos,
                pagos y entorno. Los cambios se guardan únicamente desde este módulo.
            </p>
        </div>

        <div class="settings-status <?=($settings['entorno']==='PRODUCCION'?'production':'testing')?>">
            <?=e($settings['entorno'])?>
        </div>
    </div>

    <form method="post" action="actions.php" enctype="multipart/form-data">

        <input type="hidden" name="csrf" value="<?=e(csrf())?>">
        <input type="hidden" name="action" value="settings_save">
        <input type="hidden" name="return_page" value="settings">
        <input type="hidden" name="id_configuracion" value="<?=e($settings['id_configuracion'])?>">

        <!-- =====================================================
             DATOS PRINCIPALES DE LA EMPRESA
             ===================================================== -->

        <div class="settings-section">
            <div class="settings-section-title">
                <div>
                    <h3>Datos principales de la empresa</h3>
                    <p>Información que identifica a la empresa en el sistema y en sus documentos.</p>
                </div>
            </div>

            <div class="form-grid">

                <label>
                    Razón social <span class="required">*</span>
                    <input
                        name="razon_social"
                        maxlength="200"
                        value="<?=e($settings['razon_social'])?>"
                        required
                    >
                </label>

                <label>
                    Nombre comercial <span class="required">*</span>
                    <input
                        name="nombre_comercial"
                        maxlength="200"
                        value="<?=e($settings['nombre_comercial'])?>"
                        required
                    >
                </label>

                <label>
                    Tipo de identificación fiscal
                    <select name="tipo_identificacion_fiscal">
                        <?php foreach(['NIT','RUC','RFC','RIF','DNI','OTRO'] as $tipo): ?>
                            <option value="<?=e($tipo)?>" <?=($settings['tipo_identificacion_fiscal']===$tipo?'selected':'')?> >
                                <?=e($tipo)?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label>
                    Número de identificación fiscal <span class="required">*</span>
                    <input
                        name="identificacion_fiscal"
                        maxlength="100"
                        value="<?=e($settings['identificacion_fiscal'])?>"
                        required
                    >
                </label>

                <label class="settings-full">
                    Dirección fiscal
                    <textarea name="direccion_fiscal" maxlength="500" rows="3"><?=e($settings['direccion_fiscal'])?></textarea>
                </label>

                <label>
                    Teléfono
                    <input
                        name="telefono"
                        maxlength="50"
                        value="<?=e($settings['telefono'])?>"
                    >
                </label>

                <label>
                    Correo electrónico
                    <input
                        type="email"
                        name="correo"
                        maxlength="150"
                        value="<?=e($settings['correo'])?>"
                    >
                </label>

                <label class="settings-full">
                    Logotipo para documentos PDF
                    <input
                        type="file"
                        name="logotipo"
                        accept="image/jpeg,image/png,image/webp"
                    >
                    <small class="settings-help">
                        Formatos permitidos: JPG, PNG o WEBP. Tamaño máximo: 5 MB.
                    </small>
                </label>

            </div>

            <?php if($logoPath!==''): ?>
                <div class="settings-logo-preview">
                    <span class="muted">Logotipo actual</span>
                    <img src="<?=e($logoPath)?>" alt="Logotipo de la empresa">
                </div>
            <?php endif; ?>
        </div>


        <!-- =====================================================
             FACTURACIÓN Y FOLIOS
             ===================================================== -->

        <div class="settings-section">
            <div class="settings-section-title">
                <div>
                    <h3>Parámetros de facturación y folios</h3>
                    <p>Datos de autorización fiscal y numeración que utilizará el sistema.</p>
                </div>
            </div>

            <div class="form-grid">

                <label>
                    Resolución / autorización fiscal
                    <input
                        name="resolucion_fiscal"
                        maxlength="200"
                        value="<?=e($settings['resolucion_fiscal'])?>"
                    >
                </label>

                <label>
                    Prefijo de factura
                    <input
                        name="prefijo_factura"
                        maxlength="30"
                        value="<?=e($settings['prefijo_factura'])?>"
                    >
                </label>

                <label>
                    Fecha de resolución
                    <input
                        type="date"
                        name="fecha_resolucion"
                        value="<?=e($settings['fecha_resolucion'])?>"
                    >
                </label>

                <label>
                    Fecha de vencimiento
                    <input
                        type="date"
                        name="fecha_vencimiento_resolucion"
                        value="<?=e($settings['fecha_vencimiento_resolucion'])?>"
                    >
                </label>

                <label>
                    Número inicial autorizado
                    <input
                        type="number"
                        name="numero_inicial"
                        min="1"
                        step="1"
                        value="<?=e($settings['numero_inicial'])?>"
                    >
                </label>

                <label>
                    Número actual / próximo folio
                    <input
                        type="number"
                        name="numero_actual"
                        min="1"
                        step="1"
                        value="<?=e($settings['numero_actual'])?>"
                    >
                </label>

                <label>
                    Número final autorizado
                    <input
                        type="number"
                        name="numero_final"
                        min="1"
                        step="1"
                        value="<?=e($settings['numero_final'])?>"
                        placeholder="Sin límite configurado"
                    >
                </label>

                <label>
                    Moneda predeterminada
                    <select name="id_moneda_predeterminada">
                        <?php foreach($currencies as $currency): ?>
                            <option
                                value="<?=e($currency['id_moneda'])?>"
                                <?=((int)$settings['id_moneda_predeterminada']===(int)$currency['id_moneda']?'selected':'')?>
                            >
                                <?=e($currency['codigo'].' - '.$currency['nombre'].' ('.$currency['simbolo'].')')?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label>
                    Decimales predeterminados
                    <select name="decimales">
                        <?php for($d=0;$d<=4;$d++): ?>
                            <option value="<?=$d?>" <?=((int)$settings['decimales']===$d?'selected':'')?> >
                                <?=$d?> decimal<?=$d===1?'':'es'?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </label>

            </div>

            <div class="notice settings-note">
                El campo <b>Número actual / próximo folio</b> se guarda como configuración.
                La numeración automática de las ventas existentes no se modifica en esta etapa.
            </div>
        </div>


        <!-- =====================================================
             PAGOS
             ===================================================== -->

        <div class="settings-section">
            <div class="settings-section-title">
                <div>
                    <h3>Plazos y formas de pago habituales</h3>
                    <p>Selecciona los métodos que deseas considerar habituales y define el predeterminado.</p>
                </div>
            </div>

            <div class="form-grid">

                <label>
                    Días de crédito predeterminados
                    <input
                        type="number"
                        name="dias_credito"
                        min="0"
                        max="3650"
                        step="1"
                        value="<?=e($settings['dias_credito'])?>"
                    >
                </label>

                <label>
                    Forma de pago predeterminada
                    <select name="forma_pago_predeterminada">
                        <option value="">-- Seleccionar --</option>
                        <?php foreach($paymentMethods as $method): ?>
                            <?php $methodLabel=$method['nombre'].' - '.$method['moneda']; ?>
                            <option
                                value="<?=e($method['nombre'])?>"
                                <?=($settings['forma_pago_predeterminada']===$method['nombre']?'selected':'')?>
                            >
                                <?=e($methodLabel)?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <div class="settings-full">
                    <div class="settings-label">Formas de pago habituales</div>
                    <div class="settings-payment-list">
                        <?php if(!$paymentMethods): ?>
                            <div class="notice">
                                No hay métodos de pago activos. Puedes crearlos desde el módulo Métodos de pago.
                            </div>
                        <?php else: ?>
                            <?php foreach($paymentMethods as $method): ?>
                                <?php $methodLabel=$method['nombre'].' - '.$method['moneda']; ?>
                                <label class="settings-check">
                                    <input
                                        type="checkbox"
                                        name="formas_pago[]"
                                        value="<?=e($method['nombre'])?>"
                                        <?=in_array($method['nombre'],$selectedPayments,true)?'checked':''?>
                                    >
                                    <span><?=e($methodLabel)?></span>
                                </label>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>


        <!-- =====================================================
             IMPUESTOS Y CONTABILIDAD
             ===================================================== -->

        <div class="settings-section">
            <div class="settings-section-title">
                <div>
                    <h3>Impuestos y aspectos contables</h3>
                    <p>Valores generales que quedarán disponibles como parámetros del sistema.</p>
                </div>
            </div>

            <div class="form-grid">

                <label>
                    Impuesto general (%)
                    <input
                        type="number"
                        name="impuesto_general"
                        min="0"
                        max="100"
                        step="0.01"
                        value="<?=e($settings['impuesto_general'])?>"
                    >
                </label>

                <label>
                    Retención (%)
                    <input
                        type="number"
                        name="retencion"
                        min="0"
                        max="100"
                        step="0.01"
                        value="<?=e($settings['retencion'])?>"
                    >
                </label>

                <label>
                    Impuesto local (%)
                    <input
                        type="number"
                        name="impuesto_local"
                        min="0"
                        max="100"
                        step="0.01"
                        value="<?=e($settings['impuesto_local'])?>"
                    >
                </label>

                <label>
                    Régimen fiscal
                    <input
                        name="regimen_fiscal"
                        maxlength="150"
                        value="<?=e($settings['regimen_fiscal'])?>"
                    >
                </label>

                <label>
                    Cuenta contable de ventas
                    <input
                        name="cuenta_ventas"
                        maxlength="100"
                        value="<?=e($settings['cuenta_ventas'])?>"
                    >
                </label>

                <label>
                    Cuenta contable de compras
                    <input
                        name="cuenta_compras"
                        maxlength="100"
                        value="<?=e($settings['cuenta_compras'])?>"
                    >
                </label>

                <label>
                    Cuenta contable de impuestos
                    <input
                        name="cuenta_impuestos"
                        maxlength="100"
                        value="<?=e($settings['cuenta_impuestos'])?>"
                    >
                </label>

                <label>
                    Cuenta contable de retenciones
                    <input
                        name="cuenta_retenciones"
                        maxlength="100"
                        value="<?=e($settings['cuenta_retenciones'])?>"
                    >
                </label>

            </div>
        </div>


        <!-- =====================================================
             ENTORNO
             ===================================================== -->

        <div class="settings-section">
            <div class="settings-section-title">
                <div>
                    <h3>Entorno del sistema</h3>
                    <p>Define si la configuración corresponde a pruebas o producción.</p>
                </div>
            </div>

            <div class="settings-environment">
                <label class="environment-option">
                    <input
                        type="radio"
                        name="entorno"
                        value="PRUEBAS"
                        <?=($settings['entorno']==='PRUEBAS'?'checked':'')?>
                    >
                    <span>
                        <b>Pruebas</b>
                        <small>Para realizar pruebas sin considerar este entorno como producción.</small>
                    </span>
                </label>

                <label class="environment-option">
                    <input
                        type="radio"
                        name="entorno"
                        value="PRODUCCION"
                        <?=($settings['entorno']==='PRODUCCION'?'checked':'')?>
                    >
                    <span>
                        <b>Producción</b>
                        <small>Indica que el sistema está configurado para operación real.</small>
                    </span>
                </label>
            </div>

            <div class="notice settings-warning">
                Cambiar a <b>Producción</b> no activa por sí solo una conexión con una entidad fiscal externa.
                Actualmente este valor solo identifica el entorno configurado.
            </div>
        </div>


        <div class="settings-actions">
            <button class="btn primary" type="submit">
                Guardar configuración
            </button>
        </div>

    </form>
</section>
