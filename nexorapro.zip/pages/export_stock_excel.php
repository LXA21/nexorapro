<?php

/* =========================================================
   EXPORTAR REPORTE DE STOCK E INVENTARIO A EXCEL
   Compatible con PhpSpreadsheet actual.
   ========================================================= */

require_once __DIR__ . '/../functions.php';

require_login();


/* =========================================================
   FECHAS
   ========================================================= */

$from = $_GET['from'] ?? date('Y-m-01');
$to   = $_GET['to']   ?? date('Y-m-d');

$fromObj = DateTime::createFromFormat('Y-m-d', $from);
$toObj   = DateTime::createFromFormat('Y-m-d', $to);

if (!$fromObj) {
    $from = date('Y-m-01');
}

if (!$toObj) {
    $to = date('Y-m-d');
}

if ($from > $to) {
    $tmp = $from;
    $from = $to;
    $to = $tmp;
}

$fromDateTime = $from . ' 00:00:00';
$toDateTime   = $to   . ' 23:59:59';


/* =========================================================
   FILTROS
   ========================================================= */

$inventorySearch =
    trim((string)($_GET['inventory_search'] ?? ''));

$inventoryProduct =
    (int)($_GET['inventory_product'] ?? 0);


/* =========================================================
   PRODUCTOS ACTIVOS
   ========================================================= */

$inventoryProducts = allrows("
    SELECT
        id_producto,
        codigo,
        nombre,
        costo_promedio,
        stock_actual,
        stock_minimo
    FROM productos
    WHERE activo = 1
    ORDER BY nombre
");


/* =========================================================
   MOVIMIENTOS DEL PERÍODO
   ========================================================= */

$inventoryPeriodMovements = allrows("
    SELECT
        mi.id_movimiento,
        mi.id_producto,
        mi.tipo_movimiento,
        mi.cantidad,
        mi.stock_anterior,
        mi.stock_nuevo,
        mi.costo_unitario,
        mi.fecha,
        mi.observaciones,
        p.codigo,
        p.nombre AS producto
    FROM movimientos_inventario mi
    INNER JOIN productos p
        ON p.id_producto = mi.id_producto
    WHERE mi.fecha >= ?
      AND mi.fecha <= ?
    ORDER BY
        mi.id_producto ASC,
        mi.fecha ASC,
        mi.id_movimiento ASC
", [
    $fromDateTime,
    $toDateTime
]);


/* =========================================================
   ÚLTIMO STOCK ANTES DEL PERÍODO
   ========================================================= */

$inventoryBefore = allrows("
    SELECT
        id_producto,
        stock_nuevo
    FROM movimientos_inventario
    WHERE fecha < ?
    ORDER BY
        id_producto ASC,
        fecha DESC,
        id_movimiento DESC
", [
    $fromDateTime
]);

$inventoryBeforeMap = [];

foreach ($inventoryBefore as $m) {

    $pid = (int)$m['id_producto'];

    if (!isset($inventoryBeforeMap[$pid])) {
        $inventoryBeforeMap[$pid] =
            (float)$m['stock_nuevo'];
    }
}


/* =========================================================
   PRIMER STOCK HISTÓRICO
   ========================================================= */

$inventoryFirst = allrows("
    SELECT
        id_producto,
        stock_anterior
    FROM movimientos_inventario
    ORDER BY
        id_producto ASC,
        fecha ASC,
        id_movimiento ASC
");

$inventoryFirstMap = [];

foreach ($inventoryFirst as $m) {

    $pid = (int)$m['id_producto'];

    if (!isset($inventoryFirstMap[$pid])) {
        $inventoryFirstMap[$pid] =
            (float)$m['stock_anterior'];
    }
}


/* =========================================================
   ÚLTIMO STOCK HASTA EL FINAL DEL PERÍODO
   ========================================================= */

$inventoryUntil = allrows("
    SELECT
        id_producto,
        stock_nuevo
    FROM movimientos_inventario
    WHERE fecha <= ?
    ORDER BY
        id_producto ASC,
        fecha DESC,
        id_movimiento DESC
", [
    $toDateTime
]);

$inventoryUntilMap = [];

foreach ($inventoryUntil as $m) {

    $pid = (int)$m['id_producto'];

    if (!isset($inventoryUntilMap[$pid])) {
        $inventoryUntilMap[$pid] =
            (float)$m['stock_nuevo'];
    }
}


/* =========================================================
   CONSTRUIR RESUMEN DEL INVENTARIO
   ========================================================= */

$inventorySummary = [];

foreach ($inventoryProducts as $p) {

    $pid = (int)$p['id_producto'];

    $stockAnterior =
        $inventoryBeforeMap[$pid]
        ?? $inventoryFirstMap[$pid]
        ?? (float)$p['stock_actual'];

    $stockFinal =
        $inventoryUntilMap[$pid]
        ?? $inventoryBeforeMap[$pid]
        ?? (float)$p['stock_actual'];

    $entradas = 0.0;
    $salidas  = 0.0;
    $retiros  = 0.0;

    $productPeriodMovements = [];

    foreach ($inventoryPeriodMovements as $m) {

        if ((int)$m['id_producto'] !== $pid) {
            continue;
        }

        $productPeriodMovements[] = $m;

        $cantidad =
            (float)$m['cantidad'];

        $tipo =
            (string)$m['tipo_movimiento'];

        switch ($tipo) {

            case 'ENTRADA_COMPRA':
            case 'ENTRADA_DEVOLUCION':
            case 'AJUSTE_ENTRADA':

                $entradas += $cantidad;

                break;


            case 'SALIDA_VENTA':
            case 'SALIDA_DEVOLUCION':

                $salidas += $cantidad;

                break;


            case 'AJUSTE_SALIDA':

                $retiros += $cantidad;

                break;
        }
    }


    if ($productPeriodMovements) {

        $last =
            end($productPeriodMovements);

        $stockFinal =
            (float)$last['stock_nuevo'];

        reset($productPeriodMovements);
    }


    /*
     * El inventario se valora mediante costo_promedio,
     * que es el campo de costo almacenado en productos.
     */
    $costoUnitario =
        (float)($p['costo_promedio'] ?? 0);

    $costoTotal =
        $stockFinal * $costoUnitario;


    $inventorySummary[] = [

        'id_producto' =>
            $pid,

        'codigo' =>
            $p['codigo'],

        'producto' =>
            $p['nombre'],

        'stock_anterior' =>
            $stockAnterior,

        'entradas' =>
            $entradas,

        'salidas' =>
            $salidas,

        'retiros' =>
            $retiros,

        'stock_final' =>
            $stockFinal,

        'costo_unitario' =>
            $costoUnitario,

        'costo_total' =>
            $costoTotal
    ];
}


/* =========================================================
   APLICAR FILTROS
   ========================================================= */

$inventorySummaryFiltered = [];

foreach ($inventorySummary as $r) {

    if (
        $inventoryProduct > 0 &&
        (int)$r['id_producto'] !== $inventoryProduct
    ) {
        continue;
    }


    if ($inventorySearch !== '') {

        $needle =
            mb_strtolower(
                $inventorySearch,
                'UTF-8'
            );

        $haystack =
            mb_strtolower(
                (string)$r['codigo']
                . ' '
                . (string)$r['producto'],
                'UTF-8'
            );

        if (
            strpos(
                $haystack,
                $needle
            ) === false
        ) {
            continue;
        }
    }


    $inventorySummaryFiltered[] = $r;
}


/* =========================================================
   TOTAL INVENTARIO
   ========================================================= */

$inventoryTotalValue = 0.0;

foreach ($inventorySummaryFiltered as $r) {

    $inventoryTotalValue +=
        (float)$r['costo_total'];
}


/* =========================================================
   PHPSPREADSHEET
   ========================================================= */

$autoload =
    __DIR__ . '/../vendor/autoload.php';

if (!file_exists($autoload)) {

    http_response_code(500);

    exit(
        'No se encontró vendor/autoload.php. ' .
        'Ejecuta composer require phpoffice/phpspreadsheet'
    );
}

require_once $autoload;


/* =========================================================
   INFORMACIÓN DE LA EMPRESA
   ========================================================= */

$empresa = one("
    SELECT
        razon_social,
        identificacion_fiscal
    FROM configuracion_empresa
    ORDER BY id_configuracion ASC
    LIMIT 1
");

$companyName =
    trim(
        (string)($empresa['razon_social'] ?? '')
    );

$companyRif =
    trim(
        (string)($empresa['identificacion_fiscal'] ?? '')
    );

if ($companyName === '') {
    $companyName =
        'NOMBRE DE SU EMPRESA, C.A.';
}

if ($companyRif === '') {
    $companyRif =
        'J-00000000-0';
}


/* =========================================================
   CREAR LIBRO
   ========================================================= */

$spreadsheet =
    new \PhpOffice\PhpSpreadsheet\Spreadsheet();

$sheet =
    $spreadsheet->getActiveSheet();

$sheet->setTitle(
    'Libro de Inventario'
);


/* =========================================================
   ENCABEZADO
   ========================================================= */

$sheet->mergeCells('B1:K1');

$sheet->setCellValue(
    'A1',
    'EMPRESA / RAZÓN SOCIAL'
);

$sheet->setCellValue(
    'B1',
    $companyName
);


$sheet->mergeCells('B2:K2');

$sheet->setCellValue(
    'A2',
    'R.I.F.'
);

$sheet->setCellValue(
    'B2',
    $companyRif
);


$sheet->mergeCells('A3:K3');

$sheet->setCellValue(
    'A3',
    'LIBRO DE INVENTARIO - ARTÍCULO 177 REGLAMENTO LEY DE I.S.L.R.'
);


$sheet->mergeCells('B4:K4');

$sheet->setCellValue(
    'A4',
    'MES / AÑO:'
);

$sheet->setCellValue(
    'B4',
    date('m/Y', strtotime($to))
);


$sheet->mergeCells('B5:K5');

$sheet->setCellValue(
    'A5',
    'PERÍODO:'
);

$sheet->setCellValue(
    'B5',
    date('d/m/Y', strtotime($from))
    . ' - '
    . date('d/m/Y', strtotime($to))
);


/* =========================================================
   ENCABEZADOS DE LA TABLA
   ========================================================= */

$headers = [

    'N°',
    'CÓDIGO',
    'DESCRIPCIÓN DEL ARTÍCULO',
    'UNIDAD DE MEDIDA',
    'INVENTARIO INICIAL',
    'ENTRADAS',
    'SALIDAS',
    'AUTOCONSUMO / RETIROS',
    'INVENTARIO FINAL',
    'COSTO UNIT. PROMEDIO',
    'COSTO TOTAL'

];

$headerRow = 7;


/*
 * IMPORTANTE:
 *
 * NO usamos setCellValueByColumnAndRow().
 *
 * Esa función fue eliminada de versiones recientes
 * de PhpSpreadsheet y es exactamente la causa del error
 * que aparece en tu captura.
 *
 * Usamos coordenadas A1, B1, C1... compatibles.
 */

$headerColumns = [
    'A','B','C','D','E','F','G','H','I','J','K'
];

foreach ($headers as $index => $header) {

    $sheet->setCellValue(
        $headerColumns[$index] . $headerRow,
        $header
    );
}


/* =========================================================
   ESTILO DEL ENCABEZADO
   ========================================================= */

$sheet
    ->getStyle('A1:K2')
    ->getFont()
    ->setBold(true);

$sheet
    ->getStyle('A3:K3')
    ->getFont()
    ->setBold(true)
    ->setSize(14);

$sheet
    ->getStyle('A3:K3')
    ->getAlignment()
    ->setHorizontal(
        \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
    )
    ->setVertical(
        \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER
    );

$sheet
    ->getStyle('A4:A5')
    ->getFont()
    ->setBold(true);


$headerRange =
    'A' . $headerRow . ':K' . $headerRow;

$sheet
    ->getStyle($headerRange)
    ->getFont()
    ->setBold(true);

$headerFontColor =
    new \PhpOffice\PhpSpreadsheet\Style\Color('FFFFFFFF');

$sheet
    ->getStyle($headerRange)
    ->getFont()
    ->setColor($headerFontColor);

$sheet
    ->getStyle($headerRange)
    ->getFill()
    ->setFillType(
        \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID
    );

$sheet
    ->getStyle($headerRange)
    ->getFill()
    ->getStartColor()
    ->setARGB('1F527D');

$sheet
    ->getStyle($headerRange)
    ->getAlignment()
    ->setHorizontal(
        \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
    )
    ->setVertical(
        \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER
    )
    ->setWrapText(true);


/* =========================================================
   DATOS
   ========================================================= */

$rowNumber = $headerRow + 1;
$numero = 1;

foreach ($inventorySummaryFiltered as $r) {

    $sheet->setCellValue(
        'A' . $rowNumber,
        $numero++
    );


    /*
     * TYPE_STRING evita que Excel convierta códigos
     * de barras largos en notación científica.
     */
    $sheet->setCellValueExplicit(
        'B' . $rowNumber,
        (string)$r['codigo'],
        \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING
    );


    $sheet->setCellValue(
        'C' . $rowNumber,
        $r['producto']
    );


    /*
     * Tu base de datos no tiene un campo unidad_medida
     * confirmado en productos.
     */
    $sheet->setCellValue(
        'D' . $rowNumber,
        'Unidad'
    );


    $sheet->setCellValue(
        'E' . $rowNumber,
        (float)$r['stock_anterior']
    );


    $sheet->setCellValue(
        'F' . $rowNumber,
        (float)$r['entradas']
    );


    $sheet->setCellValue(
        'G' . $rowNumber,
        (float)$r['salidas']
    );


    $sheet->setCellValue(
        'H' . $rowNumber,
        (float)$r['retiros']
    );


    $sheet->setCellValue(
        'I' . $rowNumber,
        (float)$r['stock_final']
    );


    $sheet->setCellValue(
        'J' . $rowNumber,
        (float)$r['costo_unitario']
    );


    $sheet->setCellValue(
        'K' . $rowNumber,
        (float)$r['costo_total']
    );


    $rowNumber++;
}


$lastDataRow =
    max(
        $headerRow,
        $rowNumber - 1
    );


/* =========================================================
   FORMATO NUMÉRICO
   ========================================================= */

if ($lastDataRow >= $headerRow + 1) {

    $sheet
        ->getStyle(
            'E' . ($headerRow + 1) .
            ':I' . $lastDataRow
        )
        ->getNumberFormat()
        ->setFormatCode(
            '#,##0'
        );


    $sheet
        ->getStyle(
            'J' . ($headerRow + 1) .
            ':K' . $lastDataRow
        )
        ->getNumberFormat()
        ->setFormatCode(
            '#,##0.00'
        );
}


/* =========================================================
   BORDES
   ========================================================= */

$sheet
    ->getStyle(
        'A' . $headerRow .
        ':K' . $lastDataRow
    )
    ->getBorders()
    ->getAllBorders()
    ->setBorderStyle(
        \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN
    );


/* =========================================================
   TOTAL INVENTARIO
   ========================================================= */

$totalRow =
    $lastDataRow + 1;

$sheet->mergeCells(
    'A' . $totalRow . ':J' . $totalRow
);

$sheet->setCellValue(
    'A' . $totalRow,
    'TOTAL INVENTARIO:'
);

$sheet->setCellValue(
    'K' . $totalRow,
    $inventoryTotalValue
);

$sheet
    ->getStyle(
        'A' . $totalRow . ':K' . $totalRow
    )
    ->getFont()
    ->setBold(true);

$sheet
    ->getStyle(
        'A' . $totalRow
    )
    ->getAlignment()
    ->setHorizontal(
        \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT
    );

$sheet
    ->getStyle(
        'K' . $totalRow
    )
    ->getNumberFormat()
    ->setFormatCode(
        '#,##0.00'
    );


/* =========================================================
   ANCHO DE COLUMNAS
   ========================================================= */

$widths = [

    'A' => 7,
    'B' => 20,
    'C' => 38,
    'D' => 18,
    'E' => 18,
    'F' => 14,
    'G' => 14,
    'H' => 23,
    'I' => 18,
    'J' => 22,
    'K' => 20

];

foreach ($widths as $column => $width) {

    $sheet
        ->getColumnDimension($column)
        ->setWidth($width);
}


/* =========================================================
   ALTURA
   ========================================================= */

$sheet
    ->getRowDimension(3)
    ->setRowHeight(28);

$sheet
    ->getRowDimension(7)
    ->setRowHeight(38);


/* =========================================================
   ALINEACIÓN
   ========================================================= */

$sheet
    ->getStyle(
        'A7:B' . $lastDataRow
    )
    ->getAlignment()
    ->setHorizontal(
        \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
    );

$sheet
    ->getStyle(
        'D7:K' . $lastDataRow
    )
    ->getAlignment()
    ->setHorizontal(
        \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER
    );

$sheet
    ->getStyle(
        'C7:C' . $lastDataRow
    )
    ->getAlignment()
    ->setHorizontal(
        \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT
    );


/* =========================================================
   CONGELAR ENCABEZADO
   ========================================================= */

$sheet->freezePane('A8');


/* =========================================================
   FILTRO DE EXCEL
   ========================================================= */

$sheet->setAutoFilter(
    'A7:K' . $lastDataRow
);


/* =========================================================
   CONFIGURACIÓN DE PÁGINA
   ========================================================= */

$sheet
    ->getPageSetup()
    ->setOrientation(
        \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::ORIENTATION_LANDSCAPE
    );

$sheet
    ->getPageSetup()
    ->setPaperSize(
        \PhpOffice\PhpSpreadsheet\Worksheet\PageSetup::PAPERSIZE_LETTER
    );

$sheet
    ->getPageSetup()
    ->setFitToWidth(1);

$sheet
    ->getPageSetup()
    ->setFitToHeight(0);

$sheet
    ->getPageMargins()
    ->setTop(0.35)
    ->setRight(0.25)
    ->setBottom(0.35)
    ->setLeft(0.25);


/* =========================================================
   DESCARGA
   ========================================================= */

$fileName =
    'Libro_Inventario_' .
    date('d-m-Y', strtotime($from)) .
    '_al_' .
    date('d-m-Y', strtotime($to)) .
    '.xlsx';


while (ob_get_level() > 0) {
    ob_end_clean();
}


header(
    'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
);

header(
    'Content-Disposition: attachment; filename="' .
    $fileName .
    '"'
);

header(
    'Cache-Control: max-age=0'
);


$writer =
    new \PhpOffice\PhpSpreadsheet\Writer\Xlsx(
        $spreadsheet
    );

$writer->save(
    'php://output'
);

$spreadsheet->disconnectWorksheets();

unset($spreadsheet);

exit;
