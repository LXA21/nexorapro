<?php

/* =========================================================
   REPORTES
   ========================================================= */


/* =========================================================
   FECHAS
   ========================================================= */

$from = $_GET['from'] ?? date('Y-m-01');
$to   = $_GET['to'] ?? date('Y-m-d');


/*
|--------------------------------------------------------------------------
| Validar fechas
|--------------------------------------------------------------------------
*/

$fromObj = DateTime::createFromFormat(
    'Y-m-d',
    $from
);

$toObj = DateTime::createFromFormat(
    'Y-m-d',
    $to
);


if (!$fromObj) {

    $from = date('Y-m-01');

    $fromObj =
        new DateTime($from);

}


if (!$toObj) {

    $to = date('Y-m-d');

    $toObj =
        new DateTime($to);

}


/*
|--------------------------------------------------------------------------
| Si el usuario coloca las fechas invertidas
|--------------------------------------------------------------------------
*/

if ($from > $to) {

    $tmp = $from;

    $from = $to;

    $to = $tmp;

    $fromObj =
        new DateTime($from);

    $toObj =
        new DateTime($to);

}


/*
|--------------------------------------------------------------------------
| Rango exacto de fecha y hora
|--------------------------------------------------------------------------
*/

$fromDateTime =
    $from . ' 00:00:00';

$toDateTime =
    $to . ' 23:59:59';


/* =========================================================
   CANTIDAD DE DÍAS
   ========================================================= */

$days =
    $fromObj->diff(
        $toObj
    )->days + 1;


/*
|--------------------------------------------------------------------------
| Hasta 31 días -> días
| Más de 31 -> meses
|--------------------------------------------------------------------------
*/

$groupMode =
    ($days <= 31)
        ? 'day'
        : 'month';


/* =========================================================
   1. VENTAS DEL PERÍODO
   ========================================================= */

$salesRow = one("
    SELECT

        COALESCE(
            SUM(v.total),
            0
        ) AS total_ventas,

        COUNT(v.id_venta)
            AS cantidad_ventas

    FROM ventas v

    WHERE v.estado = 'COMPLETADA'

      AND v.fecha >= ?

      AND v.fecha <= ?

", [

    $fromDateTime,
    $toDateTime

]);


$sales =
    (float)(
        $salesRow['total_ventas']
        ?? 0
    );


$salesCount =
    (int)(
        $salesRow['cantidad_ventas']
        ?? 0
    );


/* =========================================================
   2. COSTO Y GANANCIA
   ========================================================= */

$profitRow = one("

    SELECT

        COALESCE(
            SUM(x.costo_total),
            0
        ) AS costo_total,

        COALESCE(
            SUM(x.ganancia_total),
            0
        ) AS ganancia_total

    FROM ventas v

    INNER JOIN (

        SELECT

            d.id_venta,

            SUM(
                d.costo_unitario
                * d.cantidad
            ) AS costo_total,

            SUM(

                d.subtotal
                - (
                    d.costo_unitario
                    * d.cantidad
                )
                - COALESCE(
                    d.descuento,
                    0
                )

            ) AS ganancia_total

        FROM detalle_ventas d

        GROUP BY
            d.id_venta

    ) x

        ON x.id_venta =
           v.id_venta

    WHERE v.estado = 'COMPLETADA'

      AND v.fecha >= ?

      AND v.fecha <= ?

", [

    $fromDateTime,
    $toDateTime

]);


$totalCost =
    (float)(
        $profitRow['costo_total']
        ?? 0
    );


$profit =
    (float)(
        $profitRow['ganancia_total']
        ?? 0
    );


/* =========================================================
   3. INVERSIONES / COMPRAS
   ========================================================= */

$investmentRow = one("

    SELECT

        COALESCE(
            SUM(c.total),
            0
        ) AS inversion,

        COUNT(c.id_compra)
            AS cantidad_compras

    FROM compras c

    WHERE c.estado = 'COMPLETADA'

      AND c.fecha >= ?

      AND c.fecha <= ?

", [

    $fromDateTime,
    $toDateTime

]);


$investment =
    (float)(
        $investmentRow['inversion']
        ?? 0
    );


$purchaseCount =
    (int)(
        $investmentRow['cantidad_compras']
        ?? 0
    );


/* =========================================================
   4. UNIDADES VENDIDAS
   ========================================================= */

$unitsRow = one("

    SELECT

        COALESCE(
            SUM(d.cantidad),
            0
        ) AS unidades

    FROM detalle_ventas d

    INNER JOIN ventas v

        ON v.id_venta =
           d.id_venta

    WHERE v.estado = 'COMPLETADA'

      AND v.fecha >= ?

      AND v.fecha <= ?

", [

    $fromDateTime,
    $toDateTime

]);


$unitsSold =
    (float)(
        $unitsRow['unidades']
        ?? 0
    );


/* =========================================================
   5. PRODUCTOS MÁS VENDIDOS
   ========================================================= */

$top = allrows("

    SELECT

        p.id_producto,

        p.nombre,

        COALESCE(
            SUM(d.cantidad),
            0
        ) AS cantidad,

        COALESCE(
            SUM(d.subtotal),
            0
        ) AS total,

        COALESCE(

            SUM(

                d.subtotal
                - (
                    d.costo_unitario
                    * d.cantidad
                )
                - COALESCE(
                    d.descuento,
                    0
                )

            ),

            0

        ) AS ganancia

    FROM detalle_ventas d

    INNER JOIN ventas v

        ON v.id_venta =
           d.id_venta

    INNER JOIN productos p

        ON p.id_producto =
           d.id_producto

    WHERE v.estado = 'COMPLETADA'

      AND v.fecha >= ?

      AND v.fecha <= ?

    GROUP BY

        p.id_producto,

        p.nombre

    ORDER BY

        cantidad DESC,

        total DESC

    LIMIT 10

", [

    $fromDateTime,
    $toDateTime

]);


$topLabels =
    array_column(
        $top,
        'nombre'
    );


$topQuantity =
    array_map(
        'floatval',
        array_column(
            $top,
            'cantidad'
        )
    );


$topData =
    array_map(
        'floatval',
        array_column(
            $top,
            'total'
        )
    );


$topProfit =
    array_map(
        'floatval',
        array_column(
            $top,
            'ganancia'
        )
    );


/* =========================================================
   6. DATOS PARA LAS GRÁFICAS DE VENTAS
   ========================================================= */

if ($groupMode === 'day') {

    $ventasPorPeriodo = allrows("

        SELECT

            DATE(v.fecha) AS periodo,

            COALESCE(
                SUM(v.total),
                0
            ) AS ventas,

            COUNT(v.id_venta) AS operaciones

        FROM ventas v

        WHERE v.estado = 'COMPLETADA'

          AND v.fecha >= ?

          AND v.fecha <= ?

        GROUP BY
            DATE(v.fecha)

        ORDER BY
            DATE(v.fecha) ASC

    ", [

        $fromDateTime,
        $toDateTime

    ]);


    $costosPorPeriodo = allrows("

        SELECT

            DATE(v.fecha) AS periodo,

            COALESCE(
                SUM(
                    d.costo_unitario * d.cantidad
                ),
                0
            ) AS costo,

            COALESCE(
                SUM(
                    d.subtotal
                    - (
                        d.costo_unitario
                        * d.cantidad
                    )
                    - COALESCE(d.descuento, 0)
                ),
                0
            ) AS ganancia,

            COALESCE(
                SUM(d.cantidad),
                0
            ) AS unidades

        FROM detalle_ventas d

        INNER JOIN ventas v
            ON v.id_venta = d.id_venta

        WHERE v.estado = 'COMPLETADA'

          AND v.fecha >= ?

          AND v.fecha <= ?

        GROUP BY
            DATE(v.fecha)

        ORDER BY
            DATE(v.fecha) ASC

    ", [

        $fromDateTime,
        $toDateTime

    ]);

} else {

    $ventasPorPeriodo = allrows("

        SELECT

            DATE_FORMAT(
                v.fecha,
                '%Y-%m-01'
            ) AS periodo,

            COALESCE(
                SUM(v.total),
                0
            ) AS ventas,

            COUNT(v.id_venta) AS operaciones

        FROM ventas v

        WHERE v.estado = 'COMPLETADA'

          AND v.fecha >= ?

          AND v.fecha <= ?

        GROUP BY
            YEAR(v.fecha),
            MONTH(v.fecha)

        ORDER BY
            YEAR(v.fecha) ASC,
            MONTH(v.fecha) ASC

    ", [

        $fromDateTime,
        $toDateTime

    ]);


    $costosPorPeriodo = allrows("

        SELECT

            DATE_FORMAT(
                v.fecha,
                '%Y-%m-01'
            ) AS periodo,

            COALESCE(
                SUM(
                    d.costo_unitario * d.cantidad
                ),
                0
            ) AS costo,

            COALESCE(
                SUM(
                    d.subtotal
                    - (
                        d.costo_unitario
                        * d.cantidad
                    )
                    - COALESCE(d.descuento, 0)
                ),
                0
            ) AS ganancia,

            COALESCE(
                SUM(d.cantidad),
                0
            ) AS unidades

        FROM detalle_ventas d

        INNER JOIN ventas v
            ON v.id_venta = d.id_venta

        WHERE v.estado = 'COMPLETADA'

          AND v.fecha >= ?

          AND v.fecha <= ?

        GROUP BY
            YEAR(v.fecha),
            MONTH(v.fecha)

        ORDER BY
            YEAR(v.fecha) ASC,
            MONTH(v.fecha) ASC

    ", [

        $fromDateTime,
        $toDateTime

    ]);

}


/* =========================================================
   7. MAPA DE VENTAS
   ========================================================= */

$ventasMap = [];


foreach (
    $ventasPorPeriodo
    as $row
) {

    $fechaPeriodo =
        $row['periodo'] ?? '';


    $timestampPeriodo =
        strtotime(
            (string)$fechaPeriodo
        );


    if (
        $timestampPeriodo === false
    ) {
        continue;
    }


    if (
        $groupMode === 'day'
    ) {

        $periodo =
            date(
                'Y-m-d',
                $timestampPeriodo
            );

    } else {

        $periodo =
            date(
                'Y-m-01',
                $timestampPeriodo
            );

    }


    $ventasMap[$periodo] = [

        'ventas' => (float)(
            $row['ventas'] ?? 0
        ),

        'operaciones' => (int)(
            $row['operaciones'] ?? 0
        )

    ];

}


/* =========================================================
   8. MAPA DE COSTO Y GANANCIA
   ========================================================= */

$costosMap = [];


foreach (
    $costosPorPeriodo
    as $row
) {

    $fechaPeriodo =
        $row['periodo'] ?? '';


    $timestampPeriodo =
        strtotime(
            (string)$fechaPeriodo
        );


    if (
        $timestampPeriodo === false
    ) {
        continue;
    }


    if (
        $groupMode === 'day'
    ) {

        $periodo =
            date(
                'Y-m-d',
                $timestampPeriodo
            );

    } else {

        $periodo =
            date(
                'Y-m-01',
                $timestampPeriodo
            );

    }


    $costosMap[$periodo] = [

        'costo' => (float)(
            $row['costo'] ?? 0
        ),

        'ganancia' => (float)(
            $row['ganancia'] ?? 0
        ),

        'unidades' => (float)(
            $row['unidades'] ?? 0
        )

    ];

}


/* =========================================================
   9. CONSTRUIR TODOS LOS DÍAS / MESES
   ========================================================= */

$ventasLabels = [];

$ventasVendido = [];

$ventasCosto = [];

$ventasGanancia = [];

$ventasOperations = [];

$ventasUnits = [];


if (
    $groupMode === 'day'
) {

    $cursor =
        new DateTime($from);


    $end =
        new DateTime($to);


    while (
        $cursor <= $end
    ) {

        $key =
            $cursor->format(
                'Y-m-d'
            );


        $ventasLabels[] =
            $cursor->format(
                'd/m'
            );


        $ventasVendido[] =
            (float)(
                $ventasMap[$key]['ventas']
                ?? 0
            );


        $ventasCosto[] =
            (float)(
                $costosMap[$key]['costo']
                ?? 0
            );


        $ventasGanancia[] =
            (float)(
                $costosMap[$key]['ganancia']
                ?? 0
            );


        $ventasOperations[] =
            (int)(
                $ventasMap[$key]['operaciones']
                ?? 0
            );


        $ventasUnits[] =
            (float)(
                $costosMap[$key]['unidades']
                ?? 0
            );


        $cursor->modify(
            '+1 day'
        );

    }

} else {

    $cursor =
        new DateTime(
            $fromObj->format(
                'Y-m-01'
            )
        );


    $end =
        new DateTime(
            $toObj->format(
                'Y-m-01'
            )
        );


    while (
        $cursor <= $end
    ) {

        $key =
            $cursor->format(
                'Y-m-01'
            );


        $ventasLabels[] =
            $cursor->format(
                'm/Y'
            );


        $ventasVendido[] =
            (float)(
                $ventasMap[$key]['ventas']
                ?? 0
            );


        $ventasCosto[] =
            (float)(
                $costosMap[$key]['costo']
                ?? 0
            );


        $ventasGanancia[] =
            (float)(
                $costosMap[$key]['ganancia']
                ?? 0
            );


        $ventasOperations[] =
            (int)(
                $ventasMap[$key]['operaciones']
                ?? 0
            );


        $ventasUnits[] =
            (float)(
                $costosMap[$key]['unidades']
                ?? 0
            );


        $cursor->modify(
            '+1 month'
        );

    }

}


/* =========================================================
   10. COMPRAS / INVERSIONES POR PERÍODO
   ========================================================= */

if (
    $groupMode === 'day'
) {

    $comprasPorPeriodo = allrows("

        SELECT

            DATE(c.fecha) AS periodo,

            COALESCE(
                SUM(c.total),
                0
            ) AS inversion,

            COUNT(c.id_compra)
                AS operaciones

        FROM compras c

        WHERE c.estado = 'COMPLETADA'

          AND c.fecha >= ?

          AND c.fecha <= ?

        GROUP BY
            DATE(c.fecha)

        ORDER BY
            periodo ASC

    ", [

        $fromDateTime,
        $toDateTime

    ]);

} else {

    $comprasPorPeriodo = allrows("

        SELECT

            DATE_FORMAT(
                c.fecha,
                '%Y-%m-01'
            ) AS periodo,

            COALESCE(
                SUM(c.total),
                0
            ) AS inversion,

            COUNT(c.id_compra)
                AS operaciones

        FROM compras c

        WHERE c.estado = 'COMPLETADA'

          AND c.fecha >= ?

          AND c.fecha <= ?

        GROUP BY

            YEAR(c.fecha),

            MONTH(c.fecha)

        ORDER BY
            periodo ASC

    ", [

        $fromDateTime,
        $toDateTime

    ]);

}


/* =========================================================
   11. MAPA DE COMPRAS
   ========================================================= */

$comprasMap = [];


foreach (
    $comprasPorPeriodo
    as $row
) {

    $comprasMap[
        $row['periodo']
    ] = [

        'inversion' =>
            (float)$row['inversion'],

        'operaciones' =>
            (int)$row['operaciones']

    ];

}


/* =========================================================
   12. ARRAYS DE COMPRAS
   ========================================================= */

$comprasLabels = [];

$comprasData = [];

$comprasOperations = [];


if (
    $groupMode === 'day'
) {

    $cursor =
        new DateTime($from);


    $end =
        new DateTime($to);


    while (
        $cursor <= $end
    ) {

        $key =
            $cursor->format(
                'Y-m-d'
            );


        $comprasLabels[] =
            $cursor->format(
                'd/m'
            );


        $comprasData[] =
            $comprasMap[$key]['inversion']
            ?? 0;


        $comprasOperations[] =
            $comprasMap[$key]['operaciones']
            ?? 0;


        $cursor->modify(
            '+1 day'
        );

    }

} else {

    $cursor =
        new DateTime(
            $fromObj->format(
                'Y-m-01'
            )
        );


    $end =
        new DateTime(
            $toObj->format(
                'Y-m-01'
            )
        );


    while (
        $cursor <= $end
    ) {

        $key =
            $cursor->format(
                'Y-m-01'
            );


        $comprasLabels[] =
            $cursor->format(
                'm/Y'
            );


        $comprasData[] =
            $comprasMap[$key]['inversion']
            ?? 0;


        $comprasOperations[] =
            $comprasMap[$key]['operaciones']
            ?? 0;


        $cursor->modify(
            '+1 month'
        );

    }

}


/* =========================================================
   13. TEXTO DEL PERÍODO
   ========================================================= */

$periodText =
    date(
        'd/m/Y',
        strtotime($from)
    )
    .
    ' - '
    .
    date(
        'd/m/Y',
        strtotime($to)
    );


/* =========================================================
   14. REPORTE DE STOCK E INVENTARIO
   ========================================================= */

$inventoryTab = $_GET['inventory_tab'] ?? 'resumen';

$allowedInventoryTabs = [
    'resumen',
    'compras',
    'ventas',
    'movimientos'
];

if (!in_array($inventoryTab, $allowedInventoryTabs, true)) {
    $inventoryTab = 'resumen';
}

$inventorySearch = trim((string)($_GET['inventory_search'] ?? ''));
$inventoryType   = trim((string)($_GET['inventory_type'] ?? ''));
$inventoryProduct = (int)($_GET['inventory_product'] ?? 0);

$inventoryProducts = allrows("
    SELECT
        id_producto,
        codigo,
        nombre,
        precio_venta,
        costo_promedio,
        stock_actual,
        stock_minimo
    FROM productos
    WHERE activo=1
    ORDER BY nombre
");

/*
 * Movimientos del período seleccionado.
 * La tabla movimientos_inventario ya existe en la base de datos
 * y guarda stock anterior, stock nuevo, compra/venta relacionada
 * y fecha del movimiento.
 */
$inventoryPeriodMovements = allrows("
    SELECT
        mi.id_movimiento,
        mi.id_producto,
        mi.tipo_movimiento,
        mi.cantidad,
        mi.stock_anterior,
        mi.stock_nuevo,
        mi.costo_unitario,
        mi.id_compra,
        mi.id_detalle_compra,
        mi.id_venta,
        mi.id_detalle_venta,
        mi.fecha,
        mi.observaciones,
        p.codigo,
        p.nombre AS producto
    FROM movimientos_inventario mi
    INNER JOIN productos p
        ON p.id_producto=mi.id_producto
    WHERE mi.fecha >= ?
      AND mi.fecha <= ?
    ORDER BY
        mi.id_producto ASC,
        mi.fecha ASC,
        mi.id_movimiento ASC
", [
    $fromDateTime,
    $toDateTime
]);

/*
 * Último stock conocido antes del inicio del período.
 */
$inventoryBefore = allrows("
    SELECT
        id_producto,
        stock_nuevo
    FROM movimientos_inventario
    WHERE fecha < ?
    ORDER BY
        id_producto ASC,
        fecha DESC,
        id_movimiento DESC
", [
    $fromDateTime
]);

$inventoryBeforeMap = [];

foreach ($inventoryBefore as $m) {
    $pid = (int)$m['id_producto'];

    if (!isset($inventoryBeforeMap[$pid])) {
        $inventoryBeforeMap[$pid] = (float)$m['stock_nuevo'];
    }
}

/*
 * Primer stock anterior registrado para productos que no tienen
 * un movimiento previo al período.
 */
$inventoryFirst = allrows("
    SELECT
        id_producto,
        stock_anterior
    FROM movimientos_inventario
    ORDER BY
        id_producto ASC,
        fecha ASC,
        id_movimiento ASC
");

$inventoryFirstMap = [];

foreach ($inventoryFirst as $m) {
    $pid = (int)$m['id_producto'];

    if (!isset($inventoryFirstMap[$pid])) {
        $inventoryFirstMap[$pid] = (float)$m['stock_anterior'];
    }
}

/*
 * Último stock registrado hasta la fecha final.
 */
$inventoryUntil = allrows("
    SELECT
        id_producto,
        stock_nuevo
    FROM movimientos_inventario
    WHERE fecha <= ?
    ORDER BY
        id_producto ASC,
        fecha DESC,
        id_movimiento DESC
", [
    $toDateTime
]);

$inventoryUntilMap = [];

foreach ($inventoryUntil as $m) {
    $pid = (int)$m['id_producto'];

    if (!isset($inventoryUntilMap[$pid])) {
        $inventoryUntilMap[$pid] = (float)$m['stock_nuevo'];
    }
}

/*
 * Construir resumen por producto.
 */
$inventorySummary = [];

foreach ($inventoryProducts as $p) {

    $pid = (int)$p['id_producto'];

    $stockAnterior =
        $inventoryBeforeMap[$pid]
        ?? $inventoryFirstMap[$pid]
        ?? (float)$p['stock_actual'];

    $stockFinal =
        $inventoryUntilMap[$pid]
        ?? (
            $inventoryBeforeMap[$pid]
            ?? (float)$p['stock_actual']
        );

    $entradas = 0.0;
    $salidas = 0.0;
    $retiros = 0.0;

    foreach ($inventoryPeriodMovements as $m) {

        if ((int)$m['id_producto'] !== $pid) {
            continue;
        }

        $cantidad = (float)$m['cantidad'];
        $tipo = (string)$m['tipo_movimiento'];

        switch ($tipo) {

            case 'ENTRADA_COMPRA':
            case 'ENTRADA_DEVOLUCION':
            case 'AJUSTE_ENTRADA':
                $entradas += $cantidad;
                break;

            case 'SALIDA_VENTA':
            case 'SALIDA_DEVOLUCION':
            case 'AJUSTE_SALIDA':
                $salidas += $cantidad;

                if ($tipo === 'AJUSTE_SALIDA') {
                    $retiros += $cantidad;
                }

                break;
        }
    }

    /*
     * Si existen movimientos del período, el stock final se toma
     * directamente del último movimiento para evitar diferencias
     * por redondeos o movimientos consecutivos.
     */
    $productPeriodMovements = [];

    foreach ($inventoryPeriodMovements as $m) {
        if ((int)$m['id_producto'] === $pid) {
            $productPeriodMovements[] = $m;
        }
    }

    if ($productPeriodMovements) {
        $last = end($productPeriodMovements);
        $stockFinal = (float)$last['stock_nuevo'];
        reset($productPeriodMovements);
    }

    /*
     * El stock anterior se conserva como el último stock antes
     * del período. Si el primer movimiento del período es el
     * primer movimiento histórico del producto, se usa su
     * stock_anterior.
     */
    $costoUnitario =
        (float)($p['costo_promedio'] ?? 0);

    /*
     * El inventario se valora con el costo promedio almacenado
     * en productos.costo_promedio, no con el precio de venta.
     */
    $costoTotal =
        $stockFinal * $costoUnitario;

    $inventorySummary[] = [
        'id_producto'    => $pid,
        'codigo'         => $p['codigo'],
        'producto'       => $p['nombre'],
        'stock_anterior' => $stockAnterior,
        'entradas'       => $entradas,
        'salidas'        => $salidas,
        'retiros'        => $retiros,
        'stock_final'    => $stockFinal,
        'costo_unitario' => $costoUnitario,
        'costo_total'    => $costoTotal
    ];
}

/*
 * Búsqueda y filtro del resumen.
 */
$inventorySummaryFiltered = [];

foreach ($inventorySummary as $r) {

    if ($inventoryProduct > 0 &&
        (int)$r['id_producto'] !== $inventoryProduct) {
        continue;
    }

    if ($inventorySearch !== '') {

        $needle = mb_strtolower(
            $inventorySearch,
            'UTF-8'
        );

        $haystack = mb_strtolower(
            (string)$r['codigo']
            . ' '
            . (string)$r['producto'],
            'UTF-8'
        );

        if (strpos($haystack, $needle) === false) {
            continue;
        }
    }

    $inventorySummaryFiltered[] = $r;
}

/*
 * COMPRAS del período.
 */
$purchaseReportSql = "
    SELECT
        c.id_compra,
        c.numero_factura,
        c.fecha,
        c.total,
        c.estado,
        m.codigo AS moneda,
        pr.nombre AS proveedor,
        pr.documento AS proveedor_documento,
        COALESCE(
            GROUP_CONCAT(
                DISTINCT CONCAT(
                    p.codigo,
                    ' - ',
                    p.nombre
                )
                ORDER BY p.nombre
                SEPARATOR ', '
            ),
            ''
        ) AS productos,
        COALESCE(
            SUM(dc.cantidad),
            0
        ) AS unidades
    FROM compras c
    INNER JOIN proveedores pr
        ON pr.id_proveedor=c.id_proveedor
    INNER JOIN monedas m
        ON m.id_moneda=c.id_moneda
    LEFT JOIN detalle_compras dc
        ON dc.id_compra=c.id_compra
    LEFT JOIN productos p
        ON p.id_producto=dc.id_producto
    WHERE c.estado='COMPLETADA'
      AND c.fecha >= ?
      AND c.fecha <= ?
";

$purchaseParams = [
    $fromDateTime,
    $toDateTime
];

if ($inventorySearch !== '') {

    $purchaseReportSql .= "
      AND (
            c.numero_factura LIKE ?
         OR pr.nombre LIKE ?
         OR pr.documento LIKE ?
         OR p.codigo LIKE ?
         OR p.nombre LIKE ?
      )
    ";

    $searchLike = '%' . $inventorySearch . '%';

    $purchaseParams[] = $searchLike;
    $purchaseParams[] = $searchLike;
    $purchaseParams[] = $searchLike;
    $purchaseParams[] = $searchLike;
    $purchaseParams[] = $searchLike;
}

if ($inventoryProduct > 0) {

    $purchaseReportSql .= "
      AND dc.id_producto=?
    ";

    $purchaseParams[] = $inventoryProduct;
}

$purchaseReportSql .= "
    GROUP BY
        c.id_compra,
        c.numero_factura,
        c.fecha,
        c.total,
        c.estado,
        m.codigo,
        pr.nombre,
        pr.documento
    ORDER BY c.fecha DESC, c.id_compra DESC
";

$inventoryPurchases =
    allrows(
        $purchaseReportSql,
        $purchaseParams
    );

/*
 * VENTAS del período.
 */
$saleReportSql = "
    SELECT
        v.id_venta,
        v.numero_factura,
        v.fecha,
        v.total,
        v.estado,
        v.origen,
        m.codigo AS moneda,
        COALESCE(cl.nombre, 'Consumidor final') AS cliente,
        COALESCE(cl.documento, '') AS cliente_documento,
        COALESCE(
            GROUP_CONCAT(
                DISTINCT CONCAT(
                    p.codigo,
                    ' - ',
                    p.nombre
                )
                ORDER BY p.nombre
                SEPARATOR ', '
            ),
            ''
        ) AS productos,
        COALESCE(
            SUM(dv.cantidad),
            0
        ) AS unidades
    FROM ventas v
    LEFT JOIN clientes cl
        ON cl.id_cliente=v.id_cliente
    INNER JOIN monedas m
        ON m.id_moneda=v.id_moneda
    LEFT JOIN detalle_ventas dv
        ON dv.id_venta=v.id_venta
    LEFT JOIN productos p
        ON p.id_producto=dv.id_producto
    WHERE v.estado='COMPLETADA'
      AND v.fecha >= ?
      AND v.fecha <= ?
";

$saleParams = [
    $fromDateTime,
    $toDateTime
];

if ($inventorySearch !== '') {

    $saleReportSql .= "
      AND (
            v.numero_factura LIKE ?
         OR cl.nombre LIKE ?
         OR cl.documento LIKE ?
         OR p.codigo LIKE ?
         OR p.nombre LIKE ?
      )
    ";

    $searchLike = '%' . $inventorySearch . '%';

    $saleParams[] = $searchLike;
    $saleParams[] = $searchLike;
    $saleParams[] = $searchLike;
    $saleParams[] = $searchLike;
    $saleParams[] = $searchLike;
}

if ($inventoryProduct > 0) {

    $saleReportSql .= "
      AND dv.id_producto=?
    ";

    $saleParams[] = $inventoryProduct;
}

$saleReportSql .= "
    GROUP BY
        v.id_venta,
        v.numero_factura,
        v.fecha,
        v.total,
        v.estado,
        v.origen,
        m.codigo,
        cl.nombre,
        cl.documento
    ORDER BY v.fecha DESC, v.id_venta DESC
";

$inventorySales =
    allrows(
        $saleReportSql,
        $saleParams
    );

/*
 * MOVIMIENTOS detallados del período.
 */
$movementReportSql = "
    SELECT
        mi.id_movimiento,
        mi.fecha,
        mi.tipo_movimiento,
        mi.cantidad,
        mi.stock_anterior,
        mi.stock_nuevo,
        mi.costo_unitario,
        mi.observaciones,

        p.id_producto,
        p.codigo,
        p.nombre AS producto,

        c.numero_factura AS compra_documento,
        pr.nombre AS proveedor,
        pr.documento AS proveedor_documento,

        v.numero_factura AS venta_documento,
        COALESCE(cl.nombre, 'Consumidor final') AS cliente,
        COALESCE(cl.documento, '') AS cliente_documento,

        u.nombre AS usuario

    FROM movimientos_inventario mi

    INNER JOIN productos p
        ON p.id_producto=mi.id_producto

    LEFT JOIN compras c
        ON c.id_compra=mi.id_compra

    LEFT JOIN proveedores pr
        ON pr.id_proveedor=c.id_proveedor

    LEFT JOIN ventas v
        ON v.id_venta=mi.id_venta

    LEFT JOIN clientes cl
        ON cl.id_cliente=v.id_cliente

    LEFT JOIN usuarios u
        ON u.id_usuario=mi.id_usuario

    WHERE mi.fecha >= ?
      AND mi.fecha <= ?
";

$movementParams = [
    $fromDateTime,
    $toDateTime
];

if ($inventoryType !== '') {

    $movementReportSql .= "
      AND mi.tipo_movimiento=?
    ";

    $movementParams[] = $inventoryType;
}

if ($inventoryProduct > 0) {

    $movementReportSql .= "
      AND mi.id_producto=?
    ";

    $movementParams[] = $inventoryProduct;
}

if ($inventorySearch !== '') {

    $movementReportSql .= "
      AND (
            p.codigo LIKE ?
         OR p.nombre LIKE ?
         OR c.numero_factura LIKE ?
         OR v.numero_factura LIKE ?
         OR pr.nombre LIKE ?
         OR pr.documento LIKE ?
         OR cl.nombre LIKE ?
         OR cl.documento LIKE ?
      )
    ";

    $searchLike = '%' . $inventorySearch . '%';

    for ($i = 0; $i < 8; $i++) {
        $movementParams[] = $searchLike;
    }
}

$movementReportSql .= "
    ORDER BY
        mi.fecha DESC,
        mi.id_movimiento DESC
";

$inventoryMovements =
    allrows(
        $movementReportSql,
        $movementParams
    );

/*
 * Totales del resumen.
 */
$inventoryTotalEntries = 0.0;
$inventoryTotalOutputs = 0.0;
$inventoryTotalWithdrawals = 0.0;
$inventoryTotalValue = 0.0;

foreach ($inventorySummaryFiltered as $r) {

    $inventoryTotalEntries +=
        (float)$r['entradas'];

    $inventoryTotalOutputs +=
        (float)$r['salidas'];

    $inventoryTotalWithdrawals +=
        (float)$r['retiros'];

    $inventoryTotalValue +=
        (float)$r['costo_total'];
}

?>


<section class="panel reports-header">

    <div class="reports-header-top">

        <div>

            <h2>
                Reportes
            </h2>

            <p class="muted">
                Ventas, ganancias, inversiones
                y productos más vendidos.
            </p>

        </div>

    </div>


    <!-- =====================================================
         FILTROS
         ===================================================== -->

    <form
        class="filter"
        method="get"
    >

        <label>

            Desde

            <input
                type="date"
                name="from"
                value="<?=e($from)?>"
                required
            >

        </label>


        <label>

            Hasta

            <input
                type="date"
                name="to"
                value="<?=e($to)?>"
                required
            >

        </label>


        <input
            type="hidden"
            name="page"
            value="reports"
        >


        <button
            class="btn primary"
            type="submit"
        >
            Consultar
        </button>

    </form>


    <!-- =====================================================
         RANGO RÁPIDO
         ===================================================== -->

    <div class="report-quick-ranges">

        <button
            type="button"
            data-range="today"
        >
            Hoy
        </button>

        <button
            type="button"
            data-range="week"
        >
            Últimos 7 días
        </button>

        <button
            type="button"
            data-range="month"
        >
            Este mes
        </button>

        <button
            type="button"
            data-range="year"
        >
            Este año
        </button>

    </div>


    <!-- =====================================================
         RESUMEN
         ===================================================== -->

    <div class="stats reports-stats">

        <div class="card">

            <small>
                Ventas
            </small>

            <b>
                <?=money($sales)?>
            </b>

            <span>
                <?=$salesCount?>
                <?=$salesCount === 1
                    ? 'venta'
                    : 'ventas'?>
            </span>

        </div>


        <div class="card">

            <small>
                Ganancia
            </small>

            <b>
                <?=money($profit)?>
            </b>

            <span>
                Ganancia del período
            </span>

        </div>


        <div class="card">

            <small>
                Inversión
            </small>

            <b>
                <?=money($investment)?>
            </b>

            <span>
                <?=$purchaseCount?>
                <?=$purchaseCount === 1
                    ? 'compra'
                    : 'compras'?>
            </span>

        </div>


        <div class="card">

            <small>
                Productos vendidos
            </small>

            <b>
                <?=quantity($unitsSold)?>
            </b>

            <span>
                Unidades
            </span>

        </div>

    </div>

</section>


<!-- =========================================================
     PRODUCTOS MÁS VENDIDOS
     ========================================================= -->

<section class="panel">

    <div class="report-section-title">

        <div>

            <h2>
                Productos más vendidos
            </h2>

            <p class="muted">
                Top 10 según el rango seleccionado.
            </p>

        </div>

    </div>


    <?php if ($top): ?>

        <div class="report-table-wrapper">

            <table>

                <thead>

                    <tr>

                        <th>
                            Producto
                        </th>

                        <th>
                            Cantidad
                        </th>

                        <th>
                            Ventas
                        </th>

                        <th>
                            Ganancia
                        </th>

                    </tr>

                </thead>


                <tbody>

                    <?php foreach (
                        $top
                        as $r
                    ): ?>

                        <tr>

                            <td>
                                <?=e(
                                    $r['nombre']
                                )?>
                            </td>


                            <td>
                                <?=quantity(
                                    $r['cantidad']
                                )?>
                            </td>


                            <td>
                                <?=money(
                                    $r['total']
                                )?>
                            </td>


                            <td>
                                <?=money(
                                    $r['ganancia']
                                )?>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                </tbody>

            </table>

        </div>

    <?php else: ?>

        <p class="muted">
            No hay ventas en el período seleccionado.
        </p>

    <?php endif; ?>

</section>


<!-- =========================================================
     GRÁFICAS
     ========================================================= -->

<section class="panel">

    <div class="report-section-title">

        <div>

            <h2>
                Análisis gráfico
            </h2>

            <p class="muted">
                Período:
                <?=e($periodText)?>
            </p>

        </div>

    </div>


    <div class="reports-chart-grid">


        <!-- =================================================
             GRÁFICA VENTAS
             ================================================= -->

        <div class="report-chart-card report-chart-wide">

            <div class="report-chart-heading">

                <div>

                    <h3>
                        Ventas, costo y ganancia
                    </h3>

                    <p>
                        Información
                        <?=$groupMode === 'day'
                            ? 'por día'
                            : 'por mes'?>
                    </p>

                </div>


                <strong>
                    <?=money($sales)?>
                </strong>

            </div>


            <div class="report-chart-body">

                <canvas
                    id="chartVentas"
                ></canvas>

            </div>

        </div>


        <!-- =================================================
             GRÁFICA INVERSIONES
             ================================================= -->

        <div class="report-chart-card">

            <div class="report-chart-heading">

                <div>

                    <h3>
                        Inversiones
                    </h3>

                    <p>
                        Compras del período
                    </p>

                </div>


                <strong>
                    <?=money($investment)?>
                </strong>

            </div>


            <div class="report-chart-body">

                <canvas
                    id="chartCompras"
                ></canvas>

            </div>

        </div>


        <!-- =================================================
             PRODUCTOS
             ================================================= -->

        <div class="report-chart-card">

            <div class="report-chart-heading">

                <div>

                    <h3>
                        Productos más vendidos
                    </h3>

                    <p>
                        Top 10
                    </p>

                </div>

            </div>


            <div class="report-chart-body products-chart">

                <canvas
                    id="chartTop"
                ></canvas>

            </div>

        </div>


    </div>

</section>


<!-- =========================================================
     CHART.JS
     ========================================================= -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>


<script>

(function () {

    'use strict';


    function moneyChart(value) {

        return '$' + Number(
            value || 0
        ).toLocaleString(
            'en-US',
            {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }
        );

    }


    /* =====================================================
       VENTAS
       ===================================================== */

    var ventasCanvas =
        document.getElementById(
            'chartVentas'
        );


    if (
        ventasCanvas &&
        typeof Chart !== 'undefined'
    ) {

        new Chart(
            ventasCanvas,
            {

                type: 'line',

                data: {

                    labels:
                        <?=json_encode(
                            $ventasLabels,
                            JSON_UNESCAPED_UNICODE
                        )?>,

                    datasets: [

                        {

                            label:
                                'Ventas',

                            data:
                                <?=json_encode(
                                    $ventasVendido
                                )?>,

                            borderWidth:
                                3,

                            tension:
                                .3,

                            fill:
                                false,

                            pointRadius:
                                4,

                            pointHoverRadius:
                                7

                        },


                        {

                            label:
                                'Costo',

                            data:
                                <?=json_encode(
                                    $ventasCosto
                                )?>,

                            borderWidth:
                                2,

                            borderDash:
                                [
                                    6,
                                    5
                                ],

                            tension:
                                .3,

                            fill:
                                false,

                            pointRadius:
                                3

                        },


                        {

                            label:
                                'Ganancia',

                            data:
                                <?=json_encode(
                                    $ventasGanancia
                                )?>,

                            borderWidth:
                                3,

                            tension:
                                .3,

                            fill:
                                false,

                            pointRadius:
                                4

                        }

                    ]

                },


                options: {

                    responsive:
                        true,

                    maintainAspectRatio:
                        false,

                    interaction: {

                        mode:
                            'index',

                        intersect:
                            false

                    },

                    plugins: {

                        legend: {

                            position:
                                'bottom'

                        },

                        tooltip: {

                            callbacks: {

                                label:
                                    function (
                                        context
                                    ) {

                                        return (
                                            context.dataset.label
                                            +
                                            ': '
                                            +
                                            moneyChart(
                                                context.raw
                                            )
                                        );

                                    }

                            }

                        }

                    },


                    scales: {

                        x: {

                            title: {

                                display:
                                    true,

                                text:
                                    <?=json_encode(
                                        $groupMode === 'day'
                                            ? 'Día'
                                            : 'Mes'
                                    )?>

                            },

                            grid: {

                                display:
                                    false

                            }

                        },


                        y: {

                            beginAtZero:
                                true,

                            ticks: {

                                callback:
                                    function (
                                        value
                                    ) {

                                        return moneyChart(
                                            value
                                        );

                                    }

                            }

                        }

                    }

                }

            }
        );

    }


    /* =====================================================
       INVERSIONES
       ===================================================== */

    var comprasCanvas =
        document.getElementById(
            'chartCompras'
        );


    if (
        comprasCanvas &&
        typeof Chart !== 'undefined'
    ) {

        new Chart(
            comprasCanvas,
            {

                type: 'bar',

                data: {

                    labels:
                        <?=json_encode(
                            $comprasLabels,
                            JSON_UNESCAPED_UNICODE
                        )?>,

                    datasets: [

                        {

                            label:
                                'Inversión',

                            data:
                                <?=json_encode(
                                    $comprasData
                                )?>,

                            borderWidth:
                                0,

                            borderRadius:
                                6,

                            maxBarThickness:
                                50

                        }

                    ]

                },


                options: {

                    responsive:
                        true,

                    maintainAspectRatio:
                        false,

                    plugins: {

                        legend: {

                            display:
                                false

                        },

                        tooltip: {

                            callbacks: {

                                label:
                                    function (
                                        context
                                    ) {

                                        return (
                                            'Inversión: '
                                            +
                                            moneyChart(
                                                context.raw
                                            )
                                        );

                                    }

                            }

                        }

                    },


                    scales: {

                        x: {

                            grid: {

                                display:
                                    false

                            }

                        },

                        y: {

                            beginAtZero:
                                true,

                            ticks: {

                                callback:
                                    function (
                                        value
                                    ) {

                                        return moneyChart(
                                            value
                                        );

                                    }

                            }

                        }

                    }

                }

            }
        );

    }


    /* =====================================================
       PRODUCTOS
       ===================================================== */

    var topCanvas =
        document.getElementById(
            'chartTop'
        );


    if (
        topCanvas &&
        typeof Chart !== 'undefined'
    ) {

        new Chart(
            topCanvas,
            {

                type: 'bar',

                data: {

                    labels:
                        <?=json_encode(
                            $topLabels,
                            JSON_UNESCAPED_UNICODE
                        )?>,

                    datasets: [

                        {

                            label:
                                'Unidades vendidas',

                            data:
                                <?=json_encode(
                                    $topQuantity
                                )?>,

                            borderWidth:
                                0,

                            borderRadius:
                                6

                        }

                    ]

                },


                options: {

                    indexAxis:
                        'y',

                    responsive:
                        true,

                    maintainAspectRatio:
                        false,

                    plugins: {

                        legend: {

                            display:
                                false

                        }

                    },


                    scales: {

                        x: {

                            beginAtZero:
                                true

                        },

                        y: {

                            grid: {

                                display:
                                    false

                            }

                        }

                    }

                }

            }

        );

    }


    /* =====================================================
       RANGOS RÁPIDOS
       ===================================================== */

    var rangeButtons =
        document.querySelectorAll(
            '[data-range]'
        );


    rangeButtons.forEach(
        function (button) {

            button.addEventListener(
                'click',
                function () {

                    var range =
                        button.getAttribute(
                            'data-range'
                        );


                    var today =
                        new Date();


                    var fromDate =
                        new Date(
                            today
                        );


                    if (
                        range === 'today'
                    ) {

                        fromDate =
                            new Date(
                                today
                            );

                    }


                    if (
                        range === 'week'
                    ) {

                        fromDate.setDate(
                            today.getDate() - 6
                        );

                    }


                    if (
                        range === 'month'
                    ) {

                        fromDate =
                            new Date(
                                today.getFullYear(),
                                today.getMonth(),
                                1
                            );

                    }


                    if (
                        range === 'year'
                    ) {

                        fromDate =
                            new Date(
                                today.getFullYear(),
                                0,
                                1
                            );

                    }


                    function formatDate(
                        date
                    ) {

                        return (
                            date.getFullYear()
                            +
                            '-'
                            +
                            String(
                                date.getMonth() + 1
                            ).padStart(
                                2,
                                '0'
                            )
                            +
                            '-'
                            +
                            String(
                                date.getDate()
                            ).padStart(
                                2,
                                '0'
                            )
                        );

                    }


                    var url =
                        new URL(
                            window.location.href
                        );


                    url.searchParams.set(
                        'page',
                        'reports'
                    );


                    url.searchParams.set(
                        'from',
                        formatDate(
                            fromDate
                        )
                    );


                    url.searchParams.set(
                        'to',
                        formatDate(
                            today
                        )
                    );


                    window.location.href =
                        url.toString();

                }
            );

        }
    );


})();

</script>



<?php if ($inventoryTab === 'resumen'): ?>

<!-- =========================================================
     REPORTE DE STOCK E INVENTARIO
     ========================================================= -->

<section
    class="panel inventory-report-panel"
    id="inventarioReportes"
>

    <div class="report-section-title">

        <div>

            <h2>
                Reporte de stock e inventario
            </h2>

            <p class="muted">
                Consulta el inventario correspondiente al
                rango de fechas seleccionado.
            </p>

        </div>

    </div>


    <!-- =====================================================
         FILTROS DEL REPORTE
         ===================================================== -->

    <form
        method="get"
        class="inventory-report-filters"
        id="stockReportFilterForm"
    >

        <input
            type="hidden"
            name="page"
            value="reports"
        >

        <label>

            Desde

            <input
                type="date"
                name="from"
                value="<?=e($from)?>"
                required
            >

        </label>


        <label>

            Hasta

            <input
                type="date"
                name="to"
                value="<?=e($to)?>"
                required
            >

        </label>


        <label class="inventory-report-search">

            Buscar

            <input
                type="search"
                name="inventory_search"
                value="<?=e($inventorySearch)?>"
                placeholder="Código o nombre del producto..."
                autocomplete="off"
            >

        </label>


        <label>

            Producto

            <select
                name="inventory_product"
            >

                <option value="0">
                    Todos los productos
                </option>

                <?php foreach ($inventoryProducts as $ip): ?>

                    <option
                        value="<?=e($ip['id_producto'])?>"
                        <?=(
                            $inventoryProduct ===
                            (int)$ip['id_producto']
                        ) ? 'selected' : ''?>
                    >
                        <?=e(
                            $ip['codigo']
                            . ' - '
                            . $ip['nombre']
                        )?>
                    </option>

                <?php endforeach; ?>

            </select>

        </label>


        <!-- =================================================
             BOTONES
             ================================================= -->

        <div class="inventory-report-filter-actions">

            <button
                type="submit"
                class="btn primary"
            >
                🔎 Buscar
            </button>


            <a
                class="btn"
                href="?page=reports&from=<?=e(urlencode($from))?>&to=<?=e(urlencode($to))?>"
            >
                Limpiar
            </a>


            <a
                class="btn primary"
                id="downloadStockExcel"
                href="pages/export_stock_excel.php?from=<?=e(urlencode($from))?>&to=<?=e(urlencode($to))?>&inventory_search=<?=e(urlencode($inventorySearch))?>&inventory_product=<?=e((int)$inventoryProduct)?>"
                title="Descargar resumen de inventario en Excel"
            >
                📊 Descargar Excel
            </a>

        </div>

    </form>


    <!-- =====================================================
         INFORMACIÓN DEL PERÍODO
         ===================================================== -->

    <div class="inventory-report-period">

        <span>
            Período seleccionado:
        </span>

        <strong>
            <?=e($periodText)?>
        </strong>

    </div>


    <div class="inventory-report-export-info">

        El reporte visible se utiliza únicamente para
        seleccionar los filtros. El detalle completo del
        inventario se genera al descargar el archivo Excel.

    </div>

</section>

<?php endif; ?>


<style>

.reports-header {

    margin-bottom: 18px;

}


.reports-header-top {

    display: flex;

    justify-content: space-between;

    align-items: center;

    margin-bottom: 20px;

}


.reports-header h2 {

    margin: 0;

}


.report-quick-ranges {

    display: flex;

    gap: 8px;

    flex-wrap: wrap;

    margin-top: 15px;

}


.report-quick-ranges button {

    border: 1px solid #d9e0e8;

    background: #fff;

    border-radius: 7px;

    padding: 7px 12px;

    cursor: pointer;

    font-size: 12px;

}


.report-quick-ranges button:hover {

    background: #f4f6fa;

}


.reports-stats {

    margin-top: 20px;

}


.reports-stats .card {

    display: flex;

    flex-direction: column;

    gap: 5px;

}


.reports-stats .card span {

    font-size: 11px;

    color: #7d8795;

}


.report-section-title {

    margin-bottom: 18px;

}


.report-section-title h2 {

    margin: 0 0 5px;

}


.report-table-wrapper {

    overflow-x: auto;

}


.report-table-wrapper table {

    width: 100%;

    border-collapse: collapse;

}


.report-table-wrapper th {

    text-align: left;

    background: #f5f7fa;

    padding: 11px;

    font-size: 12px;

}


.report-table-wrapper td {

    padding: 11px;

    border-top: 1px solid #edf0f3;

    font-size: 13px;

}


.reports-chart-grid {

    display: grid;

    grid-template-columns:
        repeat(2, minmax(0, 1fr));

    gap: 20px;

}


.report-chart-card {

    border: 1px solid #e1e6ed;

    border-radius: 12px;

    background: #fff;

    padding: 18px;

    min-width: 0;

}


.report-chart-wide {

    grid-column: 1 / -1;

}


.report-chart-heading {

    display: flex;

    justify-content: space-between;

    align-items: flex-start;

    gap: 15px;

    margin-bottom: 15px;

}


.report-chart-heading h3 {

    margin: 0 0 4px;

    font-size: 15px;

}


.report-chart-heading p {

    margin: 0;

    color: #7d8795;

    font-size: 12px;

}


.report-chart-heading strong {

    font-size: 16px;

}


.report-chart-body {

    position: relative;

    width: 100%;

    height: 360px;

}


.products-chart {

    height: 420px;

}


@media (max-width: 800px) {

    .reports-chart-grid {

        grid-template-columns: 1fr;

    }


    .report-chart-wide {

        grid-column: auto;

    }

}


@media (max-width: 600px) {

    .report-chart-heading {

        flex-direction: column;

    }

}


/* =========================================================
   REPORTE DE INVENTARIO / STOCK
   ========================================================= */

.inventory-report-panel {
    margin-top: 22px;
}

.inventory-report-export-info {
    margin-top: 12px;
    padding: 11px 14px;
    border: 1px solid #e1e6ed;
    border-radius: 9px;
    background: #f7f9fb;
    color: #657386;
    font-size: 12px;
    line-height: 1.5;
}


.inventory-report-tabs {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    margin: 18px 0;
    padding: 5px;
    background: #f4f6fa;
    border-radius: 10px;
    width: fit-content;
}

.inventory-report-tab {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 38px;
    padding: 0 18px;
    border-radius: 8px;
    color: #526174;
    text-decoration: none;
    font-size: 13px;
    font-weight: 600;
    transition: .15s ease;
}

.inventory-report-tab:hover {
    background: #fff;
    color: #1e4f7d;
}

.inventory-report-tab.active {
    background: #fff;
    color: #1e4f7d;
    box-shadow: 0 1px 4px rgba(24,34,56,.10);
}

.inventory-report-filters {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    align-items: end;
    padding: 16px;
    border: 1px solid #e1e6ed;
    border-radius: 12px;
    background: #fff;
    margin-bottom: 18px;
}

.inventory-report-filters label {
    display: flex;
    flex-direction: column;
    gap: 6px;
    color: #526174;
    font-size: 12px;
    font-weight: 600;
    flex: 1 1 160px;
    min-width: 160px;
}

.inventory-report-filters input,
.inventory-report-filters select {
    min-height: 40px;
    border: 1px solid #d9e0e8;
    border-radius: 8px;
    background: #fff;
    padding: 0 11px;
    color: #182238;
    outline: none;
}

.inventory-report-filters input:focus,
.inventory-report-filters select:focus {
    border-color: #4f7fa8;
    box-shadow: 0 0 0 3px rgba(79,127,168,.10);
}

.inventory-report-search {
    flex: 2 1 260px;
    min-width: 0;
}

.inventory-search-wrap {
    position: relative;
}

.inventory-search-wrap input {
    width: 100%;
    padding-right: 38px;
}

.inventory-search-clear {
    position: absolute;
    top: 50%;
    right: 10px;
    transform: translateY(-50%);
    width: 23px;
    height: 23px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    color: #7d8795;
    background: #eef1f5;
    font-size: 17px;
    line-height: 1;
}

.inventory-report-filter-actions {
    display: flex;
    gap: 7px;
    align-items: center;
    flex-wrap: wrap;
    flex: 1 1 100%;
    margin-top: 4px;
}

.inventory-report-filter-actions .btn {
    white-space: nowrap;
}
.inventory-report-cards {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 12px;
    margin-bottom: 18px;
}

.inventory-report-cards > div {
    border: 1px solid #e1e6ed;
    border-radius: 11px;
    background: #fff;
    padding: 15px;
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.inventory-report-cards small {
    color: #7d8795;
    font-size: 11px;
}

.inventory-report-cards strong {
    font-size: 18px;
}

.inventory-report-table-wrapper {
    overflow-x: auto;
    border: 1px solid #e1e6ed;
    border-radius: 10px;
}

.inventory-report-table {
    width: 100%;
    min-width: 980px;
    border-collapse: collapse;
}

.inventory-report-table th {
    background: #1f527d;
    color: #fff;
    padding: 11px 10px;
    font-size: 11px;
    font-weight: 700;
    white-space: nowrap;
    text-align: left;
}

.inventory-report-table td {
    padding: 10px;
    border-top: 1px solid #edf0f3;
    font-size: 12px;
    vertical-align: middle;
}

.inventory-report-table tbody tr:hover {
    background: #f8fafc;
}

.inventory-report-table tfoot th {
    background: #f4f6fa;
    color: #182238;
    border-top: 2px solid #dce2e9;
}

.inventory-empty {
    text-align: center;
    padding: 30px !important;
    color: #7d8795;
}

.inventory-positive {
    color: #19754b;
    font-weight: 700;
}

.inventory-negative {
    color: #b23b3b;
    font-weight: 700;
}

.inventory-products-cell {
    max-width: 360px;
    line-height: 1.45;
}

.inventory-movement-badge {
    display: inline-flex;
    align-items: center;
    border-radius: 999px;
    padding: 5px 9px;
    font-size: 10px;
    font-weight: 700;
    white-space: nowrap;
    background: #eef1f5;
    color: #526174;
}

.inventory-movement-badge.entrada {
    background: #eaf7f0;
    color: #19754b;
}

.inventory-movement-badge.salida {
    background: #fff0f0;
    color: #b23b3b;
}

@media (max-width: 1100px) {

    .inventory-report-cards {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

}

@media (max-width: 600px) {

    .inventory-report-tabs {
        width: 100%;
        overflow-x: auto;
    }

    .inventory-report-tab {
        flex: 1 0 auto;
        padding: 0 14px;
    }

       .inventory-report-filters {
        flex-direction: column;
        align-items: stretch;
    }

    .inventory-report-filters label {
        min-width: 0;
    }

    .inventory-report-cards {
        grid-template-columns: 1fr;
    }
}
/* =========================================================
   NUEVO DISEÑO REPORTE DE STOCK
   ========================================================= */

.inventory-report-panel{
    margin-top:22px;
}


.inventory-report-filters{
    display:grid;

    grid-template-columns:
        minmax(150px,170px)
        minmax(150px,170px)
        minmax(250px,1fr)
        minmax(210px,280px)
        auto;

    gap:12px;

    align-items:end;

    padding:16px;

    border:1px solid #e1e6ed;

    border-radius:12px;

    background:#fff;

    margin-bottom:12px;
}


.inventory-report-filters label{
    display:flex;

    flex-direction:column;

    gap:6px;

    color:#526174;

    font-size:12px;

    font-weight:600;
}


.inventory-report-filters input,
.inventory-report-filters select{
    min-height:40px;

    border:1px solid #d9e0e8;

    border-radius:8px;

    background:#fff;

    padding:0 11px;

    color:#182238;

    outline:none;
}


.inventory-report-filters input:focus,
.inventory-report-filters select:focus{
    border-color:#4f7fa8;

    box-shadow:
        0 0 0 3px
        rgba(79,127,168,.10);
}


.inventory-report-search{
    min-width:0;
}


.inventory-search-wrap{
    position:relative;
}


.inventory-search-wrap input{
    width:100%;

    padding-right:38px;
}


.inventory-search-clear{
    position:absolute;

    top:50%;

    right:10px;

    transform:translateY(-50%);

    width:23px;

    height:23px;

    border-radius:50%;

    display:flex;

    align-items:center;

    justify-content:center;

    text-decoration:none;

    color:#7d8795;

    background:#eef1f5;

    font-size:17px;

    line-height:1;
}


.inventory-report-filter-actions{
    display:flex;

    gap:8px;

    align-items:center;

    flex-wrap:wrap;
}


.inventory-report-period{
    display:flex;

    align-items:center;

    gap:7px;

    margin:0 0 15px;

    padding:11px 14px;

    border-radius:8px;

    background:#f5f7fa;

    color:#526174;

    font-size:12px;
}


.inventory-report-period strong{
    color:#182238;
}


.inventory-report-table-wrapper{
    width:100%;

    overflow-x:auto;

    border:1px solid #d9e0e8;

    border-radius:10px;

    background:#fff;
}


.inventory-report-table{
    width:100%;

    min-width:1100px;

    border-collapse:collapse;

    background:#fff;
}


.inventory-report-table th{
    background:#1f527d;

    color:#fff;

    padding:12px 10px;

    font-size:11px;

    font-weight:700;

    white-space:nowrap;

    text-align:center;

    vertical-align:middle;
}


.inventory-report-table td{
    padding:10px;

    border-top:1px solid #edf0f3;

    font-size:12px;

    vertical-align:middle;

    text-align:center;
}


.inventory-report-table td:nth-child(2),
.inventory-report-table td:nth-child(3){
    text-align:left;
}


.inventory-description{
    min-width:240px;
}


.inventory-report-table tbody tr:hover{
    background:#f8fafc;
}


.inventory-report-table tfoot th{
    background:#f4f6fa;

    color:#182238;

    border-top:2px solid #dce2e9;

    font-size:12px;
}


.inventory-empty{
    text-align:center;

    padding:35px !important;

    color:#7d8795;
}


.inventory-positive{
    color:#19754b;

    font-weight:700;
}


.inventory-negative{
    color:#b23b3b;

    font-weight:700;
}


/* =========================================================
   MODAL EXCEL
   ========================================================= */

.stock-excel-modal{
    position:fixed;

    inset:0;

    z-index:10000;

    display:none;

    align-items:center;

    justify-content:center;
}


.stock-excel-modal.show{
    display:flex;
}


.stock-excel-modal-overlay{
    position:absolute;

    inset:0;

    background:
        rgba(15,23,42,.58);
}


.stock-excel-modal-box{
    position:relative;

    z-index:2;

    width:min(
        480px,
        calc(100% - 30px)
    );

    padding:28px;

    background:#fff;

    border-radius:14px;

    box-shadow:
        0 25px 70px
        rgba(0,0,0,.28);

    text-align:center;
}


.stock-excel-modal-icon{
    width:55px;

    height:55px;

    margin:0 auto 12px;

    display:flex;

    align-items:center;

    justify-content:center;

    border-radius:12px;

    background:#eaf7f0;

    font-size:27px;
}


.stock-excel-modal-box h2{
    margin:0 0 8px;

    color:#182238;

    font-size:21px;
}


.stock-excel-modal-box p{
    margin:0;
}


.stock-excel-modal-close{
    position:absolute;

    top:10px;

    right:12px;

    width:35px;

    height:35px;

    border:0;

    background:transparent;

    color:#657386;

    font-size:27px;

    cursor:pointer;
}


.stock-excel-period{
    display:grid;

    grid-template-columns:1fr 1fr;

    gap:10px;

    margin:20px 0;
}


.stock-excel-period > div{
    display:flex;

    flex-direction:column;

    gap:5px;

    padding:12px;

    border:1px solid #e1e6ed;

    border-radius:9px;

    background:#f7f9fb;
}


.stock-excel-period span{
    color:#7d8795;

    font-size:11px;
}


.stock-excel-period strong{
    color:#182238;

    font-size:14px;
}


.stock-excel-modal-actions{
    display:flex;

    justify-content:flex-end;

    gap:8px;

    margin-top:20px;
}


body.stock-excel-open{
    overflow:hidden;
}


@media(max-width:1100px){

    .inventory-report-filters{
        grid-template-columns:
            repeat(2,minmax(0,1fr));
    }


    .inventory-report-search{
        grid-column:1 / -1;
    }


    .inventory-report-filter-actions{
        grid-column:1 / -1;
    }

}


@media(max-width:600px){

    .inventory-report-filters{
        grid-template-columns:1fr;
    }


    .inventory-report-search,
    .inventory-report-filter-actions{
        grid-column:auto;
    }


    .inventory-report-filter-actions{
        width:100%;

        flex-direction:column;
    }


    .inventory-report-filter-actions .btn{
        width:100%;

        text-align:center;
    }


    .inventory-report-period{
        flex-direction:column;

        align-items:flex-start;
    }


    .stock-excel-period{
        grid-template-columns:1fr;
    }


    .stock-excel-modal-box{
        padding:22px;
    }


    .stock-excel-modal-actions{
        flex-direction:column;
    }


    .stock-excel-modal-actions .btn{
        width:100%;

        text-align:center;
    }

}
</style>