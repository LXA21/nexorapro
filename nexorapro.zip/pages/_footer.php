</main>
</div>


<!-- JAVASCRIPT -->

<script
    src="assets/app.js?v=<?= filemtime(__DIR__.'/../assets/app.js') ?>"
></script>
</body>
</html>