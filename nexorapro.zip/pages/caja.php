<?php

$caja = caja_actual();

$monedas = allrows("
    SELECT *
    FROM monedas
    WHERE activo=1
    ORDER BY codigo
");

$cierreId = (int)($_GET['cierre'] ?? 0);
$cajaCierre = null;
$resumenCierre = null;

if ($cierreId) {

    $cajaCierre = one("
        SELECT *
        FROM caja_sesiones
        WHERE id_caja=?
    ", [$cierreId]);

    if ($cajaCierre) {
        $resumenCierre = caja_resumen($cierreId);
    }

}

$resumen = null;
$movimientos = [];

if ($caja) {

    $resumen = caja_resumen($caja['id_caja']);

    $movimientos = allrows("
        SELECT cm.*, m.codigo, m.simbolo
        FROM caja_movimientos cm
        JOIN monedas m ON m.id_moneda=cm.id_moneda
        WHERE cm.id_caja=?
        ORDER BY cm.fecha DESC
    ", [$caja['id_caja']]);

}
$historialCierres = caja_cierres_historial();

?>

<style>
    #cajaCierreTicket {
        max-width: 420px;
        margin: 0 auto;
        font-family: 'Courier New', monospace;
    }
    #cajaCierreTicket h2 {
        text-align: center;
        margin-bottom: 4px;
    }
    #cajaCierreTicket table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 14px;
    }
    #cajaCierreTicket td {
        padding: 2px 4px;
        font-size: 14px;
    }
    #cajaCierreTicket td:last-child {
        text-align: right;
    }
    #cajaCierreTicket tr.total td {
        font-weight: bold;
        border-top: 1px dashed #999;
    }
    #cajaCierreTicket tr.diff-ok td {
        color: #1a7a1a;
    }
    #cajaCierreTicket tr.diff-bad td {
        color: #b00020;
        font-weight: bold;
    }
    #cajaCierreTicket .seccion {
        font-weight: bold;
        border-bottom: 1px solid #333;
        margin: 14px 0 4px;
        padding-bottom: 2px;
    }
    
    /* =========================================================
       MODAL HISTORIAL DE CIERRES
       ========================================================= */

    #cajaHistorialModal {
        padding: 20px;
    }

    /* Modal un poco más grande */
    #cajaHistorialModal > div {
        width: min(1100px, 94vw);
        max-width: 1100px;
        min-height: 560px;
        max-height: 90vh;
        border-radius: 16px;
        overflow: auto;
    }

    /* Encabezado interno centrado */
    #cajaHistorialModal > div > .edit-modal-body {
        padding: 30px 34px;
        text-align: center;
    }

    /* Título */
    #cajaHistorialModal > div > .edit-modal-body h2 {
        text-align: center;
        font-size: 28px;
        line-height: 1.3;
        margin: 0 0 10px;
    }

    /* Texto de búsqueda */
    #cajaHistorialModal > div > .edit-modal-body > .muted {
        text-align: center;
        font-size: 16px;
        line-height: 1.5;
        margin: 0 auto 20px;
    }

    /* Buscador centrado */
    #cajaHistorialModal #cajaHistorialSearch {
        display: block;
        width: 75% !important;
        max-width: 700px;
        height: 48px;
        margin: 0 auto 18px !important;
        box-sizing: border-box;
    }

    /* Botón X */
    #cajaHistorialModal .edit-modal-close {
        font-size: 30px;
    }

    /* Franja azul del mismo tono de los botones primary */
    #cajaHistorialModal > div::before {
        content: "";
        display: block;
        height: 6px;
        width: 100%;
        background: #2563eb;
        border-radius: 16px 16px 0 0;
    }

    @media (max-width: 700px) {

        #cajaHistorialModal {
            padding: 10px;
        }

        #cajaHistorialModal > div {
            width: 96vw;
            min-height: 500px;
            max-height: 92vh;
            border-radius: 14px;
        }

        #cajaHistorialModal > div > .edit-modal-body {
            padding: 24px 18px;
        }

        #cajaHistorialModal > div > .edit-modal-body h2 {
            font-size: 23px;
            padding: 0 30px;
        }

        #cajaHistorialModal > div > .edit-modal-body > .muted {
            font-size: 14px;
            padding: 0 10px;
        }

        #cajaHistorialModal #cajaHistorialSearch {
            width: 92% !important;
            height: 46px;
        }
    }
</style>
<div class="no-print" style="display:flex;justify-content:flex-end;margin-bottom:16px;">
    <button
        type="button"
        class="btn primary"
        onclick="openCajaHistorialModal();"
    >
        📜 Historial de Cierres
    </button>
</div>


<div id="cajaHistorialModal" class="edit-modal" aria-hidden="true">

    <div class="edit-modal-box" role="dialog" aria-modal="true">

        <button
            type="button"
            class="edit-modal-close"
            onclick="closeCajaHistorialModal();"
            aria-label="Cerrar"
        >&times;</button>

        <div class="edit-modal-body">

           <h2>Historial de cierres de caja</h2>

          <p class="muted">
            Busca por número de cierre, fecha de apertura o fecha de cierre.
          </p>

    <input
    type="text"
    id="cajaHistorialSearch"
    placeholder="Buscar por número de cierre o fecha..."
    autocomplete="off"
    style="width:100%;margin-bottom:12px;"
    >

            <div id="cajaHistorialResults"></div>

            <div
                id="cajaHistorialPagination"
                style="display:flex;justify-content:center;gap:8px;margin-top:12px;flex-wrap:wrap;"
            ></div>

        </div>

    </div>

</div>


<script>
window.cajaCierres = <?=json_encode($historialCierres, JSON_UNESCAPED_UNICODE)?>;
</script>

<?php if ($cajaCierre): ?>

    <section class="panel">

        <div class="no-print" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
            <a href="index.php?page=caja" class="btn">&larr; Volver a caja</a>
<button type="button" class="btn primary" onclick="imprimirCierreCaja()">Imprimir cierre</button>
        </div>

        <div id="cajaCierreTicket">

            <h2>CIERRE DE CAJA</h2>
            <p style="text-align:center;margin-top:0;">
                Caja #<?=$cajaCierre['id_caja']?> ·
                Apertura: <?=e($cajaCierre['fecha_apertura'])?> ·
                Cierre: <?=e($cajaCierre['fecha_cierre'] ?? '—')?>
            </p>

            <div class="seccion">EFECTIVO</div>

            <?php foreach ($resumenCierre['efectivo'] as $ef): ?>

                <table>
                    <tbody>
                        <tr><td colspan="2"><b><?=e($ef['codigo'])?></b></td></tr>
                        <tr><td>Inicial</td><td><?=e($ef['simbolo'])?><?=number_format($ef['inicial'],2)?></td></tr>
                        <tr><td>Ventas efectivo</td><td><?=e($ef['simbolo'])?><?=number_format($ef['ventas'],2)?></td></tr>
                        <?php if ($ef['ingresos'] > 0): ?>
                            <tr><td>Ingresos</td><td>+<?=e($ef['simbolo'])?><?=number_format($ef['ingresos'],2)?></td></tr>
                        <?php endif; ?>
                        <?php if ($ef['retiros'] > 0): ?>
                            <tr><td>Retiros</td><td>-<?=e($ef['simbolo'])?><?=number_format($ef['retiros'],2)?></td></tr>
                        <?php endif; ?>
                        <tr class="total"><td>ESPERADO</td><td><?=e($ef['simbolo'])?><?=number_format($ef['esperado'],2)?></td></tr>
                        <tr class="total"><td>CONTADO</td><td><?=$ef['contado']===null ? '—' : e($ef['simbolo']).number_format($ef['contado'],2)?></td></tr>
                        <?php if ($ef['diferencia'] !== null): ?>
                            <tr class="<?=abs($ef['diferencia'])<0.01 ? 'diff-ok' : 'diff-bad'?>">
                                <td>DIFERENCIA</td>
                                <td><?=($ef['diferencia']>=0?'+':'').number_format($ef['diferencia'],2)?></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

            <?php endforeach; ?>

            <div class="seccion">PAGOS ELECTRÓNICOS</div>

            <table>
                <tbody>
                    <?php if (!$resumenCierre['electronico_totales']): ?>
                        <tr><td colspan="2">Sin pagos electrónicos</td></tr>
                    <?php endif; ?>
                    <?php foreach ($resumenCierre['electronico_totales'] as $et): ?>
                        <tr>
                            <td>Total <?=e($et['codigo'])?></td>
                            <td><?=e($et['simbolo'])?><?=number_format($et['total'],2)?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <?php if ($resumenCierre['electronico_detalle']): ?>
                <div class="seccion">Detalle por método</div>
                <table>
                    <tbody>
                        <?php foreach ($resumenCierre['electronico_detalle'] as $d): ?>
                            <tr>
                                <td><?=e($d['tipo_pago'])?> (<?=e($d['codigo'])?>)</td>
                                <td><?=e($d['simbolo'])?><?=number_format($d['total'],2)?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <?php if (!empty($cajaCierre['observaciones_cierre'])): ?>
                <p><b>Observaciones:</b> <?=e($cajaCierre['observaciones_cierre'])?></p>
            <?php endif; ?>

        </div>

    </section>


<?php elseif (!$caja): ?>

    <section class="panel">

        <h2>Abrir caja</h2>

        <p class="muted">
            Ingresa el efectivo con el que se inicia el día en cada moneda.
            Esto se usará como base para calcular lo esperado al cerrar caja.
        </p>

        <form method="post" action="actions.php">

            <input type="hidden" name="csrf" value="<?=e(csrf())?>">
            <input type="hidden" name="action" value="caja_open">
            <input type="hidden" name="return_page" value="caja">

            <div class="form-grid">

                <?php foreach ($monedas as $m): ?>

                    <label>
                        Inicial <?=e($m['codigo'])?> (<?=e($m['simbolo'])?>)

                        <input
                            type="number"
                            step="0.01"
                            min="0"
                            name="monto_inicial[<?=$m['id_moneda']?>]"
                            value="0"
                        >
                    </label>

                <?php endforeach; ?>

            </div>

            <label>
                Observaciones (opcional)
                <input type="text" name="observaciones">
            </label>

            <br>

            <button type="submit" class="btn primary">Abrir caja</button>

        </form>

    </section>


<?php else: ?>

    <section class="panel">

        <div style="display:flex;justify-content:space-between;align-items:center;">
            <h2>Caja abierta</h2>
            <span class="muted">
                Desde <?=e($caja['fecha_apertura'])?>
            </span>
        </div>

        <h3>Efectivo</h3>

        <table>
            <thead>
                <tr>
                    <th>Moneda</th>
                    <th>Inicial</th>
                    <th>Ventas efectivo</th>
                    <th>Ingresos</th>
                    <th>Retiros</th>
                    <th>Esperado ahora</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($resumen['efectivo'] as $ef): ?>
                    <tr>
                        <td><?=e($ef['codigo'])?></td>
                        <td><?=e($ef['simbolo'])?><?=number_format($ef['inicial'],2)?></td>
                        <td><?=e($ef['simbolo'])?><?=number_format($ef['ventas'],2)?></td>
                        <td><?=e($ef['simbolo'])?><?=number_format($ef['ingresos'],2)?></td>
                        <td><?=e($ef['simbolo'])?><?=number_format($ef['retiros'],2)?></td>
                        <td><b><?=e($ef['simbolo'])?><?=number_format($ef['esperado'],2)?></b></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <h3>Pagos electrónicos (hoy en esta caja)</h3>

        <table>
            <thead>
                <tr><th>Moneda</th><th>Total</th></tr>
            </thead>
            <tbody>
                <?php if (!$resumen['electronico_totales']): ?>
                    <tr><td colspan="2" class="muted">Sin pagos electrónicos aún</td></tr>
                <?php endif; ?>
                <?php foreach ($resumen['electronico_totales'] as $et): ?>
                    <tr>
                        <td><?=e($et['codigo'])?></td>
                        <td><?=e($et['simbolo'])?><?=number_format($et['total'],2)?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <h3>Retiros / Ingresos</h3>

        <form method="post" action="actions.php" class="form-grid">

            <input type="hidden" name="csrf" value="<?=e(csrf())?>">
            <input type="hidden" name="action" value="caja_movement">
            <input type="hidden" name="return_page" value="caja">

            <label>
                Tipo
                <select name="tipo" required>
                    <option value="RETIRO">Retiro</option>
                    <option value="INGRESO">Ingreso</option>
                </select>
            </label>

            <label>
                Moneda
                <select name="id_moneda" required>
                    <?php foreach ($monedas as $m): ?>
                        <option value="<?=$m['id_moneda']?>"><?=e($m['codigo'])?></option>
                    <?php endforeach; ?>
                </select>
            </label>

            <label>
                Monto
                <input type="number" step="0.01" min="0.01" name="monto" required>
            </label>

            <label>
                Motivo
                <input type="text" name="motivo" placeholder="Ej: pago a proveedor">
            </label>

            <div style="align-self:end;">
                <button type="submit" class="btn">Registrar</button>
            </div>

        </form>

        <table>
            <thead>
                <tr><th>Fecha</th><th>Tipo</th><th>Moneda</th><th>Monto</th><th>Motivo</th></tr>
            </thead>
            <tbody>
                <?php if (!$movimientos): ?>
                    <tr><td colspan="5" class="muted">Sin movimientos registrados</td></tr>
                <?php endif; ?>
                <?php foreach ($movimientos as $mv): ?>
                    <tr>
                        <td><?=e($mv['fecha'])?></td>
                        <td><?=e($mv['tipo'])?></td>
                        <td><?=e($mv['codigo'])?></td>
                        <td><?=e($mv['simbolo'])?><?=number_format($mv['monto'],2)?></td>
                        <td><?=e($mv['motivo'])?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <br>

        <button type="button" class="btn primary" onclick="document.getElementById('cajaCloseModal').setAttribute('aria-hidden','false');document.getElementById('cajaCloseModal').style.display='flex';">
            Cerrar caja
        </button>

    </section>


    <div id="cajaCloseModal" class="edit-modal" aria-hidden="true">

        <div class="edit-modal-box" role="dialog" aria-modal="true">

            <button
                type="button"
                class="edit-modal-close"
                onclick="document.getElementById('cajaCloseModal').style.display='none';"
                aria-label="Cerrar"
            >&times;</button>

            <div class="edit-modal-body">

                <h2>Cerrar caja</h2>

                <p class="muted">
                    Cuenta el efectivo físico que tienes en caja por cada moneda
                    y regístralo aquí. El sistema comparará lo contado contra
                    lo esperado.
                </p>

                <form method="post" action="actions.php">

                    <input type="hidden" name="csrf" value="<?=e(csrf())?>">
                    <input type="hidden" name="action" value="caja_close">
                    <input type="hidden" name="return_page" value="caja">

                    <div class="form-grid">

                        <?php foreach ($resumen['efectivo'] as $ef): ?>

                            <label>
                                Contado <?=e($ef['codigo'])?>
                                <span class="muted">(esperado <?=e($ef['simbolo'])?><?=number_format($ef['esperado'],2)?>)</span>

                                <input
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    name="monto_contado[<?=$ef['id_moneda']?>]"
                                    value="<?=number_format($ef['esperado'],2,'.','')?>"
                                >
                            </label>

                        <?php endforeach; ?>

                    </div>

                    <label>
                        Observaciones (opcional)
                        <input type="text" name="observaciones_cierre">
                    </label>

                    <br>

                    <button type="submit" class="btn primary">Confirmar cierre de caja</button>

                </form>

            </div>

        </div>

    </div>
    
<?php endif; ?>
<script>
function imprimirCierreCaja() {

    const contenido = document.getElementById('cajaCierreTicket');

    if (!contenido) {
        alert('No se encontró el cierre de caja para imprimir.');
        return;
    }

    const ventana = window.open('', '_blank', 'width=420,height=700');

    if (!ventana) {
        alert('El navegador bloqueó la ventana de impresión. Permite ventanas emergentes para este sitio.');
        return;
    }

    ventana.document.open();

    ventana.document.write(`
        <!doctype html>
        <html lang="es">
        <head>
            <meta charset="utf-8">

            <title>Cierre de caja</title>

            <style>

                * {
                    box-sizing: border-box;
                }

                html,
                body {
                    width: 80mm;
                    margin: 0;
                    padding: 0;
                    background: #fff;
                    color: #000;
                }

                body {
                    font-family: "Courier New", monospace;
                    font-size: 11px;
                    line-height: 1.35;
                }

                #cajaCierreTicket {
                    width: 80mm;
                    max-width: 80mm;
                    padding: 3mm;
                    margin: 0;
                }

                #cajaCierreTicket table {
                    width: 100%;
                    border-collapse: collapse;
                }

                #cajaCierreTicket td {
                    padding: 1px 0;
                    vertical-align: top;
                }

                #cajaCierreTicket td:last-child {
                    text-align: right;
                    white-space: nowrap;
                }

                #cajaCierreTicket .ticket-logo {
                    display: block;
                    max-width: 55mm;
                    max-height: 20mm;
                    margin: 0 auto 5px;
                }

                #cajaCierreTicket .ticket-center {
                    text-align: center;
                }

                #cajaCierreTicket .ticket-bold {
                    font-weight: bold;
                }

                #cajaCierreTicket .ticket-divider {
                    border-top: 1px dashed #000;
                    margin: 6px 0;
                }

                #cajaCierreTicket .ticket-section {
                    font-weight: bold;
                    text-align: center;
                    margin: 7px 0 4px;
                }

                #cajaCierreTicket .ticket-total td {
                    font-weight: bold;
                    border-top: 1px dashed #000;
                    padding-top: 3px;
                }

                #cajaCierreTicket .ticket-info {
                    margin: 1px 0;
                }

                .no-print {
                    display: none !important;
                }

                @page {
                    size: 80mm auto;
                    margin: 0;
                }

            </style>
        </head>

        <body>

            ${contenido.outerHTML}

        </body>
        </html>
    `);

    ventana.document.close();

    ventana.onload = function () {

        setTimeout(function () {

            ventana.focus();

            ventana.print();

            ventana.onafterprint = function () {
                ventana.close();
            };

        }, 300);

    };
}
</script>