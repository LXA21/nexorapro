<?php

$baseCurrency = base_currency();

$clients = allrows("
    SELECT
        id_cliente,
        nombre,
        documento
    FROM clientes
    WHERE activo=1
    ORDER BY nombre
");

$cur = allrows("
    SELECT *
    FROM monedas
    WHERE activo=1
    ORDER BY codigo
");

$methods = allrows("
    SELECT
        mp.*,
        m.codigo AS moneda,
        m.tasa_referencia AS tasa,
        m.simbolo AS simbolo_moneda
    FROM metodos_pago mp
    JOIN monedas m
        ON m.id_moneda = mp.id_moneda
    WHERE mp.activo = 1
    ORDER BY mp.nombre
");

?>

<link rel="stylesheet" href="assets/tpv.css">

<script>
window.tpvCurrency = <?=json_encode($baseCurrency, JSON_UNESCAPED_UNICODE)?>;
window.tpvCurrencies = <?=json_encode($cur, JSON_UNESCAPED_UNICODE)?>;
window.tpvPaymentMethods = <?=json_encode($methods, JSON_UNESCAPED_UNICODE)?>;
</script>

<section class="panel tpv-panel">

    <h2>Punto de venta (TPV)</h2>

    <div class="tpv-scan-bar">

        <input
            type="text"
            id="tpvScanInput"
            placeholder="Escanea el código y presiona Enter…"
            autocomplete="off"
            autofocus
        >

        <button type="button" class="btn" id="tpvCameraBtn">
            📷 Cámara
        </button>

    </div>

    <div class="tpv-search-wrap">

        <input
            type="text"
            id="tpvSearchInput"
            placeholder="Buscar producto por nombre o código…"
            autocomplete="off"
        >

        <div id="tpvSearchResults" class="tpv-search-results"></div>

    </div>

    <div id="tpvScanMsg" class="tpv-scan-msg"></div>


    <form method="post" action="actions.php" id="tpvForm">

        <input type="hidden" name="csrf" value="<?=e(csrf())?>">
        <input type="hidden" name="action" value="tpv_sale_save">
        <input type="hidden" name="moneda" value="<?=(int)$baseCurrency['id_moneda']?>">

        <div class="form-grid">

            <label>
                Cliente

                <select name="cliente" data-combo-search="Buscar cliente por nombre o documento…">
                    <option value="0">Consumidor final</option>
                    <?php foreach($clients as $c): ?>
                        <option
                            value="<?=$c['id_cliente']?>"
                            data-documento="<?=e($c['documento'] ?? '')?>"
                        >
                            <?=e($c['nombre'])?>
                        </option>
                    <?php endforeach; ?>
                </select>

            </label>

            <label>
                Impuesto (%)

                <input
                    type="number"
                    step="0.01"
                    name="impuesto"
                    id="tpvTax"
                    value="0"
                >

            </label>

        </div>


        <table id="tpvCartTable">
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Precio</th>
                    <th>Cant.</th>
                    <th>Subtotal</th>
                    <th></th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>


        <div class="summary">
            <span>
                Subtotal
                <b id="tpvSubtotal"><?=money(0, $baseCurrency['simbolo'])?></b>
            </span>
            <span>
                Impuesto
                <b id="tpvTaxAmount"><?=money(0, $baseCurrency['simbolo'])?></b>
            </span>
            <span>
                Total
                <b id="tpvTotal"><?=money(0, $baseCurrency['simbolo'])?></b>
            </span>
        </div>

        <div id="tpvConversions" class="muted tpv-conversions"></div>


        <h3>Pago</h3>

        <div class="form-grid">

            <label>
                Método

                <select name="payment_method" id="tpvPaymentMethod" required>
                    <option value="">Seleccione</option>
                    <?php foreach($methods as $m): ?>
                        <option
                            value="<?=$m['id_metodo_pago']?>"
                            data-tasa="<?=e($m['tasa'])?>"
                            data-moneda="<?=e($m['moneda'])?>"
                            data-simbolo="<?=e($m['simbolo_moneda'])?>"
                        >
                            <?=e($m['nombre'])?> · <?=e($m['moneda'])?>
                        </option>
                    <?php endforeach; ?>
                </select>

            </label>

            <input type="hidden" name="payment_rate" id="tpvPaymentRate" value="1">

            <label>
                Monto recibido

                <input
                    type="number"
                    step="0.01"
                    name="payment_amount"
                    id="tpvPaymentAmount"
                >
            </label>

            <label>
                Cambio

                <input type="text" id="tpvChange" disabled>
            </label>

        </div>


        <br>


        <button
            type="submit"
            class="btn primary"
            id="tpvSubmitBtn"
            disabled
        >
            Cobrar e imprimir ticket
        </button>

    </form>

</section>


<!-- Modal de cámara -->
<div id="tpvCameraModal" class="edit-modal">

    <div class="edit-modal-box" style="max-width:420px;">

        <button type="button" class="edit-modal-close" id="tpvCameraClose">&times;</button>

        <h3>Escanear con la cámara</h3>

        <div id="tpvCameraReader"></div>

    </div>

</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/html5-qrcode/2.3.8/html5-qrcode.min.js"></script>
<script src="assets/tpv.js?v=<?=time()?>"></script>