<?php
require_once __DIR__.'/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
function csrf(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function check_csrf(): void {
    if ($_SERVER['REQUEST_METHOD']==='POST' && !hash_equals($_SESSION['csrf']??'', $_POST['csrf']??'')) {
        http_response_code(419); exit('Token CSRF inválido.');
    }
}
function user(): ?array { return $_SESSION['user'] ?? null; }
function login_user(array $u): void { $_SESSION['user']=$u; }
function logout_user(): void { $_SESSION=[]; session_destroy(); }
function require_login(): void { if (!user()) { header('Location: login.php'); exit; } }
function admin_only(): void { if ((user()['rol']??'')!=='Administrador') { http_response_code(403); exit('Acceso no autorizado.'); } }

/*
|--------------------------------------------------------------------------
| PERMISOS POR MÓDULO (ROLES)
|--------------------------------------------------------------------------
|
| Administrador       -> acceso a todos los módulos.
| Vendedor TPV        -> acceso únicamente al Punto de Venta (tpv).
| Vendedor            -> módulos esenciales de venta: ventas, compras,
|                        facturación, clientes y proveedores. NO puede
|                        crear/editar/eliminar productos ni inventario.
| Cualquier otro rol  -> se mantiene el comportamiento que ya existía
|                        antes de este cambio (acceso a todo excepto
|                        los módulos exclusivos de Administrador), para
|                        no alterar roles ya creados como "Inventario".
|
*/

function role_allowed_pages(): array {

    $todas = [
        'dashboard','products','inventory','sales','invoices','tpv','caja',
        'clients','purchases','suppliers','payments','reports',
        'backups','users','settings'
    ];

    $rol = user()['rol'] ?? '';

    switch ($rol) {

        case 'Administrador':
            return $todas;

        case 'Vendedor TPV':
            return ['tpv','caja'];

        default:
            return array_values(array_diff($todas, ['users','backups','settings']));
    }
}

function can_access_page(string $page): bool {
    return in_array($page, role_allowed_pages(), true);
}

/*
 * Para usar dentro de actions.php (dentro del try/catch general):
 * lanza una excepción que actions.php ya sabe mostrar como mensaje
 * de error (flash danger) en vez de cortar la ejecución con un 403.
 */
function require_module_access(string $page): void {
    if (!can_access_page($page)) {
        throw new Exception('No tienes permiso para realizar esta acción.');
    }
}