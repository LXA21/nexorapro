<?php

require_once __DIR__.'/auth.php';


function e($v): string {
    return htmlspecialchars(
        (string)$v,
        ENT_QUOTES,
        'UTF-8'
    );
}


function money($v,$s='$'): string {
    return $s.number_format(
        (float)$v,
        2,
        '.',
        ','
    );
}


/*
|--------------------------------------------------------------------------
| FORMATO DE CANTIDADES
|--------------------------------------------------------------------------
|
| Solo modifica la forma visual en que se muestran las cantidades.
|
| Ejemplos:
|
| 3.000  -> 3
| 19.000 -> 19
| 30.000 -> 30
| 2.500  -> 2.5
| 1.250  -> 1.25
|
| NO modifica la base de datos ni el valor real.
|--------------------------------------------------------------------------
*/

function quantity($value): string {

    $value = (float)$value;


    /*
     * Si es un número entero, mostrarlo sin decimales.
     */

    if (floor($value) == $value) {

        return number_format(
            $value,
            0,
            '.',
            ''
        );

    }


    /*
     * Si tiene decimales reales, mostrar
     * hasta 3 decimales y eliminar ceros
     * innecesarios al final.
     */

    return rtrim(
        rtrim(
            number_format(
                $value,
                3,
                '.',
                ''
            ),
            '0'
        ),
        '.'
    );

}


function flash($type=null,$msg=null) {

    if ($msg!==null) {

        $_SESSION['flash']=[
            $type,
            $msg
        ];

        return;
    }


    $f=$_SESSION['flash']??null;

    unset(
        $_SESSION['flash']
    );


    return $f;
}


function one($sql,$p=[]): ?array {

    $s=db()->prepare(
        $sql
    );

    $s->execute(
        $p
    );

    $r=$s->fetch();


    return $r?:null;
}


function allrows($sql,$p=[]): array {

    $s=db()->prepare(
        $sql
    );

    $s->execute(
        $p
    );


    return $s->fetchAll();
}


/**
 * Genera un código de barras EAN-13 numérico aleatorio
 * y garantiza que no exista ya en la tabla productos.
 * Se usa un prefijo "20" (rango estándar para uso interno/local)
 * + 10 dígitos aleatorios + 1 dígito verificador EAN-13.
 */
function generate_unique_barcode(): string {

    do {

        $body = '20';


        for (
            $i = 0;
            $i < 10;
            $i++
        ) {

            $body .= random_int(
                0,
                9
            );

        }


        $codigo =
            $body .
            ean13_check_digit(
                $body
            );


        $existe = one(
            "SELECT id_producto FROM productos WHERE codigo = ?",
            [$codigo]
        );


    } while ($existe);


    return $codigo;
}


function ean13_check_digit(
    string $twelveDigits
): string {

    $sum = 0;


    for (
        $i = 0;
        $i < 12;
        $i++
    ) {

        $digit =
            (int)$twelveDigits[$i];


        $sum +=
            ($i % 2 === 0)
                ? $digit
                : $digit * 3;

    }


    $checkDigit =
        (10 - ($sum % 10)) % 10;


    return (string)$checkDigit;
}


function post($k,$d=null) {

    return $_POST[$k]??$d;
}


function redirect($u) {

    header(
        'Location: '.$u
    );

    exit;
}


function base_currency(): array {

    return one("
        SELECT *
        FROM monedas
        WHERE es_moneda_base=1
          AND activo=1
        LIMIT 1
    ") ?: [

        'codigo'=>'USD',
        'simbolo'=>'$',
        'tasa_referencia'=>1,
        'id_moneda'=>1

    ];

}


/*
|--------------------------------------------------------------------------
| CONFIGURACIÓN GENERAL DE LA EMPRESA
|--------------------------------------------------------------------------
*/

function company_settings(): array {

    $settings = one("
        SELECT *
        FROM configuracion_empresa
        ORDER BY id_configuracion ASC
        LIMIT 1
    ");


    return $settings ?: [

        'id_configuracion' => 0,
        'razon_social' => '',
        'nombre_comercial' => '',
        'tipo_identificacion_fiscal' => 'NIT',
        'identificacion_fiscal' => '',
        'direccion_fiscal' => '',
        'telefono' => '',
        'correo' => '',
        'logotipo' => '',
        'resolucion_fiscal' => '',
        'fecha_resolucion' => null,
        'fecha_vencimiento_resolucion' => null,
        'prefijo_factura' => 'F-',
        'numero_inicial' => 1,
        'numero_actual' => 1,
        'numero_final' => null,
        'id_moneda_predeterminada' => 0,
        'decimales' => 2,
        'dias_credito' => 0,
        'formas_pago_habituales' => '',
        'forma_pago_predeterminada' => '',
        'impuesto_general' => 0,
        'retencion' => 0,
        'impuesto_local' => 0,
        'regimen_fiscal' => '',
        'cuenta_ventas' => '',
        'cuenta_compras' => '',
        'cuenta_impuestos' => '',
        'cuenta_retenciones' => '',
        'entorno' => 'PRUEBAS'

    ];

}


/*
|--------------------------------------------------------------------------
| ENTRADA DE INVENTARIO
|--------------------------------------------------------------------------
| Aumenta stock_actual cuando entra mercancía.
*/

function product_stock_in(
    PDO $pdo,
    int $id,
    float $qty,
    float $cost
): void {

    $p=one("
        SELECT stock_actual,costo_promedio
        FROM productos
        WHERE id_producto=?
        FOR UPDATE
    ",[
        $id
    ]);


    if(!$p) {

        throw new Exception(
            'Producto no encontrado.'
        );

    }


    $old =
        (float)$p['stock_actual'];


    $oldc =
        (float)$p['costo_promedio'];


    $new =
        $old + $qty;


    $avg =
        $new > 0
            ? (
                (($old*$oldc)+($qty*$cost))
                / $new
            )
            : $cost;


    $pdo->prepare("
        UPDATE productos
        SET
            stock_actual=?,
            precio_compra=?,
            costo_promedio=?
        WHERE id_producto=?
    ")->execute([

        $new,
        $cost,
        $avg,
        $id

    ]);

}


/*
|--------------------------------------------------------------------------
| SALIDA DE INVENTARIO
|--------------------------------------------------------------------------
| Disminuye stock_actual cuando se vende mercancía.
*/

function product_stock_out(
    PDO $pdo,
    int $id,
    float $qty
): float {

    $p=one("
        SELECT stock_actual
        FROM productos
        WHERE id_producto=?
        FOR UPDATE
    ",[
        $id
    ]);


    if(!$p) {

        throw new Exception(
            'Producto no encontrado.'
        );

    }


    $old =
        (float)$p['stock_actual'];


    if(
        $old + 0.00001 < $qty
    ) {

        throw new Exception(
            "Stock insuficiente. Disponible: ".$old
        );

    }


    $pdo->prepare("
        UPDATE productos
        SET stock_actual=?
        WHERE id_producto=?
    ")->execute([

        $old - $qty,
        $id

    ]);


    return $old;
}


/*
|--------------------------------------------------------------------------
| CAJA (APERTURA / MOVIMIENTOS / CIERRE)
|--------------------------------------------------------------------------
*/

/**
 * Devuelve la sesión de caja abierta actualmente, o null si no hay
 * ninguna caja abierta.
 */
function caja_actual(): ?array {

    return one("
        SELECT *
        FROM caja_sesiones
        WHERE estado='ABIERTA'
        ORDER BY id_caja DESC
        LIMIT 1
    ");

}


/**
 * Igual que caja_actual() pero lanza una excepción si no hay
 * caja abierta. Úsalo en las acciones que requieren caja activa
 * (por ejemplo, registrar una venta de TPV).
 */
function caja_requerida(): array {

    $caja = caja_actual();

    if (!$caja) {

        throw new Exception(
            'No hay una caja abierta. Debes abrir caja antes de continuar.'
        );

    }

    return $caja;

}


/**
 * Arma el resumen completo de una sesión de caja (abierta o
 * cerrada): efectivo por moneda (inicial, ventas, retiros,
 * ingresos, esperado, contado, diferencia) y pagos electrónicos
 * agrupados por método/moneda.
 */
function caja_resumen(int $idCaja): array {

    $monedas = allrows("
        SELECT id_moneda, codigo, nombre, simbolo
        FROM monedas
        WHERE activo=1
        ORDER BY codigo
    ");


    $iniciales = allrows("
        SELECT id_moneda, monto
        FROM caja_montos
        WHERE id_caja=? AND tipo='INICIAL'
    ", [$idCaja]);

    $contados = allrows("
        SELECT id_moneda, monto
        FROM caja_montos
        WHERE id_caja=? AND tipo='CONTADO'
    ", [$idCaja]);

    $ventasEfectivo = allrows("
        SELECT mp.id_moneda, SUM(pv.monto) AS total
        FROM pagos_ventas pv
        JOIN ventas v ON v.id_venta=pv.id_venta
        JOIN metodos_pago mp ON mp.id_metodo_pago=pv.id_metodo_pago
        WHERE v.id_caja=?
          AND v.estado='COMPLETADA'
          AND mp.tipo_pago='EFECTIVO'
        GROUP BY mp.id_moneda
    ", [$idCaja]);

    $ventasElectronico = allrows("
        SELECT mp.id_moneda, mp.tipo_pago, m.codigo, m.simbolo, SUM(pv.monto) AS total
        FROM pagos_ventas pv
        JOIN ventas v ON v.id_venta=pv.id_venta
        JOIN metodos_pago mp ON mp.id_metodo_pago=pv.id_metodo_pago
        JOIN monedas m ON m.id_moneda=mp.id_moneda
        WHERE v.id_caja=?
          AND v.estado='COMPLETADA'
          AND mp.tipo_pago<>'EFECTIVO'
        GROUP BY mp.id_moneda, mp.tipo_pago
    ", [$idCaja]);

    $retiros = allrows("
        SELECT id_moneda, SUM(monto) AS total
        FROM caja_movimientos
        WHERE id_caja=? AND tipo='RETIRO'
        GROUP BY id_moneda
    ", [$idCaja]);

    $ingresos = allrows("
        SELECT id_moneda, SUM(monto) AS total
        FROM caja_movimientos
        WHERE id_caja=? AND tipo='INGRESO'
        GROUP BY id_moneda
    ", [$idCaja]);


    $idx = function(array $rows, string $col='monto') {

        $out = [];

        foreach ($rows as $r) {
            $out[(int)$r['id_moneda']] = (float)$r[$col];
        }

        return $out;

    };

    $mIni  = $idx($iniciales);
    $mCont = $idx($contados);
    $mVen  = $idx($ventasEfectivo, 'total');
    $mRet  = $idx($retiros, 'total');
    $mIng  = $idx($ingresos, 'total');


    $efectivo = [];

    foreach ($monedas as $m) {

        $id = (int)$m['id_moneda'];

        $inicial  = $mIni[$id]  ?? 0;
        $ventas   = $mVen[$id]  ?? 0;
        $retiro   = $mRet[$id]  ?? 0;
        $ingreso  = $mIng[$id]  ?? 0;
        $esperado = $inicial + $ventas + $ingreso - $retiro;
        $contado  = $mCont[$id] ?? null;

        $efectivo[] = [
            'id_moneda'  => $id,
            'codigo'     => $m['codigo'],
            'nombre'     => $m['nombre'],
            'simbolo'    => $m['simbolo'],
            'inicial'    => $inicial,
            'ventas'     => $ventas,
            'retiros'    => $retiro,
            'ingresos'   => $ingreso,
            'esperado'   => $esperado,
            'contado'    => $contado,
            'diferencia' => $contado===null ? null : ($contado - $esperado)
        ];

    }


    $electronicoTotales = [];

    foreach ($ventasElectronico as $row) {

        $cod = $row['codigo'];

        if (!isset($electronicoTotales[$cod])) {
            $electronicoTotales[$cod] = [
                'codigo'  => $cod,
                'simbolo' => $row['simbolo'],
                'total'   => 0
            ];
        }

        $electronicoTotales[$cod]['total'] += (float)$row['total'];

    }


    return [
        'efectivo'            => $efectivo,
        'electronico_detalle' => $ventasElectronico,
        'electronico_totales' => array_values($electronicoTotales)
    ];

}
/**
 * Devuelve el historial de facturas (ventas) generadas dentro de
 * sesiones de caja (id_caja no nulo), incluyendo los productos de
 * cada una para poder buscarlas por código o nombre de producto.
 */
/* =========================================================
   HISTORIAL DE CIERRES DE CAJA
   ========================================================= */

function caja_cierres_historial() {

    return allrows("
        SELECT
            cs.id_caja,
            cs.fecha_apertura,
            cs.fecha_cierre,
            cs.estado,
            cs.observaciones_cierre

        FROM caja_sesiones cs

        WHERE cs.estado = 'CERRADA'

        ORDER BY
            cs.fecha_cierre DESC,
            cs.id_caja DESC
    ");

}