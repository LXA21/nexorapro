<?php

require_once __DIR__.'/functions.php';

require_login();

header('Content-Type: application/json; charset=utf-8');

// ---------------------------------------------------------
// MODO 1: BÚSQUEDA POR CÓDIGO EXACTO (usado por el escáner)
// ---------------------------------------------------------
if (isset($_GET['codigo'])) {

    $raw = trim($_GET['codigo']);

    if ($raw === '') {
        echo json_encode(['found' => false]);
        exit;
    }

    // Quitamos espacios/saltos de línea que a veces agrega el
    // lector de cámara o un lector físico USB.
    $code = preg_replace('/\s+/', '', $raw);

    // Búsqueda EXACTA como base. Este endpoint lo usa tanto el
    // lector de cámara como el input de escaneo por teclado, y en
    // ambos casos el código escaneado debe coincidir con el que
    // el sistema tiene guardado para ese producto. No se permite
    // coincidencia parcial por nombre aquí (eso es tarea del
    // buscador manual, más abajo) para evitar que un código no
    // registrado "encuentre" un producto por error.
    //
    // Además del código tal cual, probamos variantes UPC-A/EAN-13:
    // el detector de códigos de barras nativo del navegador (usado
    // por la cámara) suele convertir un código UPC-A de 12 dígitos
    // en su equivalente EAN-13 de 13 dígitos anteponiendo un "0",
    // y viceversa. Si el producto se registró con una de las dos
    // formas y la cámara entrega la otra, sin esto no se encuentra
    // aunque el producto sí exista.
    $candidates = [$code];

    if (ctype_digit($code)) {

        if (strlen($code) === 13 && $code[0] === '0') {
            $candidates[] = substr($code, 1);
        }

        if (strlen($code) === 12) {
            $candidates[] = '0'.$code;
        }
    }

    $candidates = array_unique($candidates);

    $p = null;

    foreach ($candidates as $candidate) {

        $p = one("
            SELECT
                id_producto, codigo, nombre, imagen,
                precio_venta, costo_promedio, stock_actual
            FROM productos
            WHERE codigo = ?
              AND activo = 1
            LIMIT 1
        ", [$candidate]);

        if ($p) {
            break;
        }
    }

    echo json_encode($p
        ? ['found' => true, 'producto' => $p]
        : ['found' => false]
    );
    exit;
}


// ---------------------------------------------------------
// MODO 2: BÚSQUEDA LIBRE (usado por el buscador manual)
// ---------------------------------------------------------
$q = trim($_GET['q'] ?? '');

if ($q === '') {
    echo json_encode(['results' => []]);
    exit;
}

$like = '%'.$q.'%';

$results = allrows("
    SELECT
        id_producto, codigo, nombre, imagen,
        precio_venta, costo_promedio, stock_actual
    FROM productos
    WHERE activo = 1
      AND (codigo LIKE ? OR nombre LIKE ?)
    ORDER BY (codigo = ?) DESC, nombre ASC
    LIMIT 10
", [$like, $like, $q]);

echo json_encode(['results' => $results], JSON_UNESCAPED_UNICODE);